<?php
/**
 * Autoloader
 *
 * @package    AvalonAddons
 * @subpackage Core
 */

namespace AvalonAddons;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Autoloader
 *
 * PSR-4 compliant autoloader for the plugin.
 */
class Autoloader {

	/**
	 * Registers the autoloader with SPL.
	 *
	 * @return void
	 */
	public static function register() {
		spl_autoload_register( [ new self(), 'auto_load' ] );
	}

	/**
	 * Handles autoloading of plugin classes.
	 *
	 * @param  string $class_name Fully qualified class name.
	 * @return void
	 */
	public function auto_load( $class_name ) {
		// Check if the class is in our namespace.
		$namespace = 'AvalonAddons';
		if ( 0 !== strpos( $class_name, $namespace ) ) {
			return;
		}

		// Remove the namespace from the class name.
		$class_name = str_replace( $namespace, '', $class_name );

		// Convert namespace separators to directory separators.
		$class_path = str_replace( '\\', DIRECTORY_SEPARATOR, $class_name );
		$class_path = str_replace( '_', '-', $class_path );
		$class_path = strtolower( $class_path );

		// Build the full path to the class file.
		$file = __DIR__ . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . $class_path . '.php';

		// If the file exists, require it.
		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
}

// Initialize the autoloader.
Autoloader::register();
