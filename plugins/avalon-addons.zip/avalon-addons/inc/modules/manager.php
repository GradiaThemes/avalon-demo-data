<?php
/**
 * Module Manager
 *
 * Manages module registration and initialization.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Manager class.
 *
 * Singleton class that manages all modules.
 */
class Manager {

	/**
	 * Instance
	 *
	 * @var Manager
	 */
	private static $instance = null;

	/**
	 * Option name for storing module states.
	 *
	 * Stored as a map of module_id => bool.
	 * A missing key means the module's own is_default_active() is used.
	 *
	 * @var string
	 */
	public const OPTION_MODULES = 'avalon_addons_active_modules';

	/**
	 * Nonce action for the admin features page.
	 *
	 * @var string
	 */
	public const NONCE_ACTION = 'avalon_addons_admin_nonce';

	/**
	 * Registered modules.
	 *
	 * @var array<string, string> Array of module_id => class_name pairs.
	 */
	private static array $modules = [];

	/**
	 * Active module instances.
	 *
	 * @var array<string, Module_Base> Array of module_id => instance pairs.
	 */
	private static array $instances = [];

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded.
	 *
	 * @return Manager
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->register_modules();
		$this->init_active_modules();
	}

	/**
	 * Register a module class.
	 *
	 * @param string $class_name Fully qualified module class name.
	 * @return bool True if registered, false if already exists or invalid.
	 */
	public static function register( string $class_name ): bool {
		// Validate class exists and extends Module_Base.
		if ( ! class_exists( $class_name ) || ! is_subclass_of( $class_name, Module_Base::class ) ) {
			return false;
		}

		$module_id = $class_name::get_id();

		// Don't override if module already exists.
		if ( isset( self::$modules[ $module_id ] ) ) {
			return false;
		}

		self::$modules[ $module_id ] = $class_name;

		// Always-run module setup, regardless of enabled/available state.
		$class_name::bootstrap();

		return true;
	}

	/**
	 * Register modules.
	 *
	 * @return void
	 */
	protected function register_modules(): void {
		self::register( Toc\Module::class );

		do_action( 'avalon_addons_modules_register' );
	}

	/**
	 * Initialize active modules.
	 *
	 * Creates instances of enabled modules only.
	 *
	 * @return void
	 */
	protected function init_active_modules(): void {
		foreach ( self::$modules as $module_id => $class_name ) {
			if ( ! self::is_enabled( $module_id ) ) {
				continue;
			}

			if ( ! $class_name::is_available() ) {
				continue;
			}

			self::$instances[ $module_id ] = new $class_name();
		}
	}

	/**
	 * Get all registered modules with their information.
	 *
	 * Returns an array formatted for the admin page.
	 *
	 * @return array<string, array> Array of module_id => module_info pairs.
	 */
	public static function get_modules(): array {
		$modules = [];

		foreach ( self::$modules as $module_id => $class_name ) {
			$info = [
				'name'         => $class_name::get_name(),
				'description'  => $class_name::get_description(),
				'category'     => $class_name::get_category(),
				'settings_url' => $class_name::get_settings_url(),
				'docs_url'     => $class_name::get_docs_url(),
			];

			$info['enabled']         = self::is_enabled( $module_id );
			$info['available']       = $class_name::is_available();
			$info['requires_reload'] = $class_name::requires_reload();

			$modules[ $module_id ] = $info;
		}

		return $modules;
	}

	/**
	 * Get an active module instance.
	 *
	 * Returns the module instance only if it's registered, enabled, and available.
	 *
	 * @param string $module_id Module ID.
	 * @return Module_Base|null Module instance or null if not accessible.
	 */
	public static function get_active_module( string $module_id ): ?Module_Base {
		if ( ! isset( self::$modules[ $module_id ] ) ) {
			return null;
		}

		$class_name = self::$modules[ $module_id ];

		if ( ! self::is_enabled( $module_id ) || ! $class_name::is_available() ) {
			return null;
		}

		return self::$instances[ $module_id ] ?? null;
	}

	/**
	 * Check if a module is enabled.
	 *
	 * If the module has an explicit saved state, that is used. Otherwise,
	 * the module's own is_default_active() determines the result.
	 *
	 * @param string $module_id Module ID.
	 * @return bool True if module is enabled, false otherwise.
	 */
	public static function is_enabled( string $module_id ): bool {
		$state = get_option( self::OPTION_MODULES, [] );

		if ( is_array( $state ) && array_key_exists( $module_id, $state ) ) {
			return (bool) $state[ $module_id ];
		}

		// No saved state - use the module's own default.
		if ( isset( self::$modules[ $module_id ] ) ) {
			return self::$modules[ $module_id ]::is_default_active();
		}

		return false;
	}

	/**
	 * Get active module IDs.
	 *
	 * @return array<string> Array of active module IDs.
	 */
	public static function get_active_module_ids(): array {
		$active = [];

		foreach ( self::$modules as $module_id => $class_name ) {
			if ( self::is_enabled( $module_id ) ) {
				$active[] = $module_id;
			}
		}

		return $active;
	}

	/**
	 * Get all registered module IDs.
	 *
	 * @return array<string> Array of module IDs.
	 */
	public static function get_module_ids(): array {
		return array_keys( self::$modules );
	}

	/**
	 * Apply a partial set of module state changes.
	 *
	 * Reads the existing stored state, updates only the provided module IDs
	 * (and only for currently-registered modules), and persists the result.
	 *
	 * @param array<string, bool> $changes Map of module_id => enabled.
	 * @return bool True if the option was updated.
	 */
	public static function apply_module_changes( array $changes ): bool {
		$state = get_option( self::OPTION_MODULES, [] );

		if ( ! is_array( $state ) ) {
			$state = [];
		}

		foreach ( $changes as $module_id => $enabled ) {
			// Only accept changes for currently-registered modules
			// to prevent arbitrary keys being written to the option.
			if ( isset( self::$modules[ $module_id ] ) ) {
				$state[ $module_id ] = $enabled;
			}
		}

		return update_option( self::OPTION_MODULES, $state );
	}
}
