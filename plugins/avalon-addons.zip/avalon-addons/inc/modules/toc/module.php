<?php
/**
 * Table of Contents module
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Modules\Toc;

use AvalonAddons\Modules\Module_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Table of Contents module class.
 *
 * Parses single-post headings, injects stable IDs, and renders a floating
 * table of contents in the footer that links to each section.
 */
class Module extends Module_Base {

	/**
	 * Priority for the content filter.
	 *
	 * @var int
	 */
	private const CONTENT_PRIORITY = 20;

	/**
	 * Rendered TOC markup for the current request.
	 *
	 * @var string
	 */
	private string $toc_html = '';

	/**
	 * Processed post IDs.
	 *
	 * Prevents the same post from being processed more than once per request.
	 *
	 * @var array<int, bool>
	 */
	private static array $processed = [];

	/**
	 * Cached page builder check results.
	 *
	 * Prevents repeated meta lookups when the same post is checked more than
	 * once per request (asset enqueue + content processing).
	 *
	 * @var array<int, bool>
	 */
	private static array $builder_cache = [];

	/**
	 * Get module ID.
	 *
	 * @return string Module ID.
	 */
	public static function get_id(): string {
		return 'toc';
	}

	/**
	 * Get module display name.
	 *
	 * @return string Module display name.
	 */
	public static function get_name(): string {
		return __( 'Table of Contents', 'avalon-addons' );
	}

	/**
	 * Get module description.
	 *
	 * @return string Module description.
	 */
	public static function get_description(): string {
		return __( 'Adds a floating table of contents to default WordPress single blog posts. Not available on pages, or on posts built with a page builder (Elementor, WPBakery, Beaver Builder, Divi, Bricks).', 'avalon-addons' );
	}

	/**
	 * Whether this module is active by default.
	 *
	 * @return bool
	 */
	public static function is_default_active(): bool {
		return true;
	}

	/**
	 * Initialize the module.
	 *
	 * @return void
	 */
	public function init(): void {
		add_filter( 'the_content', [ $this, 'process_content' ], self::CONTENT_PRIORITY );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'wp_footer', [ $this, 'render_toc_panel' ] );
	}

	/**
	 * Enqueue frontend assets.
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( ! $this->is_active() ) {
			return;
		}

		wp_enqueue_style( 'avalon-toc', AVALON_ADDONS_URL . 'inc/modules/toc/css/toc.css', [], AVALON_ADDONS_VERSION );

		if ( file_exists( AVALON_ADDONS_PATH . 'inc/modules/toc/css/toc-rtl.css' ) ) {
			wp_style_add_data( 'avalon-toc', 'rtl', 'replace' );
		}

		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_script( 'avalon-toc', AVALON_ADDONS_URL . 'inc/modules/toc/js/toc' . $debug . '.js', [], AVALON_ADDONS_VERSION, true );
	}

	/**
	 * Process the post content.
	 *
	 * @param string $content The post content.
	 * @return string Modified content.
	 */
	public function process_content( string $content ): string {
		if ( '' === trim( $content ) || ! $this->should_process() ) {
			return $content;
		}

		$post_id = (int) get_the_ID();

		if ( isset( self::$processed[ $post_id ] ) ) {
			return $content;
		}
		self::$processed[ $post_id ] = true;

		try {
			$headings = $this->collect_headings( $content );
			$headings = (array) apply_filters( 'avalon_addons_toc_headings', $headings );

			$min_headings = (int) apply_filters( 'avalon_addons_toc_min_headings', 2 );
			if ( count( $headings ) < $min_headings ) {
				return $content;
			}

			$content = $this->inject_ids( $content, $headings );

			$title          = (string) apply_filters( 'avalon_addons_toc_title', __( 'On this page', 'avalon-addons' ) );
			$this->toc_html = $this->render_toc( $this->build_tree( $headings ), $title );

			return '<div class="avalon-toc__content">' . $content . '</div>';
		} catch ( \Throwable $e ) {
			return $content;
		}
	}

	/**
	 * Check whether the TOC can run on the current request.
	 *
	 * @return bool
	 */
	private function is_active(): bool {
		if ( ! is_singular( 'post' ) || is_embed() ) {
			return false;
		}

		if ( ! apply_filters( 'avalon_addons_toc_enabled', true ) ) {
			return false;
		}

		if ( $this->is_built_with_builder( get_the_ID() ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Check whether the post is built with a page builder.
	 *
	 * Only supports the default WordPress editor. Single posts built with
	 * Elementor, WPBakery, Beaver Builder, Divi, or Bricks are excluded.
	 *
	 * @param int $post_id Post ID.
	 * @return bool True if the post is built with a supported page builder.
	 */
	private function is_built_with_builder( int $post_id ): bool {
		if ( isset( self::$builder_cache[ $post_id ] ) ) {
			return self::$builder_cache[ $post_id ];
		}

		self::$builder_cache[ $post_id ] = $this->check_builders( $post_id );

		return self::$builder_cache[ $post_id ];
	}

	/**
	 * Check whether the post is built with a supported page builder.
	 *
	 * Reads all post meta in a single query instead of one query per key.
	 *
	 * @param int $post_id Post ID.
	 * @return bool True if the post is built with a supported page builder.
	 */
	private function check_builders( int $post_id ): bool {
		// Elementor (theme helper, when available).
		if (
			class_exists( '\Avalon\Integrations\Elementor' ) &&
			method_exists( '\Avalon\Integrations\Elementor', 'is_page_built_with_elementor' ) &&
			\Avalon\Integrations\Elementor::is_page_built_with_elementor( $post_id )
		) {
			return true;
		}

		$meta = get_post_meta( $post_id, '', true );

		if ( ! is_array( $meta ) ) {
			$meta = [];
		}

		// Elementor.
		if ( isset( $meta['_elementor_data'][0] ) && '' !== $meta['_elementor_data'][0] ) {
			return true;
		}

		// Beaver Builder.
		if ( isset( $meta['_fl_builder_enabled'][0] ) && '1' === $meta['_fl_builder_enabled'][0] ) {
			return true;
		}

		// Divi.
		if ( isset( $meta['_et_pb_use_builder'][0] ) && 'on' === $meta['_et_pb_use_builder'][0] ) {
			return true;
		}

		// Bricks.
		if ( isset( $meta['bricks'][0] ) && '' !== $meta['bricks'][0] ) {
			return true;
		}

		// WPBakery.
		if ( isset( $meta['_vc_post_settings'][0] ) && '' !== $meta['_vc_post_settings'][0] ) {
			return true;
		}

		// WPBakery via content (shortcode-only usage).
		$content = (string) get_post_field( 'post_content', $post_id );

		return false !== strpos( $content, '[vc_' ) && (bool) preg_match( '/\[vc_(row|column|column_text|custom_heading|single_image|section)\b/', $content );
	}

	/**
	 * Check whether the main loop is rendering the single post content.
	 *
	 * @return bool
	 */
	private function should_process(): bool {
		return $this->is_active() && in_the_loop() && is_main_query();
	}

	/**
	 * Create an HTML processor for the given content.
	 *
	 * @param string $content The post content.
	 * @return \WP_HTML_Processor|null Processor instance or null on failure.
	 */
	private function create_processor( string $content ): ?\WP_HTML_Processor {
		if ( ! class_exists( '\WP_HTML_Processor' ) ) {
			return null;
		}

		try {
			return \WP_HTML_Processor::create_fragment( $content, '<body>', 'UTF-8' );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Get the heading tags this module targets.
	 *
	 * @return array<string> Heading tag names.
	 */
	private function heading_tags(): array {
		return [ 'h2', 'h3', 'h4', 'h5', 'h6' ];
	}

	/**
	 * Collect headings from the content.
	 *
	 * Reads each heading's existing ID and visible text, and assigns a
	 * stable, unique ID to every heading.
	 *
	 * @param string $content The post content.
	 * @return array<int, array> List of heading data.
	 */
	private function collect_headings( string $content ): array {
		$processor = $this->create_processor( $content );

		if ( ! $processor ) {
			return [];
		}

		$heading_tags = $this->heading_tags();
		$headings     = [];
		$used_ids     = [];
		$heading_key  = 0;

		while ( $processor->next_tag( [ 'tag_closers' => 'skip' ] ) ) {
			$tag = strtolower( (string) $processor->get_tag() );

			if ( ! in_array( $tag, $heading_tags, true ) ) {
				$element_id = $processor->get_attribute( 'id' );

				if ( is_string( $element_id ) && '' !== trim( $element_id ) ) {
					$used_ids[ trim( $element_id ) ] = true;
				}

				continue;
			}

			$existing_id = $processor->get_attribute( 'id' );
			$text        = $this->read_heading_text( $processor, $tag );

			if ( is_string( $existing_id ) && '' !== trim( $existing_id ) ) {
				$heading_id = $this->make_unique_id( trim( $existing_id ), $used_ids );
			} else {
				$heading_id = $this->make_unique_id( $this->slugify( $text ), $used_ids );
			}

			$headings[] = [
				'index' => $heading_key,
				'tag'   => $tag,
				'id'    => $heading_id,
				'text'  => $text,
			];

			++$heading_key;
		}

		return $headings;
	}

	/**
	 * Read the visible text of the current heading.
	 *
	 * The processor must be positioned on the heading opener. On return the
	 * processor is positioned on the matching closing tag.
	 *
	 * @param \WP_HTML_Processor $processor   The HTML processor.
	 * @param string             $heading_tag The heading tag name, e.g. 'h2'.
	 * @return string Heading text.
	 */
	private function read_heading_text( \WP_HTML_Processor $processor, string $heading_tag ): string {
		$text  = '';
		$depth = 0;

		while ( $processor->next_token() ) {
			if ( '#text' === $processor->get_token_type() ) {
				$text .= $processor->get_modifiable_text();
				continue;
			}

			if ( '#tag' !== $processor->get_token_type() ) {
				continue;
			}

			if ( ! $processor->is_tag_closer() ) {
				if ( strtolower( (string) $processor->get_tag() ) === $heading_tag ) {
					++$depth;
				}

				continue;
			}

			if ( strtolower( (string) $processor->get_tag() ) === $heading_tag ) {
				if ( 0 === $depth ) {
					break;
				}

				--$depth;
			}
		}

		$text = preg_replace( '/\s+/u', ' ', $text );

		return trim( is_string( $text ) ? $text : '' );
	}

	/**
	 * Inject the collected IDs into the content headings.
	 *
	 * @param string            $content  The post content.
	 * @param array<int, array> $headings List of heading data.
	 * @return string Modified content.
	 */
	private function inject_ids( string $content, array $headings ): string {
		$processor = $this->create_processor( $content );

		if ( ! $processor ) {
			return $content;
		}

		$pending = [];
		foreach ( $headings as $heading ) {
			$pending[ $heading['index'] ] = $heading['id'];
		}

		$heading_tags = $this->heading_tags();
		$index        = 0;

		while ( $processor->next_tag( [ 'tag_closers' => 'skip' ] ) ) {
			$tag = strtolower( (string) $processor->get_tag() );

			if ( ! in_array( $tag, $heading_tags, true ) ) {
				continue;
			}

			if ( isset( $pending[ $index ] ) ) {
				$expected = $pending[ $index ];
				$current  = $processor->get_attribute( 'id' );

				if ( $current !== $expected ) {
					$processor->set_attribute( 'id', $expected );
				}
			}

			++$index;
		}

		return $processor->get_updated_html();
	}

	/**
	 * Convert heading text into a URL-safe ID slug.
	 *
	 * @param string $text Heading text.
	 * @return string Slug, or 'heading' when nothing usable remains.
	 */
	private function slugify( string $text ): string {
		$slug = sanitize_title( $text, '', 'save' );

		return ( '' === $slug ) ? 'heading' : $slug;
	}

	/**
	 * Ensure an ID is unique within the document.
	 *
	 * @param string                  $id       Desired ID.
	 * @param array<int|string, bool> $used_ids IDs already taken.
	 * @return string Unique ID.
	 */
	private function make_unique_id( string $id, array &$used_ids ): string {
		$id     = ( '' === $id ) ? 'heading' : $id;
		$base   = $id;
		$suffix = 2;

		while ( isset( $used_ids[ $id ] ) ) {
			$id = $base . '-' . $suffix;
			++$suffix;
		}

		$used_ids[ $id ] = true;

		return $id;
	}

	/**
	 * Build a nested heading tree.
	 *
	 * @param array<int, array> $headings List of heading data.
	 * @return array<int, array> Nested tree of headings.
	 */
	private function build_tree( array $headings ): array {
		$root  = [ 'children' => [] ];
		$stack = [ 0 => &$root ];

		foreach ( $headings as $heading ) {
			$level = (int) substr( $heading['tag'], 1 );

			$parent_level = 0;
			for ( $l = $level - 1; $l >= 0; $l-- ) {
				if ( isset( $stack[ $l ] ) ) {
					$parent_level = $l;
					break;
				}
			}

			$item = [
				'id'       => $heading['id'],
				'text'     => $heading['text'],
				'children' => [],
			];

			$stack[ $parent_level ]['children'][] = &$item;

			foreach ( array_keys( $stack ) as $l ) {
				if ( $l >= $level ) {
					unset( $stack[ $l ] );
				}
			}

			$stack[ $level ] = &$item;
			unset( $item );
		}

		return $root['children'];
	}

	/**
	 * Render the table of contents.
	 *
	 * @param array<int, array> $tree  Nested heading tree.
	 * @param string            $title Table of contents title.
	 * @return string Rendered HTML.
	 */
	private function render_toc( array $tree, string $title ): string {
		ob_start();
		?>
		<nav class="avalon-toc" data-avalon-toc aria-label="<?php echo esc_attr( $title ); ?>">
			<span class="avalon-toc__title"><?php echo esc_html( $title ); ?></span>
			<?php $this->render_tree( $tree ); ?>
		</nav>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Render a heading list recursively.
	 *
	 * @param array<int, array> $items Heading items.
	 * @return void
	 */
	private function render_tree( array $items ): void {
		if ( empty( $items ) ) {
			return;
		}

		echo '<ul class="avalon-toc__list">';

		foreach ( $items as $item ) {
			echo '<li class="avalon-toc__item">';
			printf(
				'<a class="avalon-toc__link" href="#%s">%s</a>',
				esc_attr( $item['id'] ),
				esc_html( $item['text'] )
			);
			$this->render_tree( $item['children'] );
			echo '</li>';
		}

		echo '</ul>';
	}

	/**
	 * Render the floating TOC panel in the footer.
	 *
	 * @return void
	 */
	public function render_toc_panel(): void {
		if ( '' === $this->toc_html ) {
			return;
		}

		echo '<aside class="avalon-toc__aside fixed top-1/2 -translate-y-1/2 left--container z-10 invisible" aria-label="' . esc_attr__( 'Table of contents', 'avalon-addons' ) . '">'
			. wp_kses_post( $this->toc_html )
			. '</aside>';
	}
}
