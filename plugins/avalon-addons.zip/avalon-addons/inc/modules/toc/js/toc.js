(function () {
	'use strict';

	const panel = document.querySelector( '.avalon-toc__aside' );
	const content = document.querySelector( '.avalon-toc__content' );

	if ( ! panel || ! content ) {
		return;
	}

	const reduceMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	const items = [];

	panel.querySelectorAll( '.avalon-toc__link' ).forEach( function ( link ) {
		const href = link.getAttribute( 'href' );

		if ( ! href || '#' !== href.charAt( 0 ) || href.length < 2 ) {
			return;
		}

		const target = document.getElementById( href.slice( 1 ) );

		if ( ! target ) {
			return;
		}

		items.push( { id: href.slice( 1 ), link: link, target: target } );
	} );

	if ( ! items.length ) {
		return;
	}

	let ticking = false;

	function scrollToTarget( target ) {
		const smoother = window.ScrollSmoother && window.ScrollSmoother.get();

		if ( smoother ) {
			smoother.scrollTo( target, ! reduceMotion );
			return;
		}

		const rect = target.getBoundingClientRect();
		const margin = parseFloat( getComputedStyle( target ).scrollMarginTop ) || 0;

		window.scrollTo( {
			top: rect.top + window.scrollY - margin,
			behavior: reduceMotion ? 'auto' : 'smooth',
		} );
	}

	function update() {
		const viewportHeight = window.innerHeight;
		const contentRect = content.getBoundingClientRect();
		const visible = contentRect.top < viewportHeight && contentRect.bottom > 0;

		panel.classList.toggle( 'invisible', ! visible );

		const line = viewportHeight * 0.35;
		let currentId = '';

		for ( let i = 0; i < items.length; i++ ) {
			if ( items[ i ].target.getBoundingClientRect().top <= line ) {
				currentId = items[ i ].id;
			} else {
				break;
			}
		}

		items.forEach( function ( item ) {
			item.link.classList.toggle( 'is-active', item.id === currentId );
		} );

		ticking = false;
	}

	function requestUpdate() {
		if ( ticking ) {
			return;
		}

		ticking = true;
		window.requestAnimationFrame( update );
	}

	window.addEventListener( 'scroll', requestUpdate, { passive: true } );
	window.addEventListener( 'resize', requestUpdate );

	update();

	panel.addEventListener( 'click', function ( event ) {
		const link = event.target.closest( '.avalon-toc__link' );

		if ( ! link ) {
			return;
		}

		const href = link.getAttribute( 'href' );

		if ( ! href || '#' !== href.charAt( 0 ) || href.length < 2 ) {
			return;
		}

		const target = document.getElementById( href.slice( 1 ) );

		if ( ! target ) {
			return;
		}

		event.preventDefault();

		scrollToTarget( target );

		if ( window.history && window.history.replaceState ) {
			window.history.replaceState( null, '', href );
		}
	} );
})();
