<?php
/**
 * Module base class
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Module abstract class.
 *
 * Provides base functionality for all modules. Module instances are
 * managed exclusively by Manager - do not instantiate directly.
 */
abstract class Module_Base {

	/**
	 * Default module category.
	 *
	 * @var string
	 */
	public const CATEGORY_THEME = 'theme';

	/**
	 * Get module ID.
	 *
	 * Must be unique across all modules.
	 *
	 * @return string Module ID.
	 */
	abstract public static function get_id(): string;

	/**
	 * Get module display name.
	 *
	 * @return string Module display name.
	 */
	abstract public static function get_name(): string;

	/**
	 * Get module category.
	 *
	 * @return string Category key.
	 */
	public static function get_category(): string {
		return self::CATEGORY_THEME;
	}

	/**
	 * Get module description.
	 *
	 * @return string Module description.
	 */
	public static function get_description(): string {
		return '';
	}

	/**
	 * Get module settings URL.
	 *
	 * @return string URL to module settings page, or empty string if none.
	 */
	public static function get_settings_url(): string {
		return '';
	}

	/**
	 * Get module documentation URL.
	 *
	 * @return string URL to module documentation, or empty string if none.
	 */
	public static function get_docs_url(): string {
		return '';
	}

	/**
	 * Always-run module setup.
	 *
	 * Called by Manager for every registered module, regardless of enabled
	 * or available state. Override to wire behavior a module needs even
	 * when it never boots. No-op by default.
	 *
	 * @return void
	 */
	public static function bootstrap(): void {}

	/**
	 * Initialize the module.
	 *
	 * Should be overridden by child classes to register hooks, filters, etc.
	 *
	 * @return void
	 */
	public function init(): void {}

	/**
	 * Check if module is available.
	 *
	 * Override this method to check for plugin dependencies or other requirements.
	 *
	 * @return bool True if module can be used, false otherwise.
	 */
	public static function is_available(): bool {
		return true;
	}

	/**
	 * Whether this module should be active by default.
	 *
	 * When no explicit state is saved for this module, this value determines
	 * whether it is considered active. Users may override via the admin dashboard.
	 *
	 * @return bool
	 */
	public static function is_default_active(): bool {
		return false;
	}

	/**
	 * Whether toggling this module requires a page reload to take effect.
	 *
	 * Override and return true for modules that register hooks, rewrite rules,
	 * or admin UI at boot time that cannot be changed dynamically.
	 *
	 * @return bool
	 */
	public static function requires_reload(): bool {
		return false;
	}

	/**
	 * Constructor.
	 *
	 * Modules must be instantiated via Manager, not directly.
	 */
	public function __construct() {
		$this->init();
	}
}
