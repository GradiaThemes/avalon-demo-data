<?php
/**
 * Theme Features admin page
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Theme Features admin class.
 *
 * Registers a "Theme Features" submenu under the Avalon dashboard menu and
 * handles toggling module states via AJAX.
 */
class Theme_Features {

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	public const SLUG = 'avalon-theme-features';

	/**
	 * Page hook suffix returned by add_submenu_page().
	 *
	 * @var string
	 */
	private string $page_hook = '';

	/**
	 * Instance
	 *
	 * @var Theme_Features
	 */
	private static $instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded.
	 *
	 * @return Theme_Features
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ], 15 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'wp_ajax_avalon_addons_save_modules', [ $this, 'ajax_save_modules' ] );
	}

	/**
	 * Register the admin submenu.
	 *
	 * @return void
	 */
	public function register_menu(): void {
		$this->page_hook = add_submenu_page(
			'avalon_dashboard',
			esc_html__( 'Theme Features', 'avalon-addons' ),
			esc_html__( 'Theme Features', 'avalon-addons' ),
			'manage_options',
			self::SLUG,
			[ $this, 'render_page' ]
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( string $hook ): void {
		if ( $this->page_hook !== $hook ) {
			return;
		}

		wp_enqueue_style( 'avalon-theme-features', AVALON_ADDONS_ASSETS_URL . 'css/admin/theme-features.css', [], AVALON_ADDONS_VERSION );

		if ( file_exists( AVALON_ADDONS_PATH . 'assets/css/admin/theme-features-rtl.css' ) ) {
			wp_style_add_data( 'avalon-theme-features', 'rtl', 'replace' );
		}

		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_script( 'avalon-theme-features', AVALON_ADDONS_ASSETS_URL . 'js/admin/theme-features' . $debug . '.js', [ 'jquery' ], AVALON_ADDONS_VERSION, true );

		$modules = Manager::get_modules();

		wp_localize_script(
			'avalon-theme-features',
			'avalonThemeFeatures',
			[
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( Manager::NONCE_ACTION ),
				'moduleNames'  => wp_list_pluck( $modules, 'name' ),
				'activeText'   => esc_html__( 'Active', 'avalon-addons' ),
				'inactiveText' => esc_html__( 'Inactive', 'avalon-addons' ),
			]
		);
	}

	/**
	 * Handle AJAX requests to save module states.
	 *
	 * @return void
	 */
	public function ajax_save_modules(): void {
		check_ajax_referer( Manager::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Permission denied.', 'avalon-addons' ) ] );
		}

		$changes = [];

		if ( isset( $_POST['changes'] ) && is_array( $_POST['changes'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$raw = wp_unslash( $_POST['changes'] );

			foreach ( $raw as $module_id => $enabled ) {
				$changes[ sanitize_key( (string) $module_id ) ] = filter_var( $enabled, FILTER_VALIDATE_BOOLEAN );
			}
		}

		Manager::apply_module_changes( $changes );

		wp_send_json_success();
	}

	/**
	 * Render the admin page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$modules = Manager::get_modules();
		?>
		<div class="wrap avalon-features">
			<h1><?php esc_html_e( 'Theme Features', 'avalon-addons' ); ?></h1>
			<p class="avalon-features__intro">
				<?php esc_html_e( 'Enable or disable Avalon Addons features to customize your site.', 'avalon-addons' ); ?>
			</p>

			<div class="avalon-features__actions">
				<button type="button" class="button button-primary avalon-bulk-toggle" data-action="activate">
					<?php esc_html_e( 'Activate All', 'avalon-addons' ); ?>
				</button>
				<button type="button" class="button avalon-bulk-toggle" data-action="deactivate">
					<?php esc_html_e( 'Deactivate All', 'avalon-addons' ); ?>
				</button>
			</div>

			<div class="avalon-features__grid">
				<?php foreach ( $modules as $module_id => $module ) : ?>
					<div class="avalon-feature-card<?php echo $module['enabled'] ? ' is-enabled' : ''; ?><?php echo ! $module['available'] ? ' is-unavailable' : ''; ?>">
						<div class="avalon-feature-card__header">
							<h2 class="avalon-feature-card__title"><?php echo esc_html( $module['name'] ); ?></h2>
							<label class="avalon-toggle<?php echo ! $module['available'] ? ' avalon-toggle--disabled' : ''; ?>">
								<input
									type="checkbox"
									class="avalon-toggle__input"
									data-module="<?php echo esc_attr( $module_id ); ?>"
									<?php checked( $module['enabled'], true ); ?>
									<?php disabled( ! $module['available'] ); ?>
								>
								<span class="avalon-toggle__slider" aria-hidden="true"></span>
								<span class="screen-reader-text"><?php echo esc_html( $module['name'] ); ?></span>
							</label>
						</div>
						<p class="avalon-feature-card__desc"><?php echo esc_html( $module['description'] ); ?></p>
						<div class="avalon-feature-card__footer">
							<span class="avalon-feature-card__badge avalon-feature-card__badge--<?php echo $module['enabled'] ? 'active' : 'inactive'; ?>">
								<?php echo $module['enabled'] ? esc_html__( 'Active', 'avalon-addons' ) : esc_html__( 'Inactive', 'avalon-addons' ); ?>
							</span>
							<?php if ( ! $module['available'] ) : ?>
								<span class="avalon-feature-card__notice">
									<?php esc_html_e( 'Unavailable', 'avalon-addons' ); ?>
								</span>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
