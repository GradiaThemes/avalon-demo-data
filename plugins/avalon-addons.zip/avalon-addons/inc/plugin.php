<?php
/**
 * AvalonAddons init
 *
 * @package AvalonAddons
 */

namespace AvalonAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * AvalonAddons init
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		$current_theme = wp_get_theme();
		if ( ! in_array( $current_theme->get( 'Name' ), [ 'Avalon', 'Avalon Child' ], true ) ) {
			return;
		}

		add_action( 'plugins_loaded', [ $this, 'load_templates' ] );
		add_action( 'init', [ $this, 'load_init' ] );

		// The importer bails unless OCDI and Elementor are already available, so
		// instantiate it late on plugins_loaded instead of here: at this point
		// no other plugin file has been included yet.
		add_action( 'plugins_loaded', [ $this, 'load_importer' ], 20 );
	}

	/**
	 * Load the demo importer integration.
	 *
	 * @return void
	 */
	public function load_importer() {
		Admin\Importer::instance();
	}

	/**
	 * Load templates
	 *
	 * @return void
	 */
	public function load_templates() {
		Shortcode::instance();

		Modules\Manager::instance();
		Modules\Theme_Features::instance();

		if ( did_action( 'elementor/loaded' ) ) {
			Elementor\Elementor::instance();
		}

		if ( defined( 'MC4WP_VERSION' ) ) {
			Integrations\MailChimp::instance();
		}
	}

	/**
	 * Load init
	 *
	 * @return void
	 */
	public function load_init() {
		if ( ! defined( 'AVALON_PATH' ) ) {
			return;
		}

		Blocks\Button_Block::instance();

		Admin\Portfolio::instance();
	}
}
