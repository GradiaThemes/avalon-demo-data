<?php
/**
 * Helper functions
 *
 * @package AvalonAddons
 */

namespace AvalonAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Helper class
 */
class Helper {

	/**
	 * Get Theme SVG.
	 *
	 * @param string $svg_name SVG name.
	 * @param string $group Icon group.
	 * @param array  $attr Arguments.
	 * @return string
	 */
	public static function get_svg( string $svg_name, string $group = 'ui', array $attr = [] ): string {
		if ( class_exists( '\Avalon\Icon' ) && method_exists( '\Avalon\Icon', 'get_svg' ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return \Avalon\Icon::get_svg( $svg_name, $group, $attr );
		}

		return '';
	}

	/**
	 * Social network share URL templates.
	 *
	 * @var array<string, string>
	 */
	public static array $share_urls = [
		'facebook'  => 'https://www.facebook.com/sharer/sharer.php?u={url}',
		'x'         => 'https://twitter.com/intent/tweet?url={url}&text={title}',
		'linkedin'  => 'https://www.linkedin.com/sharing/share-offsite/?url={url}',
		'pinterest' => 'https://pinterest.com/pin/create/button/?url={url}&media={image}&description={title}',
		'whatsapp'  => 'https://api.whatsapp.com/send?text={title}%20{url}',
		'telegram'  => 'https://t.me/share/url?url={url}&text={title}',
		'email'     => 'mailto:?subject={title}&body={url}',
		'reddit'    => 'https://www.reddit.com/submit?url={url}&title={title}',
		'pocket'    => 'https://getpocket.com/save?url={url}&title={title}',
		'instagram' => 'https://www.instagram.com/?url={url}',
		'clipboard' => '{url}',
	];

	/**
	 * Get the share URL for a social network.
	 *
	 * @param string   $network The social network (facebook, twitter, linkedin, etc.).
	 * @param int|null $post_id Optional. The post ID. Defaults to current post.
	 * @return string The share URL or empty string if network not supported.
	 */
	public static function get_share_url( string $network, ?int $post_id = null ): string {
		$network = strtolower( $network );

		if ( ! isset( self::$share_urls[ $network ] ) ) {
			return '';
		}

		$post_id = $post_id ?? get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		$url   = get_permalink( $post_id );
		$title = get_the_title( $post_id );
		$image = get_the_post_thumbnail_url( $post_id, 'full' );

		// Clipboard returns the raw URL (not URL-encoded) for copying.
		if ( 'clipboard' === $network ) {
			/**
			 * Filter the share URL for a social network.
			 *
			 * @param string $share_url The generated share URL.
			 * @param string $network   The social network.
			 * @param int    $post_id   The post ID.
			 */
			return apply_filters( 'avalon_share_url', $url, $network, $post_id );
		}

		$replacements = [
			'{url}'   => rawurlencode( $url ),
			'{title}' => rawurlencode( $title ),
			'{image}' => rawurlencode( $image ?? '' ),
		];

		$share_url = str_replace(
			array_keys( $replacements ),
			array_values( $replacements ),
			self::$share_urls[ $network ]
		);

		/**
		 * Filter the share URL for a social network.
		 *
		 * @param string $share_url The generated share URL.
		 * @param string $network   The social network.
		 * @param int    $post_id   The post ID.
		 */
		return apply_filters( 'avalon_share_url', $share_url, $network, $post_id );
	}

	/**
	 * Get all available share URLs for a post.
	 *
	 * @param array    $networks Optional. Specific networks to get. Defaults to all.
	 * @param int|null $post_id  Optional. The post ID. Defaults to current post.
	 * @return array<string, string> Array of network => share URL.
	 */
	public static function get_share_urls( array $networks = [], ?int $post_id = null ): array {
		if ( empty( $networks ) ) {
			$networks = array_keys( self::$share_urls );
		}

		$urls = [];

		foreach ( $networks as $network ) {
			$url = self::get_share_url( $network, $post_id );
			if ( ! empty( $url ) ) {
				$urls[ $network ] = $url;
			}
		}

		return $urls;
	}
}
