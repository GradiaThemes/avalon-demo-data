<?php
/**
 * Button Block registration and render callback.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Button_Block
 */
final class Button_Block {

	/**
	 * Singleton instance.
	 *
	 * @var Button_Block|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return Button_Block
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->register_block();
	}

	/**
	 * Register the Button block.
	 */
	public function register_block() {
		$path = AVALON_ADDONS_PATH . 'inc/blocks/button';

		if ( ! file_exists( $path . '/block.json' ) ) {
			return;
		}

		register_block_type(
			$path,
			[
				'render_callback' => [ $this, 'render_callback' ],
			]
		);
	}

	/**
	 * Render callback for the Button block.
	 *
	 * @param array  $attributes Block attributes.
	 * @param string $content    Block content.
	 * @return string Rendered HTML.
	 */
	public function render_callback( $attributes, $content ) {
		if ( empty( trim( wp_strip_all_tags( $content ) ) ) ) {
			return '';
		}
		return $content;
	}
}
