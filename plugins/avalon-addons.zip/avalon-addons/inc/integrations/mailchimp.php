<?php
/**
 * MailChimp class
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use AvalonAddons\Helper;

/**
 * MailChimp
 */
class MailChimp {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'mc4wp_form_css_classes', [ $this, 'add_mailchimp_class' ], 10, 2 );
	}

	/**
	 * Add mailchimp class
	 *
	 * @param array $classes CSS classes.
	 * @param array $form Form.
	 * @return array
	 */
	public function add_mailchimp_class( $classes, $form ) {
		if ( empty( $form->settings['css'] ) ) {
			$classes[] = 'avalon-mc4wp-form-mailchimp';
		}

		return $classes;
	}
}
