<?php
/**
 * Hooks for importer
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Importer
 */
class Importer {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Returns the instance.
	 *
	 * @return object instance of class
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		if ( ! class_exists( 'OCDI_Plugin' ) || ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'ocdi/before_content_import', [ $this,'enable_svg_upload' ] );
		add_action( 'ocdi/customizer_import_execution', [ $this,'enable_svg_upload' ] );
		add_action( 'ocdi/before_widgets_import', [ $this,'enable_svg_upload' ] );
		add_action( 'init', [ $this, 'maybe_enable_svg_upload' ] );
		add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
		add_action( 'ocdi/after_import', [ $this, 'after_import_setup' ] );
	}

	/**
	 * Define demo import files.
	 *
	 * @return array
	 */
	public function import_files() {
		$base_path = 'https://github.com/GradiaThemes/avalon-demo-data/raw/refs/heads/main/data/';

		return [
			[
				'import_file_name'           => esc_html__( 'Design V1', 'avalon-addons' ),
				'import_preview_image_url'   => $base_path . 'v1/preview.jpg',
				'import_file_url'            => $base_path . 'v1/content.xml',
				'import_customizer_file_url' => $base_path . 'v1/customizer.dat',
				'preview_url'                => 'https://avalon.gradiathemes.com/home-v1/',
				'page_slugs'                 => [
					'home'      => 'home-v1',
					'blog'      => 'our-blogs',
					'portfolio' => 'works',
				],
				'menu_slugs'                 => [
					'primary' => 'Primary Menu',
				],
			],
			[
				'import_file_name'           => esc_html__( 'Design V2', 'avalon-addons' ),
				'import_preview_image_url'   => $base_path . 'v2/preview.jpg',
				'import_file_url'            => $base_path . 'v2/content.xml',
				'import_customizer_file_url' => $base_path . 'v2/customizer.dat',
				'preview_url'                => 'https://avalon.gradiathemes.com/home-v2/',
				'page_slugs'                 => [
					'home'      => 'home-v2',
					'blog'      => 'our-blogs',
					'portfolio' => 'works',
				],
				'menu_slugs'                 => [
					'primary' => 'Primary Menu',
				],
			],
			[
				'import_file_name'           => esc_html__( 'Design V3', 'avalon-addons' ),
				'import_preview_image_url'   => $base_path . 'v3/preview.jpg',
				'import_file_url'            => $base_path . 'v3/content.xml',
				'import_customizer_file_url' => $base_path . 'v3/customizer.dat',
				'preview_url'                => 'https://avalon.gradiathemes.com/home-v3/',
				'page_slugs'                 => [
					'home'      => 'home-v3',
					'blog'      => 'our-blogs',
					'portfolio' => 'works',
				],
				'menu_slugs'                 => [
					'primary' => 'Primary Menu V3',
				],
			],
		];
	}

	/**
	 * Enable svg upload
	 */
	public function enable_svg_upload() {
		add_filter( 'upload_mimes', [ $this, 'svg_upload_types' ] );
		add_filter( 'wp_check_filetype_and_ext', [ $this, 'svg_filetype_fix' ], 10, 5 );
		add_filter( 'wp_handle_sideload_prefilter', [ $this, 'svg_sideload_fix' ] );
	}

	/**
	 * Enable SVG upload during OCDI import across all AJAX requests.
	 * OCDI splits imports into multiple AJAX calls (separate PHP processes),
	 * so hooks like ocdi/before_content_import only run on the first request.
	 */
	public function maybe_enable_svg_upload() {
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX && get_transient( 'ocdi_importer_data' ) ) {
			$this->enable_svg_upload();
		}
	}

	/**
	 * Enable svg upload
	 *
	 * @param array $file_types File types.
	 * @return array
	 */
	public function svg_upload_types( $file_types ) {
		$new_filetypes         = [];
		$new_filetypes['svg']  = 'image/svg+xml';
		$new_filetypes['webp'] = 'image/webp';
		$file_types            = array_merge( $file_types, $new_filetypes );
		return $file_types;
	}

	/**
	 * Fix file type detection for SVG files.
	 *
	 * @param array  $data     File data.
	 * @param string $file     Full path to file.
	 * @param string $filename File name.
	 * @return array
	 */
	public function svg_filetype_fix( $data, $file, $filename ) {
		if ( ! empty( $data['ext'] ) ) {
			return $data;
		}

		$ext = pathinfo( $filename, PATHINFO_EXTENSION );

		if ( 'svg' === strtolower( $ext ) ) {
			$data['ext']             = 'svg';
			$data['type']            = 'image/svg+xml';
			$data['proper_filename'] = $filename;
		}

		return $data;
	}

	/**
	 * Fix sideload validation for SVG files.
	 *
	 * @param array $file File data.
	 * @return array
	 */
	public function svg_sideload_fix( $file ) {
		if ( 'image/svg+xml' === $file['type'] ) {
			if ( isset( $file['name'] ) ) {
				$ext = pathinfo( $file['name'], PATHINFO_EXTENSION );
				if ( 'svg' === strtolower( $ext ) ) {
					$contents = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local temp file read.
					if ( false !== strpos( $contents, '<svg' ) ) {
						return $file;
					}
				}
			}
		}
		return $file;
	}

	/**
	 * Setup after import.
	 *
	 * @param array $selected_import Selected import data.
	 * @return void
	 */
	public function after_import_setup( $selected_import ) {
		$pages = ! empty( $selected_import['page_slugs'] ) ? $selected_import['page_slugs'] : [];
		$menus = ! empty( $selected_import['menu_slugs'] ) ? $selected_import['menu_slugs'] : [];

		if ( ! empty( $pages['home'] ) ) {
			$page = get_page_by_path( $pages['home'] );
			if ( $page ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $page->ID );
			}
		}

		if ( ! empty( $pages['blog'] ) ) {
			$page = get_page_by_path( $pages['blog'] );
			if ( $page ) {
				update_option( 'page_for_posts', $page->ID );
			}
		}

		if ( ! empty( $pages['portfolio'] ) ) {
			$page = get_page_by_path( $pages['portfolio'] );
			if ( $page ) {
				update_option( 'avalon_portfolio_page_id', $page->ID );
			}
		}

		if ( ! empty( $menus ) ) {
			$locations = [];
			foreach ( $menus as $location => $menu_name ) {
				$menu = get_term_by( 'name', $menu_name, 'nav_menu' );
				if ( $menu ) {
					$locations[ $location ] = $menu->term_id;
				}
			}
			if ( ! empty( $locations ) ) {
				set_theme_mod( 'nav_menu_locations', $locations );
			}
		}

		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );

		if ( did_action( 'elementor/loaded' ) ) {
			\Elementor\Plugin::instance()->files_manager->clear_cache();
		}

		flush_rewrite_rules();
	}
}
