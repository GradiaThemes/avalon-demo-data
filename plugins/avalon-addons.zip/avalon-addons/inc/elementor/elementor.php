<?php
/**
 * Integrate with Elementor.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor class
 */
class Elementor {
	/**
	 * Instance
	 *
	 * @access private
	 *
	 * @var Elementor
	 */
	private static $instance = null;

	/**
	 * Widget category name
	 *
	 * @var string
	 */
	const CATEGORY     = 'avalon-widgets';
	const CLASS_WIDGET = 'avalon-elementor-widget';

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @return Elementor An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->setup_hooks();

		Dynamic_Controls\Autocomplete\Autocomplete::instance();
		Features\Theme_Settings::instance();
		Features\Page_Settings::instance();
		Features\Animation::instance();
		Features\Pin::instance();
		Builder\Builder::instance();

		if ( ! defined( 'ELEMENTOR_PRO_VERSION' ) ) {
			Features\Custom_CSS::instance();
		}
	}

	/**
	 * Hooks to init
	 */
	protected function setup_hooks() {
		add_action( 'wp', [ $this, 'actions' ], 20 );

		// Widgets.
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'register_styles' ] );

		add_action( 'elementor/frontend/before_enqueue_scripts', [ $this, 'register_scripts' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ] );

		// Editor.
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
	}

	/**
	 * Actions
	 */
	public function actions() {
		add_filter( 'avalon_content_container_class', [ $this, 'content_container_class' ], 10, 1 );
	}

	/**
	 * Content container class
	 *
	 * @param string $classes Container classes.
	 * @return string
	 */
	public function content_container_class( $classes ) {
		if ( is_singular() ) {
			$id = get_the_ID();

			if ( \AvalonAddons\Admin\Portfolio::is_portfolio_archive() ) {
				$id = \AvalonAddons\Admin\Portfolio::get_portfolio_page_id();
			}

			$document = \Elementor\Plugin::$instance->documents->get( $id );
			if ( $document && $document->is_built_with_elementor() ) {
				$classes = 'avalon-container-elementor';
			}
		}

		return $classes;
	}

	/**
	 * Get registered asset handles for a widget.
	 *
	 * @param string $slug Widget slug (without the 'avalon-' prefix).
	 * @return array Associative array of 'styles' and 'scripts' handle lists.
	 */
	public static function get_widget_assets( $slug ) {
		$assets = [
			'styles'  => [],
			'scripts' => [],
		];

		if ( file_exists( AVALON_ADDONS_PATH . 'assets/css/elementor/widgets/' . $slug . '.css' ) ) {
			$assets['styles'][] = 'avalon-elementor-widget-' . $slug;
		}

		if ( file_exists( AVALON_ADDONS_PATH . 'assets/js/elementor/widgets/' . $slug . '.js' ) ) {
			$assets['scripts'][] = 'avalon-elementor-widget-' . $slug;
		}

		return $assets;
	}

	/**
	 * Register styles
	 *
	 * @return void
	 */
	public function register_styles() {
		// Site-wide Elementor layout base, always loaded.
		wp_register_style( 'avalon-elementor-base', AVALON_ADDONS_URL . 'assets/css/elementor/core.css', [], AVALON_ADDONS_VERSION );
		$this->add_rtl_swap( 'avalon-elementor-base', AVALON_ADDONS_PATH . 'assets/css/elementor/core-rtl.css' );
		wp_enqueue_style( 'avalon-elementor-base' );

		// Per-widget styles, loaded on demand via get_style_depends().
		foreach ( glob( AVALON_ADDONS_PATH . 'assets/css/elementor/widgets/*.css' ) as $css_file ) {
			$slug   = basename( $css_file, '.css' );
			$handle = 'avalon-elementor-widget-' . $slug;

			wp_register_style( $handle, AVALON_ADDONS_URL . 'assets/css/elementor/widgets/' . $slug . '.css', [ 'avalon-elementor-base' ], AVALON_ADDONS_VERSION );
			$this->add_rtl_swap( $handle, AVALON_ADDONS_PATH . 'assets/css/elementor/widgets/' . $slug . '-rtl.css' );
		}
	}

	/**
	 * Register scripts
	 *
	 * @return void
	 */
	public function register_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_register_script( 'avalon-elementor-widget-common', AVALON_ADDONS_URL . 'assets/js/elementor/widgets/common' . $debug . '.js', [ 'jquery', 'underscore', 'elementor-frontend', 'regenerator-runtime' ], AVALON_ADDONS_VERSION, true );

		// Per-widget scripts, loaded on demand via get_script_depends().
		foreach ( glob( AVALON_ADDONS_PATH . 'assets/js/elementor/widgets/*.js' ) as $js_file ) {
			if ( '.min.js' === substr( $js_file, -7 ) ) {
				continue;
			}

			$slug = basename( $js_file, '.js' );

			if ( 'common' === $slug ) {
				continue;
			}

			$handle = 'avalon-elementor-widget-' . $slug;

			wp_register_script( $handle, AVALON_ADDONS_URL . 'assets/js/elementor/widgets/' . $slug . $debug . '.js', [ 'avalon-elementor-widget-common', 'elementor-frontend', 'jquery', 'underscore', 'regenerator-runtime' ], AVALON_ADDONS_VERSION, true );
		}
	}

	/**
	 * Init Widgets
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager instance.
	 */
	public function register_widgets( $widgets_manager ) {
		// Get all widget files from the widgets directory.
		$widgets_dir = AVALON_ADDONS_PATH . '/inc/elementor/widgets/';

		if ( ! is_dir( $widgets_dir ) ) {
			return;
		}

		$widget_files = glob( $widgets_dir . '*.php' );

		foreach ( $widget_files as $widget_file ) {
			$widget_name  = basename( $widget_file, '.php' );
			$widget_class = $this->get_widget_class_name( $widget_name );

			// Check if the class exists and register the widget.
			if ( class_exists( $widget_class ) ) {
				$widgets_manager->register( new $widget_class() );
			}
		}
	}

	/**
	 * Get widget class name from file name
	 *
	 * @param string $widget_name Widget name.
	 * @return string
	 */
	private function get_widget_class_name( $widget_name ) {
		// Convert kebab-case to PascalCase.
		$class_name = str_replace( '-', '_', $widget_name );
		$class_name = str_replace( '_', ' ', $class_name );
		$class_name = ucwords( $class_name );
		$class_name = str_replace( ' ', '_', $class_name );

		return '\\AvalonAddons\\Elementor\\Widgets\\' . $class_name;
	}

	/**
	 * Add Avalon category
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor widgets manager instance.
	 */
	public function add_category( $elements_manager ) {
		$elements_manager->add_category(
			self::CATEGORY,
			[
				'title' => esc_html__( 'Avalon', 'avalon-addons' ),
			]
		);
	}

	/**
	 * Add RTL swap data to a registered style.
	 *
	 * When the site language direction is RTL, WordPress replaces the
	 * stylesheet URL with its `-rtl.css` variant. The file must exist —
	 * otherwise only the LTR stylesheet is kept.
	 *
	 * @param string $handle   Registered style handle.
	 * @param string $rtl_file Absolute path to the `-rtl.css` variant.
	 * @return void
	 */
	private function add_rtl_swap( $handle, $rtl_file ) {
		if ( file_exists( $rtl_file ) ) {
			wp_style_add_data( $handle, 'rtl', 'replace' );
		}
	}

	/**
	 * Enqueue editor scripts
	 */
	public function enqueue_editor_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_style( 'avalon-elementor-editor', AVALON_ADDONS_ASSETS_URL . 'css/elementor/elementor-editor.css', [], AVALON_ADDONS_VERSION );
		$this->add_rtl_swap( 'avalon-elementor-editor', AVALON_ADDONS_PATH . 'assets/css/elementor/elementor-editor-rtl.css' );

		wp_enqueue_script(
			'avalon-elementor-modules',
			AVALON_ADDONS_ASSETS_URL . 'js/elementor/elementor-modules' . $debug . '.js',
			[
				'backbone-marionette',
				'elementor-common-modules',
				'elementor-editor-modules',
			],
			AVALON_ADDONS_VERSION,
			true
		);
	}
}
