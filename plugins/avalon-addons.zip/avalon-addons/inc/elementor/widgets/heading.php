<?php
/**
 * Heading Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Heading Widget Class
 */
class Heading extends Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-heading';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'heading' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'heading' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Heading', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-heading ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'heading', 'title', 'text' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Section content.
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Heading', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Heading', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your heading', 'avalon-addons' ),
				'default'     => esc_html__( 'Add Your Heading Text Here', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => esc_html__( 'Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'avalon-addons' ),
				'default'     => [
					'url' => '',
				],
			]
		);

		$this->register_text_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .avalon-heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .avalon-heading',
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-heading' => 'color: {{VALUE}}; --color-link: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_hover',
			[
				'label'     => esc_html__( 'Color Hover', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-heading' => '--color-link-hover: {{VALUE}};',
				],
				'condition' => [
					'link[url]!' => '',
				],
			]
		);

		$this->add_control(
			'clip_heading',
			[
				'label' => esc_html__( 'Clip heading by vertical', 'avalon-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_responsive_control(
			'clip_heading_height',
			[
				'label'      => esc_html__( 'Clip height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-heading' => 'max-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'clip_heading' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['heading'] ) ) {
			return;
		}

		$this->add_render_attribute( 'heading', 'class', [ 'avalon-heading', 'my-0', ! empty( $settings['clip_heading'] ) ? 'overflow-hidden' : '' ] );

		$this->add_inline_editing_attributes( 'heading' );

		$this->text_render(
			$settings['heading'],
			[
				'tag'        => $settings['html_tag'],
				'size'       => $settings['size'],
				'attr'       => 'heading',
				'linebreaks' => $settings['linebreaks'],
			],
			$settings['link'] ?? [],
		);
	}
}
