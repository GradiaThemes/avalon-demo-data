<?php
/**
 * Services Showcase Widget
 *
 * Displays services in a vertical scroll-pinned layout with background images,
 * animated titles, descriptions, and buttons.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;
use AvalonAddons\Elementor\Widgets\Base;

/**
 * Services Showcase Widget Class
 */
class Services_Showcase extends Widget_Base {

	use Base\Text_Base;
	use Base\Button_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-services-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'services-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'services-showcase' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Services Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-single-post ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'services', 'showcase', 'scroll', 'pinned' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Heading', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter heading', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__( 'Items', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'avalon-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::WYSIWYG,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$this->register_button_controls( '', $repeater );

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'image'       => [],
						'title'       => esc_html__( 'Service 1', 'avalon-addons' ),
						'description' => esc_html__( 'Description for service 1.', 'avalon-addons' ),
					],
					[
						'image'       => [],
						'title'       => esc_html__( 'Service 2', 'avalon-addons' ),
						'description' => esc_html__( 'Description for service 2.', 'avalon-addons' ),
					],
					[
						'image'       => [],
						'title'       => esc_html__( 'Service 3', 'avalon-addons' ),
						'description' => esc_html__( 'Description for service 3.', 'avalon-addons' ),
					],
				],
			]
		);

		$this->add_control(
			'title_settings_heading',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->register_text_controls(
			[
				'html_tag' => 'span',
				'size'     => '',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_general_style',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-services-showcase' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-services-showcase' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_typography_style',
			[
				'label' => esc_html__( 'Typography', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_style_heading',
			[
				'label' => esc_html__( 'Heading', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .avalon-services-showcase__heading',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-services-showcase__heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_style_heading',
			[
				'label'     => esc_html__( 'Title List', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-services-showcase__title-item',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-services-showcase__title-item' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-services-showcase__title-item.is-active' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_center_style_heading',
			[
				'label'     => esc_html__( 'Title Center', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_center_typography',
				'selector' => '{{WRAPPER}} .avalon-services-showcase__titles-center .avalon-services-showcase__title > *, {{WRAPPER}} .avalon-services-showcase__right .avalon-services-showcase__title > *',
			]
		);

		$this->add_control(
			'title_center_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-services-showcase__titles-center .avalon-services-showcase__title > *' => 'color: {{VALUE}};',
					'{{WRAPPER}} .avalon-services-showcase__right .avalon-services-showcase__title > *' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-services-showcase__descs > div',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-services-showcase__descs > div' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_image_style',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-services-showcase__image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-services-showcase__image img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Example: 16/9', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-services-showcase__image img' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-services-showcase__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['items'] ?? [];
		$count    = count( $items );

		if ( empty( $items ) || $count < 2 ) {
			return;
		}

		$this->render_services( $settings, $items, $count );
	}

	/**
	 * Render the services showcase layout.
	 *
	 * @param array $settings Widget settings.
	 * @param array $items    Repeater items.
	 * @param int   $count    Number of items.
	 */
	private function render_services( array $settings, array $items, int $count ) {
		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-services-showcase',
				'relative',
				'h-screen',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute( 'wrapper', 'data-count', esc_attr( $count ) );

		$this->add_render_attribute(
			'images',
			'class',
			[
				'avalon-services-showcase__images',
				'absolute',
				'inset-0',
			]
		);

		$this->add_render_attribute(
			'overlay',
			'class',
			[
				'avalon-services-showcase__overlay',
				'absolute',
				'inset-0',
				'z-3',
				'flex',
			]
		);

		$this->add_render_attribute(
			'left',
			'class',
			[
				'avalon-services-showcase__left',
				'w-1/2',
				'hidden',
				'md:flex',
				'flex-col',
				'gap-10',
				'justify-end',
				'px-4',
				'py-10',
				'md:px-10',
				'pointer-events-auto',
			]
		);

		$this->add_render_attribute(
			'right',
			'class',
			[
				'avalon-services-showcase__right',
				'w-full',
				'md:w-1/2',
				'relative',
				'px-4',
				'py-10',
				'md:px-10',
				'pointer-events-auto',
				'flex',
				'flex-col',
				'justify-between',
				'md:items-end',
			]
		);

		$this->add_render_attribute(
			'titles',
			'class',
			[
				'avalon-services-showcase__titles',
				'flex',
				'flex-col',
				'gap-1',
			]
		);

		$this->add_render_attribute(
			'titles_mobile',
			'class',
			[
				'avalon-services-showcase__title',
				'grid',
				'grid-area-1',
				'md:hidden',
			]
		);

		$this->add_render_attribute(
			'descs',
			'class',
			[
				'avalon-services-showcase__descs',
				'grid',
				'grid-area-1',
				'md:mt-30',
				'text-body-4',
			]
		);

		$this->add_render_attribute(
			'buttons',
			'class',
			[
				'avalon-services-showcase__buttons',
				'grid',
				'grid-area-1',
			]
		);

		$this->add_render_attribute(
			'titles_center',
			'class',
			[
				'avalon-services-showcase__titles-center',
				'absolute',
				'bottom-4',
				'md:bottom-10',
				'left-1/2',
				'-translate-x-1/2',
				'z-3',
				'hidden',
				'md:block',
			]
		);

		$this->add_render_attribute(
			'title_collection',
			'class',
			[
				'avalon-services-showcase__title',
				'grid',
				'grid-area-1',
				'text-center',
			]
		);

		$this->add_render_attribute(
			'heading',
			'class',
			[
				'avalon-services-showcase__heading',
				'my-0',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'images' ); ?>>
				<?php foreach ( $items as $index => $item ) : ?>
					<?php
					$image     = $item['image'] ?? [];
					$image_id  = $image['id'] ?? 0;
					$image_url = $image['url'] ?? '';
					$has_image = ! empty( $image_id ) || ! empty( $image_url );
					?>
					<?php if ( $has_image ) : ?>
					<figure class="avalon-services-showcase__image absolute inset-0 ratio-image <?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
							<?php
							if ( $image_id ) {
								echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									$image_id,
									'full',
									false,
									[
										'loading' => 0 === $index ? 'eager' : 'lazy',
									]
								);
							} else {
								printf(
									'<img src="%1$s" alt="%2$s" loading="%3$s" />',
									esc_url( $image_url ),
									esc_attr( Control_Media::get_image_alt( $image ) ),
									esc_attr( 0 === $index ? 'eager' : 'lazy' ),
								);
							}
							?>
						</figure>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>

			<div <?php $this->print_render_attribute_string( 'overlay' ); ?>>
				<div <?php $this->print_render_attribute_string( 'left' ); ?>>
					<?php if ( ! empty( $settings['heading'] ) ) : ?>
						<h2 class="avalon-services-showcase__heading text-body-4 my-0">
							<?php echo wp_kses_post( nl2br( $settings['heading'] ) ); ?>
						</h2>
					<?php endif; ?>

					<div <?php $this->print_render_attribute_string( 'titles' ); ?>>
						<?php foreach ( $items as $index => $item ) : ?>
							<span class="avalon-services-showcase__title-item text-body-4 <?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
								<?php echo wp_kses_post( $item['title'] ?? '' ); ?>
							</span>
						<?php endforeach; ?>
					</div>
				</div>

				<div <?php $this->print_render_attribute_string( 'right' ); ?>>

					<div <?php $this->print_render_attribute_string( 'titles_mobile' ); ?>>
						<?php foreach ( $items as $index => $item ) : ?>
							<?php
							$this->text_render(
								$item['title'] ?? '',
								[
									'tag'        => $settings['html_tag'] ?? 'span',
									'size'       => 'h4',
									'class'      => [
										'my-0',
										0 === $index ? 'is-active' : '',
									],
									'attr'       => 'title_center_' . $index,
									'linebreaks' => 'no',
								]
							);
							?>
						<?php endforeach; ?>
					</div>

					<div <?php $this->print_render_attribute_string( 'descs' ); ?>>
						<?php foreach ( $items as $index => $item ) : ?>
							<div class="<?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
								<?php echo wp_kses_post( $item['description'] ?? '' ); ?>
							</div>
						<?php endforeach; ?>
					</div>

					<div <?php $this->print_render_attribute_string( 'buttons' ); ?>>
						<?php foreach ( $items as $index => $item ) : ?>
							<div class="<?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
								<?php $this->button_render( $item ); ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

			<div <?php $this->print_render_attribute_string( 'titles_center' ); ?>>
				<div <?php $this->print_render_attribute_string( 'title_collection' ); ?>>
					<?php foreach ( $items as $index => $item ) : ?>
						<?php
						$this->text_render(
							$item['title'] ?? '',
							[
								'tag'        => $settings['html_tag'] ?? 'span',
								'size'       => 'h2',
								'class'      => [
									'my-0',
									0 === $index ? 'is-active' : '',
								],
								'attr'       => 'title_center_' . $index,
								'linebreaks' => 'no',
							]
						);
						?>
					<?php endforeach; ?>
				</div>
			</div>
			</div>
		</div>
		<?php
	}
}
