<?php
/**
 * Menu Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Menu Widget Class
 */
class Menu extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-menu';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'menu' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'menu' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Menu', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-nav-menu ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'menu', 'nav', 'navigation' ];
	}

	/**
	 * Get menu options
	 *
	 * @return array
	 */
	private function get_menu_options() {
		$menus = get_terms(
			[
				'taxonomy'   => 'nav_menu',
				'hide_empty' => false,
			]
		);

		$options = [];

		if ( ! empty( $menus ) && ! is_wp_error( $menus ) ) {
			foreach ( $menus as $menu ) {
				$options[ $menu->slug ] = $menu->name;
			}
		}

		return $options;
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Menu', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'menu_selected',
			[
				'label'       => esc_html__( 'Select Menu', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => $this->get_menu_options(),
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'avalon-addons' ),
					'glass'   => esc_html__( 'Floating Glass', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'menu_depth',
			[
				'label'       => esc_html__( 'Menu Depth', 'avalon-addons' ),
				'description' => esc_html__( '0 = unlimited depth, 1 = parent only, 2 = parent + children, etc.', 'avalon-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 10,
				'step'        => 1,
				'default'     => 0,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'menu_class',
			[
				'label'       => esc_html__( 'Custom Menu Class', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'my-custom-class', 'avalon-addons' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['menu_selected'] ) ) {
			return;
		}

		$container_class = 'main-navigation primary-navigation main-navigation--elementor pointer-events-none text-center main-navigation--' . esc_attr( $settings['style'] );

		$menu_class = 'menu nav-menu main-menu pointer-events-auto';
		if ( ! empty( $settings['menu_class'] ) ) {
			$menu_class .= ' ' . esc_attr( $settings['menu_class'] );
		}

		$nav_menu_args = [
			'menu'            => esc_attr( $settings['menu_selected'] ),
			'menu_class'      => $menu_class,
			'depth'           => ! empty( $settings['menu_depth'] ) ? absint( $settings['menu_depth'] ) : 0,
			'container'       => 'nav',
			'container_class' => $container_class,
			'fallback_cb'     => false,
			'echo'            => true,
		];

		wp_nav_menu( $nav_menu_args );
	}
}
