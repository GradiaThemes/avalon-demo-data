<?php
/**
 * Hero Showcase Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Hero Showcase Widget Class
 */
class Hero_Showcase extends Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-hero-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'hero-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'hero-showcase' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Hero Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-single-page ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'hero', 'showcase', 'video', 'banner' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'main_text',
			[
				'label'       => esc_html__( 'Main Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your main text', 'avalon-addons' ),
				'description' => esc_html__( 'Rendered in a transparent color so the media below shows through.', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->register_text_controls();

		$this->add_control(
			'left_text',
			[
				'label'       => esc_html__( 'Left Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter left text', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->add_control(
			'right_text',
			[
				'label'       => esc_html__( 'Right Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter right text', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->add_control(
			'sub_description',
			[
				'label'       => esc_html__( 'Text Below Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter text below the description', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'media_section',
			[
				'label' => esc_html__( 'Media', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'media_type',
			[
				'label'   => esc_html__( 'Media Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image' => esc_html__( 'Image', 'avalon-addons' ),
					'video' => esc_html__( 'Video', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => [
					'url' => '',
				],
				'condition'   => [
					'media_type' => 'image',
				],
				'description' => esc_html__( 'Shown behind the text block.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'insert_url',
			[
				'label'     => esc_html__( 'External URL', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'hosted_url',
			[
				'label'       => esc_html__( 'Choose Video File', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => [ 'video' ],
				'condition'   => [
					'media_type' => 'video',
					'insert_url' => '',
				],
				'description' => esc_html__( 'Autoplays muted and loops while the text block slides up.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'external_url',
			[
				'label'       => esc_html__( 'Video URL', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com/video.mp4', 'avalon-addons' ),
				'condition'   => [
					'media_type' => 'video',
					'insert_url' => 'yes',
				],
			]
		);

		$this->add_control(
			'start',
			[
				'label'       => esc_html__( 'Start Time', 'avalon-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify a start time (in seconds)', 'avalon-addons' ),
				'condition'   => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'end',
			[
				'label'       => esc_html__( 'End Time', 'avalon-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify an end time (in seconds)', 'avalon-addons' ),
				'condition'   => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'video_options',
			[
				'label'     => esc_html__( 'Video Options', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => esc_html__( 'Autoplay', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'play_on_mobile',
			[
				'label'     => esc_html__( 'Play On Mobile', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'media_type' => 'video',
					'autoplay'   => 'yes',
				],
			]
		);

		$this->add_control(
			'mute',
			[
				'label'     => esc_html__( 'Mute', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'     => esc_html__( 'Loop', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'controls',
			[
				'label'     => esc_html__( 'Player Controls', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'avalon-addons' ),
				'label_on'  => esc_html__( 'Show', 'avalon-addons' ),
				'default'   => 'yes',
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'download_button',
			[
				'label'     => esc_html__( 'Download Button', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'avalon-addons' ),
				'label_on'  => esc_html__( 'Show', 'avalon-addons' ),
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'preload',
			[
				'label'     => esc_html__( 'Preload', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'metadata' => esc_html__( 'Metadata', 'avalon-addons' ),
					'auto'     => esc_html__( 'Auto', 'avalon-addons' ),
					'none'     => esc_html__( 'None', 'avalon-addons' ),
				],
				'default'   => 'metadata',
				'condition' => [
					'media_type' => 'video',
					'autoplay'   => '',
				],
			]
		);

		$this->add_control(
			'poster',
			[
				'label'     => esc_html__( 'Poster', 'avalon-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'media_type' => 'video',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'       => esc_html__( 'Height', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'vh', '%', 'custom' ],
				'default'     => [
					'unit' => 'custom',
					'size' => '100svh',
				],
				'selectors'   => [
					'{{WRAPPER}} .avalon-hero-showcase' => '--hero-height: {{SIZE}}{{UNIT}};',
				],
				'description' => esc_html__( 'Set the widget height on desktop only.', 'avalon-addons' ),
			]
		);

		$this->add_responsive_control(
			'media_ratio',
			[
				'label'       => esc_html__( 'Media Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '4 / 3',
				'description' => esc_html__( 'Media ratio below desktop, where the text sits under the media. Example: 4 / 3', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-hero-showcase__media' => '--hero-media-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_bg_color',
			[
				'label'     => esc_html__( 'Text Block Background', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f4f4f4',
				'selectors' => [
					'{{WRAPPER}} .avalon-hero-showcase__text' => '--hero-text-bg: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_bg_opacity',
			[
				'label'      => esc_html__( 'Text Block Background Opacity', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 90,
				],
				'selectors'  => [
					'{{WRAPPER}} .avalon-hero-showcase__text' => '--hero-text-bg-opacity: {{SIZE}}%;',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_text_style',
			[
				'label' => esc_html__( 'Text', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_container',
			[
				'label'   => esc_html__( 'Text Container', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'container--fluid',
				'options' => [
					'container--narrow' => esc_html__( 'Container (Narrow)', 'avalon-addons' ),
					'container--fluid'  => esc_html__( 'Container (Fluid)', 'avalon-addons' ),
					'container--full'   => esc_html__( 'Container (Full No Spacing)', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'main_heading',
			[
				'label' => esc_html__( 'Main Text', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'main_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .avalon-hero-showcase__main' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'main_typography',
				'selector' => '{{WRAPPER}} .avalon-hero-showcase__main',
			]
		);

		$this->add_responsive_control(
			'main_margin',
			[
				'label'      => esc_html__( 'Margin', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-hero-showcase__main' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'side_heading',
			[
				'label'     => esc_html__( 'Left / Right Text', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'side_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-hero-showcase__row' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'side_typography',
				'selector' => '{{WRAPPER}} .avalon-hero-showcase__row',
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-hero-showcase__desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-hero-showcase__desc',
			]
		);

		$this->add_control(
			'sub_heading',
			[
				'label'     => esc_html__( 'Text Below Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sub_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-hero-showcase__sub' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sub_typography',
				'selector' => '{{WRAPPER}} .avalon-hero-showcase__sub',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-hero-showcase',
				'relative',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute(
			'media',
			'class',
			[
				'avalon-hero-showcase__media',
				'w-full',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute(
			'text',
			'class',
			[
				'avalon-hero-showcase__text',
				'absolute',
				'inset-0',
				'z-1',
				'flex',
				'flex-col',
				'justify-center',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'media' ); ?>>
				<?php $this->render_media( $settings ); ?>
			</div>
			<div <?php $this->print_render_attribute_string( 'text' ); ?>>
				<div class="<?php echo ! empty( $settings['text_container'] ) ? esc_attr( $settings['text_container'] ) : 'container--fluid'; ?>">
					<?php if ( ! empty( $settings['main_text'] ) || ! empty( $settings['left_text'] ) || ! empty( $settings['right_text'] ) ) { ?>
					<div class="avalon-hero-showcase__row grid grid-cols-1 items-center gap-3 lg:grid-cols-12">
						<?php if ( ! empty( $settings['left_text'] ) ) { ?>
							<div class="avalon-hero-showcase__left text-center text-body-4 lg:text-left lg:col-span-2 text-subtle"><?php echo esc_html( $settings['left_text'] ); ?></div>
						<?php } ?>
						<?php if ( ! empty( $settings['main_text'] ) ) { ?>
							<div class="avalon-hero-showcase__center text-center lg:col-span-8">
								<?php
								$this->add_inline_editing_attributes( 'main_text' );
								$this->text_render(
									$settings['main_text'],
									[
										'tag'        => $settings['html_tag'],
										'size'       => $settings['size'],
										'attr'       => 'main_text',
										'class'      => [ 'avalon-hero-showcase__main', 'my-4' ],
										'linebreaks' => $settings['linebreaks'],
									]
								);
								?>
							</div>
						<?php } ?>
						<?php if ( ! empty( $settings['right_text'] ) ) { ?>
							<div class="avalon-hero-showcase__right text-center text-body-4 lg:text-right lg:col-span-2 text-subtle"><?php echo esc_html( $settings['right_text'] ); ?></div>
						<?php } ?>
					</div>
					<?php } ?>

					<?php if ( ! empty( $settings['description'] ) || ! empty( $settings['sub_description'] ) ) { ?>
					<div class="avalon-hero-showcase__footer absolute inset-x-0 bottom-0 flex flex-col gap-4 md:gap-8 p-4 md:p-12 text-center font-regular">
						<?php if ( ! empty( $settings['description'] ) ) { ?>
							<div class="avalon-hero-showcase__desc text-body-1 font-regular sm:no-br">
								<?php echo wp_kses_post( nl2br( $settings['description'] ) ); ?>
							</div>
						<?php } ?>
						<?php if ( ! empty( $settings['sub_description'] ) ) { ?>
							<div class="avalon-hero-showcase__sub text-body-4 text-subtle">
								<?php echo wp_kses_post( nl2br( $settings['sub_description'] ) ); ?>
							</div>
						<?php } ?>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the media block (image or self-hosted video).
	 *
	 * @param array $settings Widget settings.
	 */
	private function render_media( $settings ) {
		$type = $settings['media_type'] ?? 'image';

		if ( 'video' === $type ) {
			$this->render_hosted_video( $settings );
		}

		if ( 'image' === $type && ! empty( $settings['image']['url'] ) ) {
			$this->render_image( $settings['image'] );
		}
	}

	/**
	 * Render an image.
	 *
	 * @param array $image Media settings.
	 */
	private function render_image( $image ) {
		if ( ! empty( $image['id'] ) ) {
			echo wp_get_attachment_image(
				$image['id'],
				'full',
				false,
				[
					'title' => Control_Media::get_image_title( $image ),
					'alt'   => Control_Media::get_image_alt( $image ),
					'class' => 'object-cover',
				]
			);
		} else {
			printf(
				'<img src="%1$s" title="%2$s" alt="%3$s" loading="lazy" class="object-cover" />',
				esc_url( $image['url'] ),
				esc_attr( Control_Media::get_image_title( $image ) ),
				esc_attr( Control_Media::get_image_alt( $image ) )
			);
		}
	}

	/**
	 * Render a self-hosted video.
	 *
	 * @param array $settings Widget settings.
	 */
	private function render_hosted_video( $settings ) {
		$video_url = $this->get_hosted_video_url( $settings );

		if ( empty( $video_url ) ) {
			return;
		}

		$video_params = [];

		foreach ( [ 'autoplay', 'loop', 'controls' ] as $option_name ) {
			if ( ! empty( $settings[ $option_name ] ) ) {
				$video_params[ $option_name ] = '';
			}
		}

		if ( empty( $settings['autoplay'] ) && ! empty( $settings['preload'] ) ) {
			$video_params['preload'] = $settings['preload'];
		}

		if ( ! empty( $settings['mute'] ) ) {
			$video_params['muted'] = 'muted';
		}

		if ( ! empty( $settings['play_on_mobile'] ) ) {
			$video_params['playsinline'] = '';
		}

		if ( empty( $settings['download_button'] ) ) {
			$video_params['controlsList'] = 'nodownload';
		}

		if ( ! empty( $settings['poster']['url'] ) ) {
			$video_params['poster'] = $settings['poster']['url'];
		}

		/* Sometimes the video url is base64, therefore we use `esc_attr` in `src`. */
		?>
		<video class="avalon-hero-showcase__video" src="<?php echo esc_attr( $video_url ); ?>" <?php \Elementor\Utils::print_html_attributes( $video_params ); ?>></video>
		<?php
	}

	/**
	 * Get the hosted video URL (file or external URL) with start/end time.
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	private function get_hosted_video_url( $settings ) {
		if ( ! empty( $settings['insert_url'] ) ) {
			$video_url = ! empty( $settings['external_url']['url'] ) ? $settings['external_url']['url'] : '';
		} else {
			$video_url = ! empty( $settings['hosted_url']['url'] ) ? $settings['hosted_url']['url'] : '';
		}

		if ( empty( $video_url ) && ! empty( $settings['hosted_url']['id'] ) ) {
			$video_url = wp_get_attachment_url( $settings['hosted_url']['id'] );
		}

		if ( empty( $video_url ) ) {
			return '';
		}

		if ( ! empty( $settings['start'] ) || ! empty( $settings['end'] ) ) {
			$video_url .= '#t=';

			if ( ! empty( $settings['start'] ) ) {
				$video_url .= $settings['start'];
			}

			if ( ! empty( $settings['end'] ) ) {
				$video_url .= ',' . $settings['end'];
			}
		}

		return $video_url;
	}
}
