<?php
/**
 * Services Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Elementor\Group_Control_Image_Size;
use Elementor\Control_Media;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Services Widget Class
 */
class Services extends Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-services';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'services' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'services' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Services', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-single-post ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'services' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'general_section',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'number',
			[
				'label'   => esc_html__( 'Number', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'S01', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => esc_html__( 'Title', 'avalon-addons' ),
				'separator' => 'before',
			]
		);

		$this->register_text_controls();

		$this->add_control(
			'description',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => esc_html__( 'This is description', 'avalon-addons' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'thumbnail',
			[
				'label'     => esc_html__( 'Thumbnail', 'avalon-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'ratio_thumbnail',
			[
				'label'       => esc_html__( 'Thumbnail Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => esc_html__( 'Set the thumbnail ratio. Example: 16/9', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-services__thumbnail' => '--aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_section',
			[
				'label' => esc_html__( 'Services', 'avalon-addons' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'name_service',
			[
				'label' => esc_html__( 'Name Service', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'link_service',
			[
				'label' => esc_html__( 'Link Service', 'avalon-addons' ),
				'type'  => Controls_Manager::URL,
			]
		);

		$this->add_control(
			'services',
			[
				'label'   => esc_html__( 'Services', 'avalon-addons' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'name_service' => esc_html__( 'Service 1', 'avalon-addons' ),
					],
					[
						'name_service' => esc_html__( 'Service 2', 'avalon-addons' ),
					],
					[
						'name_service' => esc_html__( 'Service 3', 'avalon-addons' ),
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'header', 'class', [ 'avalon-services__header', 'grid', 'gap-x-3', 'gap-y-4', 'grid-cols-1', 'md:grid-cols-12', 'sticky', 'top-0', 'mb-4', 'z-2', 'bg-body' ] );
		$this->add_render_attribute( 'details', 'class', [ 'avalon-services__details', 'grid', 'gap-x-3', 'gap-y-4', 'grid-cols-1', 'md:grid-cols-12' ] );

		$this->add_render_attribute( 'number', 'class', [ 'avalon-services__number', 'h2', 'my-0', 'whitespace-nowrap' ] );
		$this->add_render_attribute( 'title', 'class', [ 'avalon-services__title', 'h2', 'my-0' ] );

		$this->add_render_attribute( 'description', 'class', [ 'avalon-services__description', 'text-body-3', 'sticky', 'bottom-0', 'self-start' ] );
		$this->add_render_attribute( 'services', 'class', [ 'avalon-services__services', 'flex', 'flex-col', 'gap-4' ] );
		$this->add_render_attribute( 'service', 'class', [ 'avalon-services__service', 'h5', 'my-0' ] );

		$this->add_render_attribute( 'thumbnail', 'class', [ 'avalon-services__thumbnail', 'overflow-hidden', 'ratio-image', 'rounded-lg', 'mt-16' ] );
		$this->add_render_attribute( 'thumbnail', 'data-animate', 'parallax' );
		$this->add_render_attribute( 'thumbnail', 'data-animate-selector', 'img' );

		$this->add_inline_editing_attributes( 'number' );
		$this->add_inline_editing_attributes( 'title' );
		?>
		<div <?php $this->print_render_attribute_string( 'header' ); ?>>
			<?php if ( ! empty( $settings['number'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'number' ); ?>><?php echo wp_kses_post( $settings['number'] ); ?></div>
			<?php endif; ?>

			<?php
			if ( ! empty( $settings['title'] ) ) {
				$this->text_render(
					$settings['title'],
					[
						'tag'        => $settings['html_tag'],
						'size'       => $settings['size'],
						'attr'       => 'title',
						'linebreaks' => $settings['linebreaks'],
					]
				);
			}
			?>
		</div>

		<div <?php $this->print_render_attribute_string( 'details' ); ?>>
			<?php if ( ! empty( $settings['description'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'description' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['description'] ) ); ?>
				</div>
			<?php endif; ?>

			<div <?php $this->print_render_attribute_string( 'services' ); ?>>
				<?php
				if ( ! empty( $settings['services'] ) ) {
					foreach ( $settings['services'] as $key => $service ) {
						$key_link = $this->get_repeater_setting_key( 'link_service', 'services', $key );
						?>
							<div <?php $this->print_render_attribute_string( 'service' ); ?>>
								<?php if ( ! empty( $service['link_service']['url'] ) ) : ?>
									<?php $this->add_link_attributes( $key_link, $service['link_service'] ); ?>
									<a <?php $this->print_render_attribute_string( $key_link ); ?>>
								<?php endif; ?>

									<?php
									if ( ! empty( $service['name_service'] ) ) {
										echo wp_kses_post( $service['name_service'] );
									}
									?>

								<?php if ( ! empty( $service['link_service']['url'] ) ) : ?>
									</a>
								<?php endif; ?>
							</div>
						<?php
					}
				}
				?>
			</div>
		</div>

		<?php if ( ! empty( $settings['thumbnail']['url'] ) ) : ?>
		<div <?php $this->print_render_attribute_string( 'thumbnail' ); ?>>
			<?php
			if ( ! empty( $settings['thumbnail']['id'] ) ) {
				echo wp_get_attachment_image(
					$settings['thumbnail']['id'],
					'full',
					false,
					[
						'title' => Control_Media::get_image_title( $settings['thumbnail'] ),
						'alt'   => Control_Media::get_image_alt( $settings['thumbnail'] ),
					]
				);
			} else {
				printf(
					'<img src="%1$s" title="%2$s" alt="%3$s" loading="lazy" />',
					esc_url( $settings['thumbnail']['url'] ),
					esc_attr( Control_Media::get_image_title( $settings['thumbnail'] ) ),
					esc_attr( Control_Media::get_image_alt( $settings['thumbnail'] ) ),
				);
			}
			?>
		</div>
		<?php endif; ?>
		<?php
	}
}
