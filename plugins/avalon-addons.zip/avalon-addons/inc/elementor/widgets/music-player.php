<?php
/**
 * Music Player Widget
 *
 * Plays a single audio file (or an MP4 used as audio-only) behind a
 * "Sound On/Off" text + 5 equalizer bars. Clicking the widget toggles
 * playback. When scroll-controlled, playback follows the direct parent
 * container position in the viewport.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Music Player Widget Class
 */
class Music_Player extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-music-player';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'music-player' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'music-player' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Music Player', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-play ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'music', 'audio', 'sound', 'player', 'equalizer', 'bars' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// Content - Source.
		$this->start_controls_section(
			'source_section',
			[
				'label' => esc_html__( 'Source', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source_type',
			[
				'label'   => esc_html__( 'Source Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'media',
				'options' => [
					'media' => esc_html__( 'Media Library', 'avalon-addons' ),
					'url'   => esc_html__( 'External URL', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'media_file',
			[
				'label'       => esc_html__( 'Audio File', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => [ 'video' ],
				'description' => esc_html__( 'Upload an audio file, or an MP4 (only its audio will be played).', 'avalon-addons' ),
				'conditions'  => [
					'terms' => [
						[
							'name'  => 'source_type',
							'value' => 'media',
						],
					],
				],
			]
		);

		$this->add_control(
			'media_url',
			[
				'label'         => esc_html__( 'Audio URL', 'avalon-addons' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://example.com/audio.mp3', 'avalon-addons' ),
				'label_block'   => true,
				'show_external' => false,
				'auto_confirm'  => true,
				'conditions'    => [
					'terms' => [
						[
							'name'  => 'source_type',
							'value' => 'url',
						],
					],
				],
			]
		);

		$this->add_control(
			'sound_on_text',
			[
				'label'   => esc_html__( 'Sound On Text', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Sound on', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'sound_off_text',
			[
				'label'   => esc_html__( 'Sound Off Text', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Sound off', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'loop_enable',
			[
				'label'              => esc_html__( 'Loop', 'avalon-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'          => esc_html__( 'No', 'avalon-addons' ),
				'return_value'       => 'yes',
				'default'            => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'volume',
			[
				'label'              => esc_html__( 'Volume', 'avalon-addons' ),
				'type'               => Controls_Manager::SLIDER,
				'range'              => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'            => [
					'size' => 100,
				],
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		// Style - Content.
		$this->start_controls_section(
			'content_style_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_gap',
			[
				'label'      => esc_html__( 'Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-music-player' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_heading',
			[
				'label'     => esc_html__( 'Text', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_typography',
				'selector' => '{{WRAPPER}} .avalon-music-player__text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-music-player__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bars_heading',
			[
				'label'     => esc_html__( 'Equalizer Bars', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'bar_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-music-player__bars' => '--avalon-eq-bar-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'bar_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-music-player__bar' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'bar_gap',
			[
				'label'      => esc_html__( 'Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-music-player__bars' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'bar_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-music-player__bar' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'bar_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-music-player__bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'animation_speed',
			[
				'label'     => esc_html__( 'Animation Speed', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0.5,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-music-player__bar' => 'animation-duration: {{SIZE}}s;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$source_url = '';
		$mime       = '';

		if ( 'media' === $settings['source_type'] && ! empty( $settings['media_file']['url'] ) ) {
			$source_url = $settings['media_file']['url'];

			if ( ! empty( $settings['media_file']['mime_type'] ) ) {
				$mime = $settings['media_file']['mime_type'];
			}
		} elseif ( 'url' === $settings['source_type'] && ! empty( $settings['media_url']['url'] ) ) {
			$source_url = $settings['media_url']['url'];
		}

		if ( empty( $source_url ) ) {
			return;
		}

		$this->add_render_attribute(
			'wrapper',
			[
				'class'         => [
					'avalon-music-player',
					'avalon-elementor--music-player',
					'inline-flex',
					'items-center',
					'gap-2',
					'p-0',
					'text-emphasis',
					'is-off',
					'button--no-style',
				],
				'role'          => 'button',
				'tabindex'      => '0',
				'aria-pressed'  => 'false',
				'data-src'      => esc_url( $source_url ),
				'data-loop'     => ( 'yes' === ( $settings['loop_enable'] ?? 'yes' ) ) ? '1' : '0',
				'data-volume'   => (string) ( ( $settings['volume']['size'] ?? 100 ) / 100 ),
				'data-on-text'  => esc_attr( $settings['sound_on_text'] ?? '' ),
				'data-off-text' => esc_attr( $settings['sound_off_text'] ?? '' ),
			]
		);

		if ( $mime ) {
			$this->add_render_attribute( 'wrapper', 'data-mime', esc_attr( $mime ) );
		}

		?>
		<button <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $settings['sound_on_text'] ) && ! empty( $settings['sound_off_text'] ) ) : ?>
				<span class="avalon-music-player__text caption"><?php echo wp_kses_post( $settings['sound_off_text'] ); ?></span>
			<?php endif; ?>
			<span class="avalon-music-player__bars inline-flex items-center" aria-hidden="true">
				<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
					<span class="avalon-music-player__bar inline-block circle h-full" style="--avalon-eq-index: <?php echo (int) $i; ?>"></span>
				<?php endfor; ?>
			</span>
		</button>
		<?php
	}
}
