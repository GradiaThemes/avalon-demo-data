<?php
/**
 * Text Base
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

/**
 * Text Base Trait
 *
 * @mixin \Elementor\Widget_Base
 */
trait Text_Base {

	/**
	 * Get text size options (text-display, text-body, caption)
	 *
	 * @return array
	 */
	protected function get_text_size_options(): array {
		return [
			''               => esc_html__( 'Default', 'avalon-addons' ),
			'h1'             => esc_html__( 'Heading 1', 'avalon-addons' ),
			'h2'             => esc_html__( 'Heading 2', 'avalon-addons' ),
			'h3'             => esc_html__( 'Heading 3', 'avalon-addons' ),
			'h4'             => esc_html__( 'Heading 4', 'avalon-addons' ),
			'h5'             => esc_html__( 'Heading 5', 'avalon-addons' ),
			'h6'             => esc_html__( 'Heading 6', 'avalon-addons' ),
			'text-display-1' => esc_html__( 'Text Display 1', 'avalon-addons' ),
			'text-body-1'    => esc_html__( 'Text Body 1', 'avalon-addons' ),
			'text-body-2'    => esc_html__( 'Text Body 2', 'avalon-addons' ),
			'text-body-3'    => esc_html__( 'Text Body 3', 'avalon-addons' ),
			'text-body-4'    => esc_html__( 'Text Body 4', 'avalon-addons' ),
			'caption'        => esc_html__( 'Caption', 'avalon-addons' ),
		];
	}

	/**
	 * Get HTML tag options
	 *
	 * @return array
	 */
	protected function get_html_tag_options(): array {
		return [
			'h1'   => esc_html__( 'H1', 'avalon-addons' ),
			'h2'   => esc_html__( 'H2', 'avalon-addons' ),
			'h3'   => esc_html__( 'H3', 'avalon-addons' ),
			'h4'   => esc_html__( 'H4', 'avalon-addons' ),
			'h5'   => esc_html__( 'H5', 'avalon-addons' ),
			'h6'   => esc_html__( 'H6', 'avalon-addons' ),
			'div'  => esc_html__( 'div', 'avalon-addons' ),
			'span' => esc_html__( 'span', 'avalon-addons' ),
			'p'    => esc_html__( 'p', 'avalon-addons' ),
		];
	}

	/**
	 * Register text controls.
	 *
	 * @param array  $defaults Defaults.
	 * @param object $control Control.
	 * @param string $prefix Control prefix.
	 */
	public function register_text_controls( $defaults = [], $control = null, $prefix = '' ) {
		if ( null === $control ) {
			$control = $this;
		}

		$control->add_control(
			$prefix . 'html_tag',
			[
				'label'   => esc_html__( 'HTML Tag', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_html_tag_options(),
				'default' => $defaults['html_tag'] ?? 'h2',
			]
		);

		$control->add_control(
			$prefix . 'size',
			[
				'label'   => esc_html__( 'Size', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_size_options(),
				'default' => $defaults['size'] ?? '',
			]
		);

		$control->add_control(
			$prefix . 'linebreaks',
			[
				'label'        => esc_html__( 'Disable line breaks on mobile', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'default'      => $defaults['linebreaks'] ?? 'yes',
			]
		);
	}

	/**
	 * Render text.
	 *
	 * @param string $text Text content.
	 * @param array  $args Render args: tag, size, class, attr, link_attr.
	 * @param array  $link Link settings (Controls_Manager::URL).
	 */
	protected function text_render( $text = '', $args = [], $link = [] ) {
		$defaults = [
			'tag'        => 'h2',
			'size'       => '',
			'class'      => [],
			'attr'       => 'heading',
			'linebreaks' => 'yes',
			'link_attr'  => 'link',
		];
		$args     = wp_parse_args( $args, $defaults );

		if ( empty( $text ) ) {
			return;
		}

		$this->add_render_attribute( $args['attr'], 'class', array_merge( (array) $args['class'], [ $args['size'] ] ) );

		if ( 'yes' === $args['linebreaks'] ) {
			$this->add_render_attribute( $args['attr'], 'class', [ 'sm:no-br' ] );
		}

		$has_link = ! empty( $link['url'] );
		if ( $has_link ) {
			$this->add_link_attributes( $args['link_attr'], $link );
		}

		$tag = $args['tag'];
		?>
		<<?php echo esc_attr( $tag ); ?> <?php $this->print_render_attribute_string( $args['attr'] ); ?>>
			<?php if ( $has_link ) { ?>
				<a <?php $this->print_render_attribute_string( $args['link_attr'] ); ?>><?php echo wp_kses_post( do_shortcode( nl2br( $text ) ) ); ?></a>
			<?php } else { ?>
				<?php echo wp_kses_post( do_shortcode( nl2br( $text ) ) ); ?>
			<?php } ?>
		</<?php echo esc_attr( $tag ); ?>>
		<?php
	}
}
