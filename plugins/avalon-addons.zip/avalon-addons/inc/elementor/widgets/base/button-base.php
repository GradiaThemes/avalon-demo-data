<?php
/**
 * Button Base
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

/**
 * Button Base Class
 *
 * @mixin \Elementor\Widget_Base
 */
trait Button_Base {

	/**
	 * Register button controls.
	 *
	 * @param string $prefix Control prefix.
	 * @param object $control Control.
	 */
	public function register_button_controls( $prefix = '', $control = null ) {
		if ( null === $control ) {
			$control = $this;
		}

		$control->add_control(
			$prefix . 'button_type',
			[
				'label'   => esc_html__( 'Button Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'text',
				'options' => [
					'text' => esc_html__( 'Text', 'avalon-addons' ),
					'icon' => esc_html__( 'Icon', 'avalon-addons' ),
				],
			]
		);

		$control->add_control(
			$prefix . 'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Click Here', 'avalon-addons' ),
				'placeholder' => esc_html__( 'Enter button text', 'avalon-addons' ),
				'label_block' => true,
				'condition'   => [
					$prefix . 'button_type' => 'text',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_icon',
			[
				'label'       => esc_html__( 'Icon', 'avalon-addons' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition'   => [
					$prefix . 'button_type' => 'icon',
				],
				'label_block' => true,
			]
		);

		$control->add_control(
			$prefix . 'button_link',
			[
				'label'       => esc_html__( 'Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'avalon-addons' ),
				'default'     => [
					'url' => '',
				],
			]
		);
	}

	/**
	 * Register button style controls.
	 *
	 * @param string $prefix Prefix.
	 * @param object $control Control.
	 */
	protected function register_button_controls_style( $prefix = '', $control = null ) {
		if ( ! $control ) {
			$control = $this;
		}

		$control->add_control(
			$prefix . 'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-button' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => $prefix . 'button_typography',
				'selector' => '{{WRAPPER}} .avalon-button',
			]
		);

		$control->add_control(
			$prefix . 'button_shadow_hide',
			[
				'label'     => esc_html__( 'Hide Shadow', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'{{WRAPPER}} .avalon-button' => '--button-shadow: none; --button-shadow-hover: none;',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-button' => '--button-color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_shadow_hide' => 'yes',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-button' => '--button-bg-color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_shadow_hide' => 'yes',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-button' => '--button-color-hover: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_shadow_hide' => 'yes',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_background_color_hover',
			[
				'label'     => esc_html__( 'Hover Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-button' => '--button-bg-color-hover: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_shadow_hide' => 'yes',
				],
			]
		);

		$control->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'      => $prefix . 'button_border',
				'selector'  => '{{WRAPPER}} .avalon-button',
				'condition' => [
					$prefix . 'button_shadow_hide' => 'yes',
				],
			]
		);
	}

	/**
	 * Render button.
	 *
	 * @param array  $settings Settings.
	 * @param string $prefix Prefix.
	 * @param string $classes Classes.
	 */
	protected function button_render( $settings = [], $prefix = '', $classes = null ) {
		if ( empty( $settings ) ) {
			$settings = $this->get_settings_for_display();
		}

		if ( 'icon' === $settings[ $prefix . 'button_type' ] ) {
			$this->button_icon( $settings, $prefix, $classes );
		} else {
			$this->button_text( $settings, $prefix, $classes );
		}
	}

	/**
	 * Render button text.
	 *
	 * @param array  $settings Settings.
	 * @param string $prefix Prefix.
	 * @param string $classes Classes.
	 */
	protected function button_text( $settings = [], $prefix = '', $classes = null ) {
		$settings_defaults = $this->get_settings_for_display();

		if ( empty( $settings ) ) {
			$settings = $this->get_settings_for_display();
		}

		if ( empty( $settings[ $prefix . 'button_text' ] ) ) {
			return;
		}

		$button_class = 'avalon-button ' . ( $classes ? esc_attr( $classes ) : '' );

		if ( ! empty( $settings[ $prefix . 'button_style' ] ) ) {
			$button_class .= ' ' . esc_attr( $settings[ $prefix . 'button_style' ] );
		} elseif ( ! empty( $settings_defaults[ $prefix . 'button_style' ] ) ) {
			$button_class .= ' ' . esc_attr( $settings_defaults[ $prefix . 'button_style' ] );
		}

		$this->add_render_attribute( $prefix . 'button', [ 'class' => $button_class ] );

		if ( ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ) {
			$this->add_link_attributes( $prefix . 'button', $settings[ $prefix . 'button_link' ] );
		}

		$tag = ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ? 'a' : 'button';

		?>
		<<?php echo esc_attr( $tag ); ?> <?php $this->print_render_attribute_string( $prefix . 'button' ); ?>>
			<span class="button__text"><?php echo esc_html( $settings[ $prefix . 'button_text' ] ); ?></span>
		</<?php echo esc_attr( $tag ); ?>>
		<?php
	}

	/**
	 * Render button icon.
	 *
	 * @param array  $settings Settings.
	 * @param string $prefix Prefix.
	 * @param string $classes Classes.
	 */
	protected function button_icon( $settings = [], $prefix = '', $classes = null ) {
		$settings_defaults = $this->get_settings_for_display();

		if ( empty( $settings ) ) {
			$settings = $this->get_settings_for_display();
		}

		if ( empty( $settings[ $prefix . 'button_icon' ]['value'] ) ) {
			return;
		}

		$button_class = 'avalon-button button-icon ' . ( $classes ? esc_attr( $classes ) : '' );

		if ( ! empty( $settings[ $prefix . 'button_style' ] ) ) {
			$button_class .= ' ' . esc_attr( $settings[ $prefix . 'button_style' ] );
		} elseif ( ! empty( $settings_defaults[ $prefix . 'button_style' ] ) ) {
			$button_class .= ' ' . esc_attr( $settings_defaults[ $prefix . 'button_style' ] );
		}

		$this->add_render_attribute( $prefix . 'button', [ 'class' => $button_class ] );

		if ( ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ) {
			$this->add_link_attributes( $prefix . 'button', $settings[ $prefix . 'button_link' ] );
		}

		$tag = ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ? 'a' : 'button';

		?>
		<<?php echo esc_attr( $tag ); ?> <?php $this->print_render_attribute_string( $prefix . 'button' ); ?>>
			<span class="avalon-svg-icon">
			<?php
			\Elementor\Icons_Manager::render_icon(
				$settings[ $prefix . 'button_icon' ],
				[
					'aria-hidden' => 'true',
					'fill'        => 'currentColor',
				]
			);
			?>
			</span>
		</<?php echo esc_attr( $tag ); ?>>
		<?php
	}
}
