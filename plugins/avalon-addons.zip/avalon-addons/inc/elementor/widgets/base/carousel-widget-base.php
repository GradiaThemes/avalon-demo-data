<?php
/**
 * Carousel Widget Base
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use AvalonAddons\Helper;

/**
 * Carousel Widget Base Class
 */
abstract class Carousel_Widget_Base extends Widget_Base {

	/**
	 * Default controls
	 *
	 * @var array
	 */
	protected $default_controls = [
		'effect'             => 'slide',
		'slides_per_view'    => [
			'desktop' => 1,
			'tablet'  => 1,
			'mobile'  => 1,
		],
		'space_between'      => [
			'desktop' => 20,
			'tablet'  => 20,
			'mobile'  => 12,
		],
		'navigation'         => 'arrows',
		'autoplay'           => '',
		'autoplay_speed'     => 3000,
		'speed'              => 800,
		'infinite'           => '',
		'show_side_overflow' => '',
		'centered_slides'    => '',
	];

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [];
	}

	/**
	 * Register carousel controls.
	 *
	 * @param array $supported_controls Supported controls.
	 * @param bool  $hidden           Is hidden.
	 */
	protected function register_carousel_controls( $supported_controls = [], $hidden = false ) {
		$carousel_controls = array_merge(
			$this->default_controls,
			$this->get_carousel_controls()
		);

		$supported_controls = empty( $supported_controls ) ? [
			'effect',
			'slides_per_view',
			'space_between',
			'navigation',
			'autoplay',
			'autoplay_speed',
			'speed',
			'infinite',
			'show_side_overflow',
		] : $supported_controls;

		foreach ( $supported_controls as $index => $option ) {

			if ( 'effect' === $option ) {
				$this->add_control(
					'effect',
					[
						'label'   => esc_html__( 'Effect', 'avalon-addons' ),
						'type'    => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SELECT,
						'default' => $carousel_controls[ $option ],
						'options' => [
							'slide' => esc_html__( 'Slide', 'avalon-addons' ),
							'fade'  => esc_html__( 'Fade', 'avalon-addons' ),
						],
					]
				);
			}

			if ( 'slides_per_view' === $option ) {
				$this->add_responsive_control(
					'slides_per_view',
					[
						'label'          => esc_html__( 'Slides to Show', 'avalon-addons' ),
						'type'           => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::NUMBER,
						'min'            => 1,
						'max'            => 50,
						'step'           => 1,
						'default'        => ! empty( $carousel_controls[ $option ]['desktop'] ) ? $carousel_controls[ $option ]['desktop'] : 1,
						'tablet_default' => ! empty( $carousel_controls[ $option ]['tablet'] ) ? $carousel_controls[ $option ]['tablet'] : 1,
						'mobile_default' => ! empty( $carousel_controls[ $option ]['mobile'] ) ? $carousel_controls[ $option ]['mobile'] : 1,
					]
				);
			}

			if ( 'space_between' === $option ) {
				$this->add_responsive_control(
					'space_between',
					[
						'label'          => esc_html__( 'Space Between', 'avalon-addons' ),
						'type'           => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::NUMBER,
						'min'            => 0,
						'max'            => 200,
						'default'        => ! empty( $carousel_controls[ $option ]['desktop'] ) ? $carousel_controls[ $option ]['desktop'] : 20,
						'tablet_default' => ! empty( $carousel_controls[ $option ]['tablet'] ) ? $carousel_controls[ $option ]['tablet'] : 20,
						'mobile_default' => ! empty( $carousel_controls[ $option ]['mobile'] ) ? $carousel_controls[ $option ]['mobile'] : 12,
					]
				);
			}

			if ( 'navigation' === $option ) {
				$this->add_responsive_control(
					'navigation',
					[
						'label'          => esc_html__( 'Navigation', 'avalon-addons' ),
						'type'           => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SELECT,
						'options'        => [
							'arrows' => esc_html__( 'Arrows', 'avalon-addons' ),
							'both'   => esc_html__( 'Arrows + Fraction', 'avalon-addons' ),
							'none'   => esc_html__( 'None', 'avalon-addons' ),
						],
						'default'        => $carousel_controls[ $option ],
						'tablet_default' => 'arrows',
						'mobile_default' => 'arrows',
						'prefix_class'   => 'gt-swiper-navigation%s-',
					]
				);
			}

			if ( 'autoplay' === $option ) {
				$this->add_control(
					'autoplay',
					[
						'label'     => esc_html__( 'Autoplay', 'avalon-addons' ),
						'type'      => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SWITCHER,
						'label_off' => esc_html__( 'Off', 'avalon-addons' ),
						'label_on'  => esc_html__( 'On', 'avalon-addons' ),
						'default'   => $carousel_controls[ $option ],
					]
				);
			}

			if ( 'autoplay_speed' === $option ) {
				$this->add_control(
					'autoplay_speed',
					[
						'label'     => esc_html__( 'Autoplay Speed', 'avalon-addons' ),
						'type'      => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::NUMBER,
						'default'   => $carousel_controls[ $option ],
						'min'       => 100,
						'step'      => 50,
						'condition' => [
							'autoplay' => 'yes',
						],
					]
				);
			}

			if ( 'speed' === $option ) {
				$this->add_control(
					'speed',
					[
						'label'   => esc_html__( 'Animation Speed', 'avalon-addons' ),
						'type'    => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::NUMBER,
						'default' => $carousel_controls[ $option ],
						'min'     => 100,
						'step'    => 50,
					]
				);
			}

			if ( 'infinite' === $option ) {
				$this->add_control(
					'infinite',
					[
						'label'     => esc_html__( 'Infinite Loop', 'avalon-addons' ),
						'type'      => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SWITCHER,
						'label_off' => esc_html__( 'Off', 'avalon-addons' ),
						'label_on'  => esc_html__( 'On', 'avalon-addons' ),
						'default'   => $carousel_controls[ $option ],
					]
				);
			}

			if ( 'show_side_overflow' === $option ) {
				$this->add_control(
					'show_side_overflow',
					[
						'label'        => esc_html__( 'Show side overflow', 'avalon-addons' ),
						'type'         => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SWITCHER,
						'label_off'    => esc_html__( 'Hide', 'avalon-addons' ),
						'label_on'     => esc_html__( 'Show', 'avalon-addons' ),
						'default'      => $carousel_controls[ $option ],
						'prefix_class' => 'swiper-show-side-overflow-',
					]
				);
			}

			if ( 'centered_slides' === $option ) {
				$this->add_control(
					'centered_slides',
					[
						'label'     => esc_html__( 'Centered Slides', 'avalon-addons' ),
						'type'      => $hidden ? Controls_Manager::HIDDEN : Controls_Manager::SWITCHER,
						'label_off' => esc_html__( 'Off', 'avalon-addons' ),
						'label_on'  => esc_html__( 'On', 'avalon-addons' ),
						'default'   => $carousel_controls[ $option ],
					]
				);
			}
		}
	}

	/**
	 * Register carousel style controls.
	 */
	protected function register_carousel_style_controls() {
		$this->add_control(
			'arrows_show',
			[
				'label'        => esc_html__( 'Always show button', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Off', 'avalon-addons' ),
				'label_on'     => esc_html__( 'On', 'avalon-addons' ),
				'default'      => '',
				'return_value' => '1',
				'selectors'    => [
					'{{WRAPPER}} .swiper-button' => 'opacity: {{VALUE}}; margin-left: 0 !important; margin-right: 0 !important;',
				],
			]
		);

		$this->add_control(
			'arrows_style',
			[
				'label'   => esc_html__( 'Arrows Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button--white',
				'options' => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
			]
		);
	}

	/**
	 * Render arrows.
	 */
	protected function render_arrows() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="swiper-navigation">
			<button type="button" class="swiper-button swiper-button-prev button-icon <?php echo esc_attr( ! empty( $settings['arrows_style'] ) ? $settings['arrows_style'] : 'button--white' ); ?>" aria-label="<?php esc_attr_e( 'Previous', 'avalon-addons' ); ?>">
				<?php
				// phpcs:ignore
				echo Helper::get_svg( is_rtl() ? 'arrow-right' : 'arrow-left' );
				?>
			</button>
			<button type="button" class="swiper-button swiper-button-next button-icon <?php echo esc_attr( ! empty( $settings['arrows_style'] ) ? $settings['arrows_style'] : 'button--white' ); ?>" aria-label="<?php esc_attr_e( 'Next', 'avalon-addons' ); ?>">
				<?php
				// phpcs:ignore
				echo Helper::get_svg( is_rtl() ? 'arrow-left' : 'arrow-right' );
				?>
			</button>
		</div>
		<?php
	}

	/**
	 * Render the combined navigation layout: prev arrow + fraction + next arrow.
	 *
	 * The fraction element (`.swiper-pagination` with `data-type="fraction"`) is
	 * auto-detected by the gt-slider web component and rendered as `current / total`.
	 */
	protected function render_pagination() {
		?>
		<div class="swiper-pagination" data-type="fraction"></div>
		<?php
	}

	/**
	 * Render navigation custom.
	 */
	protected function render_navigation_custom() {}

	/**
	 * Print attributes.
	 *
	 * @param array $attributes Attributes.
	 */
	protected function print_attributes( array $attributes ) {
		foreach ( $attributes as $key => $value ) {
			if ( ! empty( $value ) ) {
				echo ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
			}
		}
	}

	/**
	 * Get attributes.
	 *
	 * @return array
	 */
	protected function get_attributes(): array {
		$settings          = $this->get_settings_for_display();
		$carousel_controls = array_merge(
			$this->default_controls,
			$this->get_carousel_controls()
		);
		$_attributes       = $this->get_manual_attributes();

		$slides_per_view = 1;
		$space_between   = 30;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view'] ) && ! empty( $carousel_controls['slides_per_view']['desktop'] ) ) {
				$slides_per_view = $carousel_controls['slides_per_view']['desktop'];
			}

			if ( empty( $settings['space_between'] ) && ! empty( $carousel_controls['space_between']['desktop'] ) ) {
				$space_between = $carousel_controls['space_between']['desktop'];
			}
		}

		$slides_per_view = ! empty( $settings['slides_per_view'] ) ? $settings['slides_per_view'] : $slides_per_view;
		$space_between   = ! empty( $settings['space_between'] ) ? $settings['space_between'] : $space_between;

		$slides_per_view_tablet = $slides_per_view;
		$space_between_tablet   = $space_between;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view_tablet'] ) && ! empty( $carousel_controls['slides_per_view']['tablet'] ) ) {
				$slides_per_view_tablet = $carousel_controls['slides_per_view']['tablet'];
			}

			if ( empty( $settings['space_between_tablet'] ) && ! empty( $carousel_controls['space_between']['tablet'] ) ) {
				$space_between_tablet = $carousel_controls['space_between']['tablet'];
			}
		}

		$slides_per_view_tablet = ! empty( $settings['slides_per_view_tablet'] ) ? $settings['slides_per_view_tablet'] : $slides_per_view_tablet;
		$space_between_tablet   = ! empty( $settings['space_between_tablet'] ) ? $settings['space_between_tablet'] : $space_between_tablet;

		$slides_per_view_mobile = $slides_per_view_tablet;
		$space_between_mobile   = $space_between_tablet;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view_mobile'] ) && ! empty( $carousel_controls['slides_per_view']['mobile'] ) ) {
				$slides_per_view_mobile = $carousel_controls['slides_per_view']['mobile'];
			}

			if ( empty( $settings['space_between_mobile'] ) && ! empty( $carousel_controls['space_between']['mobile'] ) ) {
				$space_between_mobile = $carousel_controls['space_between']['mobile'];
			}
		}

		$slides_per_view_mobile = ! empty( $settings['slides_per_view_mobile'] ) ? $settings['slides_per_view_mobile'] : $slides_per_view_mobile;
		$space_between_mobile   = ! empty( $settings['space_between_mobile'] ) ? $settings['space_between_mobile'] : $space_between_mobile;

		$autoplay = isset( $carousel_controls['autoplay'] ) && 'yes' === $carousel_controls['autoplay'] ? $carousel_controls['autoplay_speed'] : '';
		$autoplay = isset( $settings['autoplay'] ) && 'yes' === $settings['autoplay'] ? $settings['autoplay_speed'] : $autoplay;

		$loop = isset( $settings['infinite'] ) ? $settings['infinite'] : $carousel_controls['infinite'];

		if ( 'yes' === ( $settings['show_side_overflow'] ?? '' ) ) {
			$loop = 'fill';
		}

		return array_merge(
			$_attributes,
			[
				'effect'          => isset( $settings['effect'] ) ? $settings['effect'] : $carousel_controls['effect'],
				'slides-per-view' => $slides_per_view_mobile,
				'space-between'   => $space_between_mobile,
				'speed'           => isset( $settings['speed'] ) ? $settings['speed'] : $carousel_controls['speed'],
				'autoplay'        => $autoplay,
				'loop'            => $loop,
				'centered-slides' => isset( $settings['centered_slides'] ) ? $settings['centered_slides'] : $carousel_controls['centered_slides'],
				'breakpoints'     => esc_attr(
					wp_json_encode(
						[
							'768'  => [
								'slidesPerView' => $slides_per_view_tablet,
								'spaceBetween'  => $space_between_tablet,
							],
							'1024' => [
								'slidesPerView' => $slides_per_view,
								'spaceBetween'  => $space_between,
							],
						]
					)
				),
			]
		);
	}

	/**
	 * Get manual attributes.
	 *
	 * @return array
	 */
	protected function get_manual_attributes(): array {
		return [];
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [];
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {}

	/**
	 * Render carousel.
	 *
	 * @param string $html_tag Html tag.
	 * @param string $classes Classes.
	 * @param bool   $navigation Navigation.
	 */
	protected function render_carousel( string $html_tag = 'div', string $classes = '', $navigation = false ): void {
		$settings = $this->get_settings_for_display();
		$nav_mode = $settings['navigation'] ?? 'arrows';
		?>
		<gt-slider <?php $this->print_attributes( $this->get_attributes() ); ?>>
			<div class="swiper swiper--elementor <?php echo esc_attr( implode( ' ', $this->get_classes_swiper() ) ); ?>">
				<<?php echo esc_attr( $html_tag ); ?> class="swiper-wrapper <?php echo esc_attr( $classes ); ?>">
					<?php $this->render_items_carousel(); ?>
				</<?php echo esc_attr( $html_tag ); ?>>

				<?php if ( 'both' === $nav_mode ) : ?>
					<div class="avalon-swiper-controls flex items-center gap-6">
				<?php endif; ?>
					<?php $this->render_arrows(); ?>
					<?php $this->render_pagination(); ?>
				<?php if ( 'both' === $nav_mode ) : ?>
					</div>
				<?php endif; ?>
			</div>
		</gt-slider>
		<?php
	}
}
