<?php
/**
 * Hover Cursor Base
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;

/**
 * Hover Cursor Base Class
 *
 * Outputs theme-compatible `hover-cursor` markup consumed by the Avalon theme's
 * hover-cursor module (`assets/js/modules/hover-cursor.js`).
 *
 * The rendered cursor lives at the body level (`.avalon-cursor__inner`), which
 * is why style control selectors are scoped to `.avalon-cursor__inner` plus the
 * id-scoped wrapper class `avalon-hover-cursor__{prefix}{id}`.
 *
 * Widget usage:
 * - Register controls with {@see register_hover_cursor_controls()}.
 * - Render the hover-cursor attributes inside the content wrapper via
 *   {@see render_hover_cursor_attributes()}.
 * - Call {@see render_hover_cursor_template()} *inside* that same wrapper
 *   (a descendant `<template hover-cursor-image>` is required for the image type).
 *
 * @mixin \Elementor\Widget_Base
 */
trait Hover_Cursor_Base {

	/**
	 * Register hover cursor content controls
	 *
	 * @param string $prefix Prefix.
	 * @param array  $defaults Defaults.
	 * @param array  $conditions Conditions.
	 */
	protected function register_hover_cursor_controls( $prefix = '', $defaults = [], $conditions = [] ) {
		$type_conditions   = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type!' => 'none' ] );
		$icon_conditions   = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => [ 'button_icon', 'button_text_icon' ] ] );
		$image_conditions  = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => 'image' ] );
		$text_conditions   = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => [ 'button_text', 'button_text_icon' ] ] );
		$button_conditions = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => [ 'button_icon', 'button_text', 'button_text_icon' ] ] );

		$this->add_control(
			$prefix . 'hover_cursor_type',
			[
				'label'     => esc_html__( 'Hover Cursor Type', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $defaults['hover_cursor_type'] ?? 'none',
				'options'   => [
					'none'             => esc_html__( 'None', 'avalon-addons' ),
					'image'            => esc_html__( 'Image', 'avalon-addons' ),
					'button_icon'      => esc_html__( 'Button Icon', 'avalon-addons' ),
					'button_text'      => esc_html__( 'Button Text', 'avalon-addons' ),
					'button_text_icon' => esc_html__( 'Button Text & Icon', 'avalon-addons' ),
				],
				'condition' => $conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon',
			[
				'label'     => esc_html__( 'Icon', 'avalon-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => $defaults['hover_cursor_icon'] ?? [],
				'condition' => $icon_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_image',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => $defaults['hover_cursor_image'] ?? [],
				'condition' => $image_conditions,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => $prefix . 'hover_cursor_image_size',
				'default'   => $defaults['hover_cursor_image_size'] ?? 'large',
				'separator' => 'none',
				'condition' => $image_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text',
			[
				'label'     => esc_html__( 'Text', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $defaults['hover_cursor_text'] ?? '',
				'condition' => $text_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_position',
			[
				'label'     => esc_html__( 'Position', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $defaults['hover_cursor_position'] ?? 'center',
				'options'   => [
					'center'  => esc_html__( 'Center', 'avalon-addons' ),
					'default' => esc_html__( 'Default', 'avalon-addons' ),
				],
				'condition' => $type_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_style',
			[
				'label'     => esc_html__( 'Button Style', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $defaults['hover_cursor_style'] ?? 'button',
				'options'   => [
					'button' => esc_html__( 'Button', 'avalon-addons' ),
					'none'   => esc_html__( 'No Style', 'avalon-addons' ),
				],
				'condition' => $button_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_button_style',
			[
				'label'     => esc_html__( 'Button Variant', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $defaults['hover_cursor_button_style'] ?? 'button--white',
				'options'   => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
				'condition' => $button_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_class',
			[
				'label'     => esc_html__( 'Hover Cursor Class', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $defaults['hover_cursor_class'] ?? '',
				'condition' => $type_conditions,
			]
		);
	}

	/**
	 * Register hover cursor style controls
	 *
	 * The rendered cursor is cloned into the theme's body-level `.avalon-cursor`,
	 * outside the Elementor widget wrapper, so selectors are scoped to the
	 * `.avalon-cursor__inner` and the id-scoped wrapper class.
	 *
	 * @param string $prefix Prefix.
	 * @param array  $conditions Conditions.
	 */
	protected function register_hover_cursor_controls_style( $prefix = '', $conditions = [] ) {
		$type_conditions  = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type!' => 'none' ] );
		$icon_conditions  = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => [ 'button_icon', 'button_text_icon' ] ] );
		$image_conditions = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => 'image' ] );
		$text_conditions  = wp_parse_args( $conditions, [ $prefix . 'hover_cursor_type' => [ 'button_text', 'button_text_icon' ] ] );

		$wrapper = '.avalon-cursor__inner .avalon-hover-cursor__' . esc_attr( $prefix ) . '{{ID}}';

		$this->add_control(
			$prefix . 'hover_cursor_image_heading',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => $image_conditions,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					$wrapper . ' img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => $image_conditions,
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_image_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					$wrapper . ' img' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => $image_conditions,
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					$wrapper . ' img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => $image_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => $icon_conditions,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_size',
			[
				'label'      => esc_html__( 'Size', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					$wrapper . ' .avalon-cursor__button-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => $icon_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					$wrapper . ' .avalon-cursor__button-icon' => 'color: {{VALUE}};',
				],
				'condition' => $icon_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					$wrapper . ' .avalon-cursor__button-icon' => 'background-color: {{VALUE}};',
				],
				'condition' => $icon_conditions,
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					$wrapper . ' .avalon-cursor__button-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => $icon_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_heading',
			[
				'label'     => esc_html__( 'Text', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => $text_conditions,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => $prefix . 'hover_cursor_text_typography',
				'selector'  => $wrapper . ' .avalon-cursor__button',
				'condition' => $text_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					$wrapper . ' .avalon-cursor__button' => 'color: {{VALUE}};',
				],
				'condition' => $text_conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					$wrapper . ' .avalon-cursor__button' => 'background-color: {{VALUE}};',
				],
				'condition' => $text_conditions,
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_text_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					$wrapper . ' .avalon-cursor__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => $text_conditions,
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_text_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					$wrapper . ' .avalon-cursor__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => $text_conditions,
			]
		);
	}

	/**
	 * Render hover cursor attributes for the content wrapper
	 *
	 * Prints the `hover-cursor` attribute plus the element-level overrides the
	 * theme's hover-cursor module understands (`hover-cursor-type`,
	 * `hover-cursor-data`, `hover-cursor-text`, `data-cursor-position`).
	 *
	 * @param string $prefix Prefix.
	 * @return void
	 */
	protected function render_hover_cursor_attributes( $prefix = '' ) {
		$settings = $this->get_settings_for_display();
		$type     = $settings[ $prefix . 'hover_cursor_type' ] ?? 'none';

		if ( 'none' === $type ) {
			return;
		}

		$widget_id = $this->get_id();
		$cursor_id = $prefix . $widget_id;

		$attributes = 'hover-cursor';

		if ( 'image' === $type ) {
			$attributes .= ' hover-cursor-type="image"';
		} else {
			$attributes .= ' hover-cursor-data="' . esc_attr( $cursor_id ) . '"';
		}

		$text     = $settings[ $prefix . 'hover_cursor_text' ] ?? '';
		$position = $settings[ $prefix . 'hover_cursor_position' ] ?? 'center';

		if ( '' !== (string) $text ) {
			$attributes .= ' hover-cursor-text="' . esc_attr( $text ) . '"';
		}

		$attributes .= ' data-cursor-position="' . esc_attr( $position ) . '"';

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- individual values are escaped above.
		echo $attributes;
	}

	/**
	 * Render hover cursor template
	 *
	 * Outputs the markup consumed by the theme's hover-cursor module. Must be
	 * called inside the `[hover-cursor]` wrapper for the image type.
	 *
	 * - Image: `<template hover-cursor-image>` (native theme flow).
	 * - Buttons: `<template hover-cursor-data>` mirroring the theme's generated
	 *   cursor buttons (`avalon-cursor__button`, `avalon-cursor__button-icon`).
	 *
	 * @param string $prefix Prefix.
	 * @return void
	 */
	protected function render_hover_cursor_template( $prefix = '' ) {
		$settings = $this->get_settings_for_display();
		$type     = $settings[ $prefix . 'hover_cursor_type' ] ?? 'none';

		if ( 'none' === $type ) {
			return;
		}

		$widget_id = $this->get_id();
		$cursor_id = $prefix . $widget_id;

		$wrapper_class = [ 'avalon-hover-cursor__' . esc_attr( $cursor_id ) ];
		$wrapper_class = array_merge( $wrapper_class, $this->get_hover_cursor_classes() );

		$custom_class = $settings[ $prefix . 'hover_cursor_class' ] ?? '';
		if ( '' !== (string) $custom_class ) {
			$wrapper_class[] = $custom_class;
		}

		$wrapper_class = trim( implode( ' ', array_map( 'trim', array_filter( $wrapper_class ) ) ) );

		if ( 'image' === $type ) {
			?>
			<template hover-cursor-image>
				<div class="<?php echo esc_attr( $wrapper_class ); ?>">
					<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, $prefix . 'hover_cursor_image_size', $prefix . 'hover_cursor_image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</template>
			<?php
			return;
		}

		$button_modifier = 'none' === ( $settings[ $prefix . 'hover_cursor_style' ] ?? 'button' )
			? 'button--no-style'
			: ( $settings[ $prefix . 'hover_cursor_button_style' ] ?? '' );
		?>
		<template hover-cursor-data="<?php echo esc_attr( $cursor_id ); ?>">
			<div class="<?php echo esc_attr( $wrapper_class ); ?>">
				<?php if ( 'button_text_icon' === $type ) : ?>
					<div class="avalon-cursor__buttons">
						<span class="avalon-cursor__button button <?php echo esc_attr( $button_modifier ); ?>" hover-cursor-text></span>
						<span class="avalon-cursor__button-icon button button-icon avalon-svg-icon <?php echo esc_attr( $button_modifier ); ?>" aria-hidden="true">
							<?php $this->render_hover_cursor_icon( $settings, $prefix ); ?>
						</span>
					</div>
				<?php elseif ( 'button_text' === $type ) : ?>
					<span class="avalon-cursor__button button <?php echo esc_attr( $button_modifier ); ?>" hover-cursor-text></span>
				<?php elseif ( 'button_icon' === $type ) : ?>
					<span class="avalon-cursor__button-icon button button-icon avalon-svg-icon <?php echo esc_attr( $button_modifier ); ?>" aria-hidden="true">
						<?php $this->render_hover_cursor_icon( $settings, $prefix ); ?>
					</span>
				<?php endif; ?>
			</div>
		</template>
		<?php
	}

	/**
	 * Render hover cursor icon
	 *
	 * Outputs the selected Elementor icon or falls back to a theme SVG icon
	 * (defaults to `arrow-up-right`, matches `HoverCursorComponent.defaultIcon`).
	 *
	 * @param array  $settings Widget settings.
	 * @param string $prefix Prefix.
	 * @return void
	 */
	protected function render_hover_cursor_icon( $settings, $prefix = '' ) {
		$icon = $settings[ $prefix . 'hover_cursor_icon' ] ?? null;

		// Ignore the legacy `fas fa-arrow-right` default so the theme SVG stays
		// the effective default when a widget was saved before the SVG fallback
		// existed (FontAwesome is often not enqueued on the frontend).
		if ( ! empty( $icon['value'] ) && ! $this->is_hover_cursor_legacy_icon( $icon ) ) {
			Icons_Manager::render_icon(
				$icon,
				[
					'aria-hidden' => 'true',
					'fill'        => 'currentColor',
				]
			);
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted theme SVG.
		echo \AvalonAddons\Helper::get_svg( $this->get_hover_cursor_icon_fallback( $prefix ) );
	}

	/**
	 * Whether the icon is the legacy `fas fa-arrow-right` default.
	 *
	 * Widgets saved before the theme SVG default existed may still hold the old
	 * FontAwesome default, which renders nothing when FontAwesome is not
	 * enqueued. Treat it as "no icon" so the theme SVG fallback applies.
	 *
	 * @param array $icon ICONS control value.
	 * @return bool
	 */
	protected function is_hover_cursor_legacy_icon( $icon ) {
		return ( 'fas fa-arrow-right' === ( $icon['value'] ?? '' ) && 'fa-solid' === ( $icon['library'] ?? '' ) );
	}

	/**
	 * Get the fallback theme icon name for the hover cursor
	 *
	 * Override in widgets to pick a different theme `ui` SVG default.
	 *
	 * @param string $icon Icon name.
	 * @return string
	 */
	protected function get_hover_cursor_icon_fallback( $icon = 'arrow-up-right' ) {
		return $icon;
	}

	/**
	 * Get hover cursor classes
	 *
	 * Override in widgets to append theme utility classes to the cursor
	 * content wrapper.
	 *
	 * @return array
	 */
	protected function get_hover_cursor_classes() {
		return [];
	}
}
