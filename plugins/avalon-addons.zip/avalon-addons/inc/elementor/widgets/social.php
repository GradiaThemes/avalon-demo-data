<?php
/**
 * Social Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Social Widget Class
 */
class Social extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-social';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'social' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'social' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Social', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-social-icons ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'social', 'icons', 'links' ];
	}

	/**
	 * Get available social networks.
	 *
	 * @return array
	 */
	private function get_networks() {
		return [
			'facebook'  => esc_html__( 'Facebook', 'avalon-addons' ),
			'instagram' => esc_html__( 'Instagram', 'avalon-addons' ),
			'x'         => esc_html__( 'X (Twitter)', 'avalon-addons' ),
			'linkedin'  => esc_html__( 'LinkedIn', 'avalon-addons' ),
			'email'     => esc_html__( 'Email', 'avalon-addons' ),
			'pinterest' => esc_html__( 'Pinterest', 'avalon-addons' ),
			'telegram'  => esc_html__( 'Telegram', 'avalon-addons' ),
			'reddit'    => esc_html__( 'Reddit', 'avalon-addons' ),
			'pocket'    => esc_html__( 'Pocket', 'avalon-addons' ),
			'github'    => esc_html__( 'GitHub', 'avalon-addons' ),
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'social_section',
			[
				'label' => esc_html__( 'Social', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'networks',
			[
				'label'    => esc_html__( 'Networks', 'avalon-addons' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => $this->get_networks(),
				'default'  => [ 'x', 'linkedin', 'facebook' ],
			]
		);

		$this->add_control(
			'link_facebook',
			[
				'label'       => esc_html__( 'Facebook Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://facebook.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://facebook.com/' ],
				'condition'   => [
					'networks' => 'facebook',
				],
			]
		);

		$this->add_control(
			'link_instagram',
			[
				'label'       => esc_html__( 'Instagram Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://instagram.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://instagram.com/' ],
				'condition'   => [
					'networks' => 'instagram',
				],
			]
		);

		$this->add_control(
			'link_x',
			[
				'label'       => esc_html__( 'X Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://x.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://x.com/' ],
				'condition'   => [
					'networks' => 'x',
				],
			]
		);

		$this->add_control(
			'link_linkedin',
			[
				'label'       => esc_html__( 'LinkedIn Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://linkedin.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://linkedin.com/' ],
				'condition'   => [
					'networks' => 'linkedin',
				],
			]
		);

		$this->add_control(
			'link_email',
			[
				'label'       => esc_html__( 'Email Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'mailto:...', 'avalon-addons' ),
				'default'     => [ 'url' => 'mailto:' ],
				'condition'   => [
					'networks' => 'email',
				],
			]
		);

		$this->add_control(
			'link_pinterest',
			[
				'label'       => esc_html__( 'Pinterest Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://pinterest.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://pinterest.com/' ],
				'condition'   => [
					'networks' => 'pinterest',
				],
			]
		);

		$this->add_control(
			'link_telegram',
			[
				'label'       => esc_html__( 'Telegram Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://t.me/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://t.me/' ],
				'condition'   => [
					'networks' => 'telegram',
				],
			]
		);

		$this->add_control(
			'link_reddit',
			[
				'label'       => esc_html__( 'Reddit Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://reddit.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://reddit.com/' ],
				'condition'   => [
					'networks' => 'reddit',
				],
			]
		);

		$this->add_control(
			'link_pocket',
			[
				'label'       => esc_html__( 'Pocket Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://getpocket.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://getpocket.com/' ],
				'condition'   => [
					'networks' => 'pocket',
				],
			]
		);

		$this->add_control(
			'link_github',
			[
				'label'       => esc_html__( 'GitHub Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://github.com/...', 'avalon-addons' ),
				'default'     => [ 'url' => 'https://github.com/' ],
				'condition'   => [
					'networks' => 'github',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_social_style',
			[
				'label' => esc_html__( 'Social', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'     => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-social' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label'      => esc_html__( 'Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-social' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['networks'] ) ) {
			return;
		}

		$this->add_render_attribute( 'social', 'class', [ 'avalon-social', 'flex', 'flex-wrap', 'gap-3' ] );

		?>
		<div <?php $this->print_render_attribute_string( 'social' ); ?>>
			<?php
			foreach ( $settings['networks'] as $network ) {
				$link_key = 'link_' . $network;

				if ( empty( $settings[ $link_key ]['url'] ) ) {
					continue;
				}

				$attr_key = 'link_' . $network;

				$this->add_render_attribute( $attr_key, 'class', [ 'button', 'button-icon', 'button--white' ] );
				$this->add_link_attributes( $attr_key, $settings[ $link_key ] );

				$svg = \AvalonAddons\Helper::get_svg( $network, 'social' );

				if ( ! $svg ) {
					continue;
				}
				?>
				<a <?php $this->print_render_attribute_string( $attr_key ); ?>>
					<?php echo $svg; // phpcs:ignore ?>
				</a>
				<?php
			}
			?>
		</div>
		<?php
	}
}
