<?php
/**
 * Stacked Showcase Widget
 *
 * Displays content in a 3-column scroll-pinned layout with stacked images,
 * transitioning titles, details, and a fraction indicator.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Repeater;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;
use AvalonAddons\Helper;

/**
 * Stacked Showcase Widget Class
 */
class Stacked_Showcase extends Widget_Base {

	use Base\Button_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-stacked-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'stacked-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'stacked-showcase' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Stacked Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slideshow ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'stacked', 'showcase', 'scroll', 'gallery' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__( 'Items', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'thumbnail',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter button text', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Button Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'title'       => esc_html__( 'Service 1', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the first service.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Get Started', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'title'       => esc_html__( 'Service 2', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the second service.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Get Started', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'title'       => esc_html__( 'Service 3', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the third service.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Get Started', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_general_style',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'thumbnail_heading',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'thumbnail_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Example: 16/9', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-stacked-showcase__image-item' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-stacked-showcase__image-item' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_aspect_ratio_mobile',
			[
				'label'       => esc_html__( 'Aspect Ratio Mobile', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Example: 16/9', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-stacked-showcase__image' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-stacked-showcase__image-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .avalon-stacked-showcase__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'button_heading',
			[
				'label'     => esc_html__( 'Button', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['items'] ?? [];
		$count    = count( $items );

		if ( empty( $items ) || $count < 2 ) {
			return;
		}

		$this->render_stacked( $settings, $items, $count );
	}

	/**
	 * Render the stacked showcase layout.
	 *
	 * @param array $settings Widget settings.
	 * @param array $items    Repeater items.
	 * @param int   $count    Number of items.
	 */
	private function render_stacked( array $settings, array $items, int $count ) {
		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-stacked-showcase',
				'relative',
			]
		);

		$this->add_render_attribute( 'wrapper', 'data-count', esc_attr( $count ) );
		$this->add_render_attribute( 'wrapper', 'style', '--count: ' . esc_attr( $count ) . ';' );

		$this->add_render_attribute(
			'stack',
			'class',
			[
				'avalon-stacked-showcase__stack',
				'grid',
				'grid-cols-1',
				'md:grid-cols-12',
				'gap-12',
				'md:gap-4',
				'relative',
				'z-2',
			]
		);

		$this->add_render_attribute(
			'titles',
			'class',
			[
				'avalon-stacked-showcase__titles',
				'relative',
				'col-span-1',
				'sm:col-span-4',
				'lg:col-span-3',
				'hidden',
				'md:grid',
			]
		);

		$this->add_render_attribute(
			'images',
			'class',
			[
				'avalon-stacked-showcase__images',
				'col-span-1',
				'sm:col-span-4',
				'lg:col-span-6',
				'relative',
				'hidden',
				'md:block',
			]
		);

		$this->add_render_attribute(
			'details',
			'class',
			[
				'avalon-stacked-showcase__details',
				'relative',
				'col-span-1',
				'sm:col-span-4',
				'lg:col-span-3',
				'hidden',
				'md:grid',
			]
		);

		$this->add_render_attribute(
			'fraction',
			'class',
			[
				'avalon-stacked-showcase__fraction',
				'absolute',
				'left-1/2',
				'-translate-x-1/2',
				'flex',
				'items-center',
				'justify-center',
				'gap-4',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div class="avalon-stacked-showcase__backdrop overflow-hidden absolute top-0 left-1/2 -translate-x-1/2 z-1 hidden md:grid grid-area-1 place-items-center" data-animate="sticky" data-pin-start="bottom bottom">
				<?php foreach ( $items as $index => $item ) : ?>
					<?php
					$thumbnail = $item['thumbnail'] ?? [];
					$image_id  = $thumbnail['id'] ?? 0;
					$image_url = $thumbnail['url'] ?? '';
					$has_image = ! empty( $image_id ) || ! empty( $image_url );
					?>
					<?php if ( $has_image ) : ?>
						<div class="avalon-stacked-showcase__backdrop-image relative ratio-image <?php echo 0 === $index ? 'is-active' : ''; ?>" data-index="<?php echo esc_attr( $index ); ?>">
							<?php
							if ( $image_id ) {
								echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									$image_id,
									'full',
									false,
									[
										'loading' => 0 === $index ? 'eager' : 'lazy',
									]
								);
							} else {
								printf(
									'<img src="%1$s" alt="%2$s"  loading="%3$s" />',
									esc_url( $image_url ),
									esc_attr( Control_Media::get_image_alt( $thumbnail ) ),
									esc_attr( 0 === $index ? 'eager' : 'lazy' ),
								);
							}
							?>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>

			<div <?php $this->print_render_attribute_string( 'stack' ); ?>>

				<?php foreach ( $items as $index => $item ) : ?>
					<div class="avalon-stacked-showcase__item block md:hidden">
						<?php
						$thumbnail = $item['thumbnail'] ?? [];
						$image_id  = $thumbnail['id'] ?? 0;
						$image_url = $thumbnail['url'] ?? '';
						$has_image = ! empty( $image_id ) || ! empty( $image_url );
						?>
						<div class="avalon-stacked-showcase__image ratio-image rounded-sm relative" data-index="<?php echo esc_attr( $index ); ?>">
							<?php if ( $has_image ) : ?>
								<?php
								if ( $image_id ) {
									echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										$image_id,
										'full',
										false,
										[
											'loading' => 0 === $index ? 'eager' : 'lazy',
										]
									);
								} else {
									printf(
										'<img src="%1$s" alt="%2$s"  loading="%3$s" />',
										esc_url( $image_url ),
										esc_attr( Control_Media::get_image_alt( $thumbnail ) ),
										esc_attr( 0 === $index ? 'eager' : 'lazy' ),
									);
								}
								?>
							<?php endif; ?>
						</div>
						<h2 class="avalon-stacked-showcase__title text-heading font-heading my-0 mt-4"><?php echo esc_html( $item['title'] ); ?></h2>
						<div class="avalon-stacked-showcase__detail mt-4" data-index="<?php echo esc_attr( $index ); ?>">
							<?php if ( ! empty( $item['description'] ) ) : ?>
								<div class="avalon-stacked-showcase__description text-body-3 mb-6">
									<?php echo wp_kses_post( nl2br( $item['description'] ) ); ?>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $item['button_text'] ) ) : ?>
								<?php
								$item_settings                     = $item;
								$item_settings['button_style']     = $settings['button_style'] ?? '';
								$item_settings['button_type']      = 'text';
								$item_settings['button_alignment'] = '';
								$this->button_text( $item_settings );
								?>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>

				<div <?php $this->print_render_attribute_string( 'titles' ); ?>>
					<?php foreach ( $items as $index => $item ) : ?>
						<div class="avalon-stacked-showcase__title-item" data-index="<?php echo esc_attr( $index ); ?>">
							<?php if ( ! empty( $item['title'] ) ) : ?>
								<h2 class="text-heading font-heading my-0"><?php echo esc_html( $item['title'] ); ?></h2>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<div <?php $this->print_render_attribute_string( 'images' ); ?>>
					<div class="avalon-stacked-showcase__images-wrapper grid grid-area-1 place-items-center" data-animate="sticky" data-pin-start="center center">
						<?php
						foreach ( $items as $index => $item ) :
							$thumbnail = $item['thumbnail'] ?? [];
							$image_id  = $thumbnail['id'] ?? 0;
							$image_url = $thumbnail['url'] ?? '';
							$has_image = ! empty( $image_id ) || ! empty( $image_url );
							?>
							<div class="avalon-stacked-showcase__image-item ratio-image rounded-sm relative" data-index="<?php echo esc_attr( $index ); ?>">
								<?php if ( $has_image ) : ?>
									<?php
									if ( $image_id ) {
										echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
											$image_id,
											'full',
											false,
											[
												'loading' => 0 === $index ? 'eager' : 'lazy',
											]
										);
									} else {
										printf(
											'<img src="%1$s" alt="%2$s"  loading="%3$s" />',
											esc_url( $image_url ),
											esc_attr( Control_Media::get_image_alt( $thumbnail ) ),
											esc_attr( 0 === $index ? 'eager' : 'lazy' ),
										);
									}
									?>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

				<div <?php $this->print_render_attribute_string( 'details' ); ?>>
					<?php foreach ( $items as $index => $item ) : ?>
						<div class="avalon-stacked-showcase__detail-item" data-index="<?php echo esc_attr( $index ); ?>">
							<?php if ( ! empty( $item['description'] ) ) : ?>
								<div class="avalon-stacked-showcase__description text-body-3 mb-6">
									<?php echo wp_kses_post( nl2br( $item['description'] ) ); ?>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $item['button_text'] ) ) : ?>
								<?php
								$item_settings                     = $item;
								$item_settings['button_style']     = $settings['button_style'] ?? '';
								$item_settings['button_type']      = 'text';
								$item_settings['button_alignment'] = '';
								$this->button_text( $item_settings );
								?>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

			</div>

			<div class="avalon-stacked-showcase__fraction-wrapper w-full h-screen absolute inset-0 hidden md:flex justify-center items-center gap-3 text-primary z-2 pointer-events-none" data-animate="sticky">
				<div <?php $this->print_render_attribute_string( 'fraction' ); ?>>
					<span class="avalon-stacked-showcase__current caption grid grid-area-1 place-items-center">
						<?php foreach ( range( 1, $count ) as $i ) : ?>
							<span class="<?php echo esc_attr( 1 === $i ? 'is-active' : '' ); ?>">
								<?php echo esc_html( str_pad( $i, 2, '0', STR_PAD_LEFT ) ); ?>
							</span>
						<?php endforeach; ?>
					</span>
					<span class="avalon-stacked-showcase__dot">
						<?php echo Helper::get_svg( 'dot' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</span>
					<span class="avalon-stacked-showcase__total caption">
						<?php echo esc_html( str_pad( (string) $count, 2, '0', STR_PAD_LEFT ) ); ?>
					</span>
				</div>
			</div>
		</div>
		<?php
	}
}
