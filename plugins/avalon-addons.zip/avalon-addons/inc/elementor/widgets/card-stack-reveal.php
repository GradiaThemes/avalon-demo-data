<?php
/**
 * Card Stack Reveal Widget
 *
 * Displays a gallery of images as a card stack that cycles automatically
 * with smooth GSAP-powered reveal animation.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Card Stack Reveal Widget Class
 */
class Card_Stack_Reveal extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-card-stack-reveal';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'card-stack-reveal' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'card-stack-reveal' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Card Stack Reveal', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'gallery', 'stack', 'card', 'reveal', 'image' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Gallery', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'gallery',
			[
				'label'       => esc_html__( 'Images', 'avalon-addons' ),
				'type'        => Controls_Manager::GALLERY,
				'label_block' => true,
				'dynamic'     => [ 'active' => true ],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image_size',
				'default' => 'full',
			]
		);

		$this->add_control(
			'stack_duration',
			[
				'label'       => esc_html__( 'Duration', 'avalon-addons' ),
				'description' => esc_html__( 'How long each card transition takes.', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.1,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'default'     => [
					'size' => 0.3,
					'unit' => 's',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-card-stack-reveal' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'vh', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-card-stack-reveal' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-card-stack-reveal__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$gallery = (array) $settings['gallery'];

		if ( empty( $gallery ) ) {
			return;
		}

		$image_size = $this->get_image_size( $settings );
		$count      = count( $gallery );

		// Fixed animation parameters per spec — 3s interval, 60° max rotation.
		// Only the transition duration is user-configurable.
		$max_rotation = 60;
		$step         = $count > 1 ? $max_rotation / ( $count - 1 ) : 0;
		$duration     = ! empty( $settings['stack_duration']['size'] ) ? (float) $settings['stack_duration']['size'] : 0.3;

		$this->add_render_attribute(
			'wrapper',
			'class',
			[ 'avalon-card-stack-reveal', 'relative', 'inline-block' ]
		);

		$this->add_render_attribute( 'wrapper', 'data-stack-duration', esc_attr( $duration ) );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php
			foreach ( $gallery as $index => $image ) {
				$image_id  = $image['id'] ?? 0;
				$image_url = $image['url'] ?? '';

				if ( empty( $image_id ) && empty( $image_url ) ) {
					continue;
				}

				$rotation = $index * $step;
				$z_index  = $count - $index;
				$loading  = 0 === $index ? 'eager' : 'lazy';

				$item_key = 'stack_item_' . $index;

				$this->add_render_attribute(
					$item_key,
					'class',
					[ 'avalon-card-stack-reveal__item', 'absolute', 'inset-0', 'w-full', 'h-full', 'overflow-hidden', 'rounded-sm', 'ratio-image' ]
				);

				$this->add_render_attribute(
					$item_key,
					'style',
					sprintf(
						'transform: rotate(%1$.2fdeg); z-index: %2$d;',
						(float) $rotation,
						(int) $z_index
					)
				);
				?>
				<figure <?php $this->print_render_attribute_string( $item_key ); ?>>
					<?php
					if ( $image_id ) {
						echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							$image_id,
							$image_size,
							false,
							[
								'class'   => 'object-cover w-full h-full',
								'loading' => $loading,
							]
						);
					} else {
						printf(
							'<img src="%1$s" alt="%2$s" class="object-cover w-full h-full" loading="%3$s" />',
							esc_url( $image_url ),
							esc_attr( $image['alt'] ?? '' ),
							esc_attr( $loading )
						);
					}
					?>
				</figure>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Resolve the image size from the Group_Control_Image_Size settings.
	 *
	 * @param array $settings Widget settings.
	 * @return string|array Size name (e.g. 'full') or [width, height] for custom.
	 */
	private function get_image_size( array $settings ) {
		$size = $settings['image_size_size'] ?? 'full';

		if ( 'custom' === $size ) {
			$custom = $settings['image_size_custom_dimension'] ?? [];

			if ( ! empty( $custom['width'] ) || ! empty( $custom['height'] ) ) {
				return [
					! empty( $custom['width'] ) ? (int) $custom['width'] : null,
					! empty( $custom['height'] ) ? (int) $custom['height'] : null,
				];
			}

			return 'full';
		}

		return $size;
	}
}
