<?php
/**
 * Image Carousel Widget
 *
 * Displays images/logos in a grid that cycles rows vertically
 * with staggered individual item scroll animation.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Image Carousel Widget Class
 */
class Image_Carousel extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-image-carousel';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'image-carousel' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'image-carousel' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Image Carousel', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'image', 'carousel', 'logo', 'slider', 'gallery' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Images', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'avalon-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'images',
			[
				'label'       => esc_html__( 'Images', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'title_field' => esc_html__( 'Image', 'avalon-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image_size',
				'default' => 'full',
			]
		);

		$this->add_responsive_control(
			'slides_per_view',
			[
				'label'   => esc_html__( 'Slides to Show', 'avalon-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 12,
				'step'    => 1,
				'default' => 4,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label'     => esc_html__( 'Space Between', 'avalon-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100,
				'default'   => 12,
				'selectors' => [
					'{{WRAPPER}} .avalon-image-carousel__grid' => 'gap: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'   => esc_html__( 'Autoplay Speed (ms)', 'avalon-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3000,
				'min'     => 500,
				'step'    => 100,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Set the image ratio. Example: 3 / 2', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-image-carousel__item' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-image-carousel__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$images   = $settings['images'] ?? [];

		if ( empty( $images ) ) {
			return;
		}

		$desktop    = intval( $settings['slides_per_view'] ?? 4 );
		$tablet     = ! empty( $settings['slides_per_view_tablet'] ) ? intval( $settings['slides_per_view_tablet'] ) : $desktop;
		$mobile     = ! empty( $settings['slides_per_view_mobile'] ) ? intval( $settings['slides_per_view_mobile'] ) : $tablet;
		$image_size = $this->get_image_size( $settings );

		// Filter valid images.
		$valid_images = [];
		foreach ( $images as $item ) {
			$image_id  = $item['image']['id'] ?? 0;
			$image_url = $item['image']['url'] ?? '';

			if ( empty( $image_id ) && empty( $image_url ) ) {
				continue;
			}

			$valid_images[] = [
				'id'  => $image_id,
				'url' => $image_url,
				'alt' => $item['image']['alt'] ?? '',
			];
		}

		if ( empty( $valid_images ) ) {
			return;
		}

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-image-carousel',
				'relative',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute(
			'wrapper',
			'data-autoplay-speed',
			esc_attr( $settings['autoplay_speed'] ?? 3000 )
		);

		$this->add_render_attribute(
			'grid',
			'class',
			[
				'avalon-image-carousel__grid',
				'grid',
				'grid-cols-' . $mobile,
				'md:grid-cols-' . $tablet,
				'lg:grid-cols-' . $desktop,
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'grid' ); ?>>
				<?php
				foreach ( $valid_images as $index => $image ) :
					$mobile_col  = ( $index % $mobile ) + 1;
					$tablet_col  = ( $index % $tablet ) + 1;
					$desktop_col = ( $index % $desktop ) + 1;

					$item_classes = [
						'avalon-image-carousel__item',
						'ratio-image',
						'grid-row-1',
						'grid-column-' . $mobile_col,
					];

					if ( $tablet_col !== $mobile_col ) {
						$item_classes[] = 'md:grid-column-' . $tablet_col;
					}

					if ( $desktop_col !== $tablet_col ) {
						$item_classes[] = 'lg:grid-column-' . $desktop_col;
					}

					$item_key = 'item_' . $index;

					$this->add_render_attribute(
						$item_key,
						'class',
						$item_classes
					);

					$this->add_render_attribute(
						$item_key,
						'data-index',
						intval( $index )
					);
					?>
					<div <?php $this->print_render_attribute_string( $item_key ); ?>>
						<?php
						if ( $image['id'] ) {
							echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								$image['id'],
								$image_size,
								false,
								[
									'loading' => $index < $desktop ? 'eager' : 'lazy',
								]
							);
						} else {
							printf(
								'<img src="%1$s" alt="%2$s" loading="%3$s" />',
								esc_url( $image['url'] ),
								esc_attr( $image['alt'] ),
								esc_attr( $index < $desktop ? 'eager' : 'lazy' )
							);
						}
						?>
					</div>
					<?php
				endforeach;
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Resolve the image size from the Group_Control_Image_Size settings.
	 *
	 * @param array $settings Widget settings.
	 * @return string|array Size name or custom dimensions.
	 */
	private function get_image_size( array $settings ) {
		$size = $settings['image_size_size'] ?? 'full';

		if ( 'custom' === $size ) {
			$custom = $settings['image_size_custom_dimension'] ?? [];

			if ( ! empty( $custom['width'] ) || ! empty( $custom['height'] ) ) {
				return [
					! empty( $custom['width'] ) ? (int) $custom['width'] : null,
					! empty( $custom['height'] ) ? (int) $custom['height'] : null,
				];
			}

			return 'full';
		}

		return $size;
	}
}
