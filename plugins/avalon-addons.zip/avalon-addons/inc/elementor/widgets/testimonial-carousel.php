<?php
/**
 * Testimonial Carousel Widget
 *
 * Displays testimonials in a carousel. The content (quote, comment, author)
 * is the MAIN slider on the left; the image is a SECONDARY slider on the right,
 * connected to the main slider so both advance together. The optional strip
 * reveal effect is applied to each image (media) element.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor;
use AvalonAddons\Helper;

/**
 * Testimonial Carousel Widget Class
 */
class Testimonial_Carousel extends Base\Carousel_Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-testimonial-carousel';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'testimonial-carousel' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'testimonial-carousel' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Testimonial Carousel', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel ' . Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'testimonial', 'carousel', 'quote', 'slider' ];
	}

	/**
	 * Get carousel controls.
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 1,
				'tablet'  => 1,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 30,
				'tablet'  => 30,
				'mobile'  => 15,
			],
			'navigation'      => 'both',
			'effect'          => 'fade',
		];
	}

	/**
	 * Manual attributes for the main (content) slider.
	 *
	 * Links the content slider to the secondary image slider via the theme's
	 * gt-slider `data-thumbs` feature (Swiper Thumbs module), so both sliders
	 * advance together.
	 *
	 * @return array
	 */
	protected function get_manual_attributes(): array {
		return [
			'data-thumbs' => '#avalon-testimonial-image-' . $this->get_id(),
		];
	}

	/**
	 * Register widget controls.
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Testimonials', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'avalon-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'text',
			[
				'label' => esc_html__( 'Quote', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'comment',
			[
				'label' => esc_html__( 'Comment', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'avatar',
			[
				'label' => esc_html__( 'Avatar', 'avalon-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'name',
			[
				'label' => esc_html__( 'Name', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Job Title', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => esc_html__( 'Testimonials', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'text'    => esc_html__( 'This is an amazing product, highly recommended.', 'avalon-addons' ),
						'comment' => esc_html__( 'The team was professional and delivered beyond our expectations.', 'avalon-addons' ),
						'name'    => esc_html__( 'John Doe', 'avalon-addons' ),
						'title'   => esc_html__( 'CEO, Company', 'avalon-addons' ),
					],
					[
						'text'    => esc_html__( 'A wonderful experience from start to finish.', 'avalon-addons' ),
						'comment' => esc_html__( 'We will definitely work with them again in the future.', 'avalon-addons' ),
						'name'    => esc_html__( 'Jane Smith', 'avalon-addons' ),
						'title'   => esc_html__( 'Marketing Director', 'avalon-addons' ),
					],
					[
						'text'    => esc_html__( 'Outstanding quality and great support.', 'avalon-addons' ),
						'comment' => esc_html__( 'They understood our needs and executed perfectly.', 'avalon-addons' ),
						'name'    => esc_html__( 'Robert Brown', 'avalon-addons' ),
						'title'   => esc_html__( 'Product Manager', 'avalon-addons' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel' => 'height: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'comment_heading',
			[
				'label'     => esc_html__( 'Comment', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->register_text_controls(
			[
				'html_tag' => 'h5',
			],
			null,
			'comment_'
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_carousel_settings',
			[
				'label' => esc_html__( 'Carousel Settings', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls(
			[
				'navigation',
				'autoplay',
				'autoplay_speed',
				'speed',
				'infinite',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'quote_heading',
			[
				'label' => esc_html__( 'Quote', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'quote_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-carousel__text',
			]
		);

		$this->add_control(
			'quote_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'quote_spacing_bottom',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'comment_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-carousel__comment',
			]
		);

		$this->add_control(
			'comment_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__comment' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'author_heading',
			[
				'label'     => esc_html__( 'Author', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'author_spacing_top',
			[
				'label'      => esc_html__( 'Spacing Top', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__author' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-carousel__name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Name Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'job_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-carousel__job',
			]
		);

		$this->add_control(
			'job_color',
			[
				'label'     => esc_html__( 'Job Title Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__job' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_media',
			[
				'label' => esc_html__( 'Media', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Set the image ratio. Example: 1 / 1', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_max_height',
			[
				'label'      => esc_html__( 'Max Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media' => 'max-height: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'image_mix_blend_mode',
			[
				'label'     => esc_html__( 'Mix Blend Mode', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => [
					'normal'      => esc_html__( 'Normal', 'avalon-addons' ),
					'multiply'    => esc_html__( 'Multiply', 'avalon-addons' ),
					'screen'      => esc_html__( 'Screen', 'avalon-addons' ),
					'overlay'     => esc_html__( 'Overlay', 'avalon-addons' ),
					'darken'      => esc_html__( 'Darken', 'avalon-addons' ),
					'lighten'     => esc_html__( 'Lighten', 'avalon-addons' ),
					'color-dodge' => esc_html__( 'Color Dodge', 'avalon-addons' ),
					'saturation'  => esc_html__( 'Saturation', 'avalon-addons' ),
					'color'       => esc_html__( 'Color', 'avalon-addons' ),
					'luminosity'  => esc_html__( 'Luminosity', 'avalon-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media img' => 'mix-blend-mode: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'image_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media::before' => 'background-color: {{VALUE}}; display: block;',
				],
				'condition' => [
					'image_mix_blend_mode!' => 'normal',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-carousel__media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_carousel',
			[
				'label' => esc_html__( 'Carousel Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'controls_margin',
			[
				'label'      => esc_html__( 'Controls Margin', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-swiper-controls' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the content slides (main slider, left column).
	 *
	 * @param array $items Testimonial items (already filtered in render()).
	 */
	protected function render_content_items( array $items ) {
		$settings = $this->get_settings_for_display();

		foreach ( $items as $index => $item ) {
			$avatar_id  = ! empty( $item['avatar']['id'] ) ? $item['avatar']['id'] : 0;
			$avatar_url = ! empty( $item['avatar']['url'] ) ? $item['avatar']['url'] : '';

			$slide_key = 'content_slide_' . $index;
			$this->add_render_attribute(
				$slide_key,
				'class',
				[
					'swiper-slide',
					'avalon-testimonial-carousel__content-slide',
				]
			);
			?>
			<div <?php $this->print_render_attribute_string( $slide_key ); ?>>
				<div class="avalon-testimonial-carousel__content flex flex-col">
					<?php if ( ! empty( $item['text'] ) ) : ?>
						<div class="avalon-testimonial-carousel__text text-body-1 mb-8"><?php echo wp_kses_post( nl2br( $item['text'] ) ); ?></div>
					<?php endif; ?>

					<?php if ( ! empty( $item['comment'] ) ) : ?>
						<?php
						$this->text_render(
							$item['comment'],
							[
								'tag'        => $settings['comment_html_tag'] ?? 'h5',
								'size'       => $settings['comment_size'] ?? '',
								'class'      => [ 'avalon-testimonial-carousel__comment', 'font-regular', 'my-0' ],
								'attr'       => 'comment_text',
								'linebreaks' => $settings['comment_linebreaks'] ?? 'yes',
							]
						);
						?>
					<?php endif; ?>

					<?php if ( $avatar_id || $avatar_url || ! empty( $item['name'] ) || ! empty( $item['title'] ) ) : ?>
						<div class="avalon-testimonial-carousel__author flex items-center gap-6 mt-12">
							<?php if ( $avatar_id ) : ?>
								<div class="avalon-testimonial-carousel__avatar circle border border-color-secondary p-5px">
									<div class="ratio-image">
									<?php
									echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										$avatar_id,
										'full',
										false,
									);
									?>
									</div>
								</div>
							<?php elseif ( $avatar_url ) : ?>
								<div class="avalon-testimonial-carousel__avatar circle border border-color-secondary p-5px">
									<div class="ratio-image">
										<img src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $item['name'] ?? '' ); ?>" />
									</div>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $item['name'] ) || ! empty( $item['title'] ) ) : ?>
								<div class="avalon-testimonial-carousel__meta flex flex-col gap-1">
									<?php if ( ! empty( $item['name'] ) ) : ?>
										<span class="avalon-testimonial-carousel__name text-body-1 text-heading"><?php echo wp_kses_post( $item['name'] ); ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $item['title'] ) ) : ?>
										<span class="avalon-testimonial-carousel__job text-body-4"><?php echo wp_kses_post( $item['title'] ); ?></span>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render the image slides (secondary slider, right column).
	 *
	 * @param array $items Testimonial items (already filtered in render()).
	 */
	protected function render_image_items( array $items ) {
		foreach ( $items as $index => $item ) {
			$image_id  = ! empty( $item['image']['id'] ) ? $item['image']['id'] : 0;
			$image_url = ! empty( $item['image']['url'] ) ? $item['image']['url'] : '';

			if ( empty( $image_id ) && empty( $image_url ) ) {
				continue;
			}

			$slide_key = 'image_slide_' . $index;
			$this->add_render_attribute(
				$slide_key,
				'class',
				[
					'swiper-slide',
					'avalon-testimonial-carousel__image-slide',
				]
			);

			$media_key = 'image_media_' . $index;
			$this->add_render_attribute(
				$media_key,
				'class',
				[
					'avalon-testimonial-carousel__media',
					'ratio-image',
					'circle',
				]
			);
			?>
			<div <?php $this->print_render_attribute_string( $slide_key ); ?>>
				<div <?php $this->print_render_attribute_string( $media_key ); ?>>
					<?php if ( $image_id ) : ?>
						<?php
						echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							$image_id,
							'full',
						);
						?>
					<?php else : ?>
						<img  src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $item['name'] ?? '' ); ?>" />
					<?php endif; ?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render widget output.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['testimonials'] ?? [];

		// Keep content + image sliders on the SAME item set (1:1 slide
		// count). Image slides require an image, so drop items without
		// one before rendering either slider.
		$items = array_values(
			array_filter(
				$items,
				static function ( $item ) {
					return ! empty( $item['image']['id'] ) || ! empty( $item['image']['url'] );
				}
			)
		);

		if ( empty( $items ) ) {
			return;
		}

		$attributes         = $this->get_attributes();
		$content_attributes = $attributes;
		$image_attributes   = $attributes;
		unset( $image_attributes['data-thumbs'] );
		$image_attributes['effect']   = 'slices';
		$image_attributes['autoplay'] = '';
		?>
		<div class="avalon-testimonial-carousel lg:flex gap-4 justify-between relative h-full">
			<gt-slider class="avalon-testimonial-carousel__content-slider" <?php $this->print_attributes( $content_attributes ); ?>>
				<div class="swiper swiper--elementor">
					<div class="swiper-wrapper">
						<?php $this->render_content_items( $items ); ?>
					</div>
				</div>
				<div class="avalon-swiper-controls flex items-center gap-6 lg:absolute bottom-0 left-0">
					<?php $this->render_arrows(); ?>
					<?php $this->render_pagination(); ?>
				</div>
			</gt-slider>

			<gt-slider id="avalon-testimonial-image-<?php echo esc_attr( $this->get_id() ); ?>" class="avalon-testimonial-carousel__image-slider hidden lg:block" <?php $this->print_attributes( $image_attributes ); ?>>
				<div class="swiper swiper--elementor">
					<div class="swiper-wrapper">
						<?php $this->render_image_items( $items ); ?>
					</div>
				</div>
			</gt-slider>
		</div>
		<?php
	}
}
