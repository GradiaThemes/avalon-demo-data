<?php
/**
 * Image Showcase Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Image Showcase Widget Class
 */
class Image_Showcase extends Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-image-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'image-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'image-showcase' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Image Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'image', 'showcase', 'zoom', 'gallery' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title_text',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your title', 'avalon-addons' ),
				'description' => esc_html__( 'Shown above the images and fades out on scroll.', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->register_text_controls();

		$this->add_control(
			'main_image',
			[
				'label'       => esc_html__( 'Main Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'separator'   => 'before',
				'description' => esc_html__( 'The center image that expands to fill the container on scroll.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'left_image',
			[
				'label'       => esc_html__( 'Left Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'description' => esc_html__( 'Slides off-screen while the main image expands.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'right_image',
			[
				'label'       => esc_html__( 'Right Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'description' => esc_html__( 'Slides off-screen while the main image expands.', 'avalon-addons' ),
			]
		);

		$this->add_responsive_control(
			'aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '3 / 2',
				'separator'   => 'before',
				'description' => esc_html__( 'Set the image ratio. Example: 3 / 2', 'avalon-addons' ),
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'       => esc_html__( 'Height', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'vh', '%', 'custom' ],
				'default'     => [
					'unit' => 'custom',
					'size' => '100svh',
				],
				'selectors'   => [
					'{{WRAPPER}} .avalon-image-showcase' => '--showcase-height: {{SIZE}}{{UNIT}};',
				],
				'description' => esc_html__( 'Set the height for the image display area only on desktop.', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_images_style',
			[
				'label' => esc_html__( 'Images', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_align_heading',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'title_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-image-showcase__content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-image-showcase__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-image-showcase__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-image-showcase__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'main_radius_heading',
			[
				'label' => esc_html__( 'Main Image', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'main_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-image-showcase__main' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'side_radius_heading',
			[
				'label'     => esc_html__( 'Side Images', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'side_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-image-showcase__side' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-image-showcase',
				'flex',
				'flex-col',
				'justify-center',
				'relative',
				'overflow-hidden',
			]
		);
		$this->add_render_attribute(
			'wrapper',
			'style',
			sprintf(
				'--showcase-ratio: %s;',
				esc_attr( $settings['aspect_ratio'] ),
			)
		);

		$this->add_render_attribute(
			'content',
			'class',
			[
				'avalon-image-showcase__content',
				'text-center',
			]
		);

		$this->add_render_attribute(
			'images',
			'class',
			[
				'avalon-image-showcase__images',
				'flex',
				'flex-col',
				'lg:flex-row',
				'items-end',
				'gap-4',
				'flex-wrap',
				'lg:flex-nowrap',
				'lg:justify-center',
				'lg:overflow-hidden',
				'shrink-0',
				'w-full',
				'lg:absolute',
				'left-0',
				'bottom-0',
				'z-1',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $settings['title_text'] ) ) { ?>
				<div <?php $this->print_render_attribute_string( 'content' ); ?>>
					<?php
					$this->text_render(
						$settings['title_text'],
						[
							'tag'        => $settings['html_tag'],
							'size'       => $settings['size'],
							'attr'       => 'title',
							'class'      => [ 'avalon-image-showcase__title' ],
							'linebreaks' => $settings['linebreaks'],
						]
					);
					?>
				</div>
			<?php } ?>
			<div <?php $this->print_render_attribute_string( 'images' ); ?>>
				<?php
				$this->render_image( $settings['left_image'], 'figure-left', [ 'avalon-image-showcase__side', 'relative', 'z-1', 'ratio-image', 'rounded-sm', 'flex-none' ] );
				$this->render_image( $settings['main_image'], 'figure-main', [ 'avalon-image-showcase__main', 'relative', 'z-2', 'ratio-image', 'rounded-sm', 'shrink-0' ] );
				$this->render_image( $settings['right_image'], 'figure-right', [ 'avalon-image-showcase__side', 'relative', 'z-1', 'ratio-image', 'rounded-sm', 'flex-none' ] );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render a single image figure.
	 *
	 * @param array  $image   Media settings.
	 * @param string $key     Render attribute key.
	 * @param array  $classes Figure classes.
	 */
	private function render_image( $image, $key, $classes ) {
		if ( empty( $image['url'] ) ) {
			return;
		}

		$this->add_render_attribute( $key, 'class', $classes );

		?>
		<figure <?php $this->print_render_attribute_string( $key ); ?>>
			<?php
			if ( ! empty( $image['id'] ) ) {
				echo wp_get_attachment_image(
					$image['id'],
					'full',
					false,
					[
						'title' => Control_Media::get_image_title( $image ),
						'alt'   => Control_Media::get_image_alt( $image ),
						'class' => 'object-cover',
					]
				);
			} else {
				printf(
					'<img src="%1$s" title="%2$s" alt="%3$s" loading="lazy" class="object-cover" />',
					esc_url( $image['url'] ),
					esc_attr( Control_Media::get_image_title( $image ) ),
					esc_attr( Control_Media::get_image_alt( $image ) )
				);
			}
			?>
		</figure>
		<?php
	}
}
