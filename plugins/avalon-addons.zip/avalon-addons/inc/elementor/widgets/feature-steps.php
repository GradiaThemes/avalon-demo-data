<?php
/**
 * Feature Steps Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Elementor\Utils;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Feature Steps Widget Class
 */
class Feature_Steps extends Widget_Base {

	use Base\Button_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-feature-steps';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'feature-steps' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'feature-steps' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Feature Steps', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slideshow ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'feature', 'steps', 'progress', 'scroll', 'showcase' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__( 'Items', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter button text', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Button Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'title'       => esc_html__( 'Step 1', 'avalon-addons' ),
						'description' => esc_html__( 'Description', 'avalon-addons' ),
						'button_text' => esc_html__( 'Button Text', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'title'       => esc_html__( 'Step 2', 'avalon-addons' ),
						'description' => esc_html__( 'Description', 'avalon-addons' ),
						'button_text' => esc_html__( 'Button Text', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'title'       => esc_html__( 'Step 3', 'avalon-addons' ),
						'description' => esc_html__( 'Description', 'avalon-addons' ),
						'button_text' => esc_html__( 'Button Text', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
				],
			]
		);

		$this->add_control(
			'subtitle_text',
			[
				'label'       => esc_html__( 'Subtitle Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter subtitle text', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_floating_images',
			[
				'label' => esc_html__( 'Floating Images', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$floating_repeater = new Repeater();

		$floating_repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'avalon-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$floating_repeater->add_control(
			'hide_on_mobile',
			[
				'label'     => esc_html__( 'Hide on Mobile', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'after',
			]
		);

		$floating_repeater->add_responsive_control(
			'floating_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} span' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'floating_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vh', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} span' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_control(
			'horizontal_orientation',
			[
				'label'     => esc_html__( 'Horizontal Orientation', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'left'  => esc_html__( 'Left', 'avalon-addons' ),
					'right' => esc_html__( 'Right', 'avalon-addons' ),
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.is-h-left'  => 'left: var(--h-offset, auto); right: auto;',
					'{{WRAPPER}} {{CURRENT_ITEM}}.is-h-right' => 'right: var(--h-offset, auto); left: auto;',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'horizontal_offset',
			[
				'label'      => esc_html__( 'Offset', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--h-offset: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_control(
			'vertical_orientation',
			[
				'label'     => esc_html__( 'Vertical Orientation', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'top'    => esc_html__( 'Top', 'avalon-addons' ),
					'bottom' => esc_html__( 'Bottom', 'avalon-addons' ),
				],
				'default'   => 'top',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.is-v-top'    => 'top: var(--v-offset, auto); bottom: auto;',
					'{{WRAPPER}} {{CURRENT_ITEM}}.is-v-bottom' => 'bottom: var(--v-offset, auto); top: auto;',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'vertical_offset',
			[
				'label'      => esc_html__( 'Offset', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--v-offset: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'rotate',
			[
				'label'      => esc_html__( 'Rotation', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'deg' ],
				'range'      => [
					'deg' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--rotate: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'transform_offset_x',
			[
				'label'      => esc_html__( 'Offset X', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--translate-x: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$floating_repeater->add_responsive_control(
			'transform_offset_y',
			[
				'label'      => esc_html__( 'Offset Y', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--translate-y: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'floating_images',
			[
				'label'   => esc_html__( 'Images', 'avalon-addons' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $floating_repeater->get_controls(),
				'default' => [
					[
						'image'                    => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'floating_width'           => [
							'size' => 264,
							'unit' => 'px',
						],
						'floating_width_tablet'    => [
							'size' => 164,
							'unit' => 'px',
						],
						'floating_height'          => [
							'size' => 220,
							'unit' => 'px',
						],
						'floating_height_tablet'   => [
							'size' => 120,
							'unit' => 'px',
						],
						'horizontal_orientation'   => 'left',
						'horizontal_offset'        => [
							'unit' => 'px',
							'size' => -16,
						],
						'horizontal_offset_mobile' => [
							'unit' => 'px',
							'size' => -60,
						],
						'vertical_orientation'     => 'top',
						'vertical_offset'          => [
							'unit' => 'px',
							'size' => 57,
						],
						'rotate'                   => [
							'unit' => 'deg',
							'size' => -11,
						],
					],
					[
						'image'                    => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'floating_width'           => [
							'size' => 328,
							'unit' => 'px',
						],
						'floating_width_tablet'    => [
							'size' => 228,
							'unit' => 'px',
						],
						'floating_height'          => [
							'size' => 260,
							'unit' => 'px',
						],
						'floating_height_tablet'   => [
							'size' => 160,
							'unit' => 'px',
						],
						'horizontal_orientation'   => 'right',
						'horizontal_offset'        => [
							'unit' => 'px',
							'size' => -54,
						],
						'horizontal_offset_mobile' => [
							'unit' => 'px',
							'size' => -150,
						],
						'vertical_orientation'     => 'top',
						'vertical_offset'          => [
							'unit' => 'px',
							'size' => 57,
						],
						'rotate'                   => [
							'unit' => 'deg',
							'size' => 12,
						],
					],
					[
						'image'                    => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'floating_width'           => [
							'size' => 264,
							'unit' => 'px',
						],
						'floating_width_tablet'    => [
							'size' => 164,
							'unit' => 'px',
						],
						'floating_height'          => [
							'size' => 220,
							'unit' => 'px',
						],
						'floating_height_tablet'   => [
							'size' => 120,
							'unit' => 'px',
						],
						'horizontal_orientation'   => 'left',
						'horizontal_offset'        => [
							'unit' => 'px',
							'size' => -34,
						],
						'horizontal_offset_mobile' => [
							'unit' => 'px',
							'size' => -130,
						],
						'vertical_orientation'     => 'bottom',
						'vertical_offset'          => [
							'unit' => 'px',
							'size' => -97,
						],
						'vertical_offset_tablet'   => [
							'unit' => 'px',
							'size' => -50,
						],
						'rotate'                   => [
							'unit' => 'deg',
							'size' => -8,
						],
					],
					[
						'image'                  => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'floating_width'         => [
							'size' => 288,
							'unit' => 'px',
						],
						'floating_width_tablet'  => [
							'size' => 188,
							'unit' => 'px',
						],
						'floating_height'        => [
							'size' => 235,
							'unit' => 'px',
						],
						'floating_height_tablet' => [
							'size' => 135,
							'unit' => 'px',
						],
						'horizontal_orientation' => 'left',
						'horizontal_offset'      => [
							'unit' => '%',
							'size' => 50,
						],
						'vertical_orientation'   => 'bottom',
						'vertical_offset'        => [
							'unit' => 'px',
							'size' => -80,
						],
						'vertical_offset_tablet' => [
							'unit' => 'px',
							'size' => -50,
						],
						'rotate'                 => [
							'unit' => 'deg',
							'size' => 12,
						],
						'transform_offset_x'     => [
							'unit' => '%',
							'size' => -50,
						],
					],
					[
						'image'                    => [
							'url' => Utils::get_placeholder_image_src(),
						],
						'floating_width'           => [
							'size' => 288,
							'unit' => 'px',
						],
						'floating_width_tablet'    => [
							'size' => 188,
							'unit' => 'px',
						],
						'floating_height'          => [
							'size' => 235,
							'unit' => 'px',
						],
						'floating_height_tablet'   => [
							'size' => 135,
							'unit' => 'px',
						],
						'horizontal_orientation'   => 'right',
						'horizontal_offset'        => [
							'unit' => 'px',
							'size' => -96,
						],
						'horizontal_offset_mobile' => [
							'unit' => 'px',
							'size' => -150,
						],
						'vertical_orientation'     => 'bottom',
						'vertical_offset'          => [
							'unit' => 'px',
							'size' => -209,
						],
						'vertical_offset_tablet'   => [
							'unit' => 'px',
							'size' => -100,
						],
						'rotate'                   => [
							'unit' => 'deg',
							'size' => 12,
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'floating_image_size',
				'default' => 'full',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_floating',
			[
				'label' => esc_html__( 'Floating', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'floating_depth',
			[
				'label'       => esc_html__( 'Depth', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => -5,
						'max'  => 5,
						'step' => 0.1,
					],
				],
				'default'     => [
					'size' => 1,
				],
				'description' => esc_html__( 'How far the image travels. Positive moves toward the cursor, negative moves away.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'floating_sensitivity',
			[
				'label'       => esc_html__( 'Sensitivity', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.01,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.1,
				],
				'description' => esc_html__( 'Overall intensity of the movement.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'floating_ease',
			[
				'label'       => esc_html__( 'Smoothness', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.01,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.05,
				],
				'description' => esc_html__( 'Lower values create smoother, more gradual movement.', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-feature-steps' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_subtitle_style',
			[
				'label' => esc_html__( 'Subtitle', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .avalon-feature-steps__subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-feature-steps__title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_desc_style',
			[
				'label' => esc_html__( 'Description', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'selector' => '{{WRAPPER}} .avalon-feature-steps__desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_progress_style',
			[
				'label' => esc_html__( 'Progress Bar', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'progress_bar_color',
			[
				'label'     => esc_html__( 'Fill Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__fill' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'progress_bar_bg',
			[
				'label'     => esc_html__( 'Background', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__bar' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'progress_bar_height',
			[
				'label'      => esc_html__( 'Bar Thickness', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-feature-steps__bar' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'progress_number_color',
			[
				'label'     => esc_html__( 'Number Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-feature-steps__current' => 'color: {{VALUE}};',
					'{{WRAPPER}} .avalon-feature-steps__total'   => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_floating_style',
			[
				'label' => esc_html__( 'Floating Images', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'floating_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-feature-steps__floating-item span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['items'] ?? [];

		if ( empty( $items ) ) {
			return;
		}

		$count = count( $items );

		$floating_images      = $settings['floating_images'] ?? [];
		$floating_depth       = $settings['floating_depth']['size'] ?? 1;
		$floating_sensitivity = $settings['floating_sensitivity']['size'] ?? 0.1;
		$floating_ease        = $settings['floating_ease']['size'] ?? 0.05;

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-feature-steps',
				'flex',
				'flex-col',
				'justify-center',
				'gap-6px',
				'h-screen',
				'relative',
			]
		);

		$this->add_render_attribute(
			'subtitle',
			'class',
			[
				'avalon-feature-steps__subtitle',
				'text-body-1',
				'col-span-full',
				'text-center',
				'relative',
				'z-2',
			]
		);

		$this->add_render_attribute(
			'inner',
			'class',
			[
				'avalon-feature-steps__inner',
				'grid',
				'grid-cols-1',
				'gap-3',
				'lg:grid-cols-12',
				'relative',
				'z-2',
			]
		);

		$this->add_render_attribute(
			'titles',
			'class',
			[
				'avalon-feature-steps__titles',
				'relative',
				'col-span-1',
				'lg:col-span-3',
				'grid',
				'grid-area-1',
				'place-items-start',
			]
		);

		$this->add_render_attribute(
			'progress',
			'class',
			[
				'avalon-feature-steps__progress',
				'col-span-1',
				'lg:col-span-6',
				'text-center',
			]
		);

		$this->add_render_attribute(
			'progress_inner',
			'class',
			[
				'avalon-feature-steps__progress-inner',
				'inline-flex',
				'items-center',
				'justify-center',
				'gap-4',
				'mt-7',
			]
		);

		$this->add_render_attribute(
			'progress_inner',
			'style',
			[
				'--progress: ' . 100 / $count . '%',
			]
		);

		$this->add_render_attribute(
			'bar',
			'class',
			[
				'avalon-feature-steps__bar',
			]
		);

		$this->add_render_attribute(
			'fill',
			'class',
			[
				'avalon-feature-steps__fill',
			]
		);

		$this->add_render_attribute(
			'summaries',
			'class',
			[
				'avalon-feature-steps__summaries',
				'relative',
				'col-span-1',
				'lg:col-span-3',
				'grid',
				'grid-area-1',
				'place-items-start',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php
			if ( ! empty( $floating_images ) ) :
				?>
				<div class="avalon-floating-images">
				<?php
				foreach ( $floating_images as $floater ) :
					$floater_image = $floater['image'] ?? [];

					if ( empty( $floater_image['url'] ) ) {
						continue;
					}

					$h_class = 'left' === ( $floater['horizontal_orientation'] ?? 'left' ) ? 'is-h-left' : 'is-h-right';
					$v_class = 'top' === ( $floater['vertical_orientation'] ?? 'top' ) ? 'is-v-top' : 'is-v-bottom';
					?>
					<div class="elementor-repeater-item-<?php echo esc_attr( $floater['_id'] ); ?> avalon-feature-steps__floating-item absolute z-1 <?php echo esc_attr( $h_class . ' ' . $v_class ); ?> <?php echo esc_attr( ! empty( $floater['hide_on_mobile'] ) ? 'hidden md:block' : '' ); ?>">
						<span class="block ratio-image rounded-sm" data-animate="parallax-floating"
					<?php
					if ( 1 !== (float) $floating_depth ) :
						?>
						data-floating-depth="<?php echo esc_attr( $floating_depth ); ?>"<?php endif; ?>
						<?php
						if ( 0.1 !== (float) $floating_sensitivity ) :
							?>
						data-floating-sensitivity="<?php echo esc_attr( $floating_sensitivity ); ?>"<?php endif; ?>
						<?php
						if ( 0.05 !== (float) $floating_ease ) :
							?>
						data-floating-ease="<?php echo esc_attr( $floating_ease ); ?>"<?php endif; ?>>
						<?php echo Group_Control_Image_Size::get_attachment_image_html( $floater, 'floating_image_size', 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					</div>
				<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['subtitle_text'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'subtitle' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['subtitle_text'] ) ); ?>
				</div>
			<?php endif; ?>

			<div <?php $this->print_render_attribute_string( 'inner' ); ?>>

				<div <?php $this->print_render_attribute_string( 'titles' ); ?>>
					<?php foreach ( $items as $index => $item ) : ?>
						<div class="avalon-feature-steps__title<?php echo 0 === $index ? ' is-active' : ''; ?>" data-step="<?php echo esc_attr( $index ); ?>">
							<?php if ( ! empty( $item['title'] ) ) : ?>
								<h2 class="text-heading font-heading my-0"><?php echo esc_html( $item['title'] ); ?></h2>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<div <?php $this->print_render_attribute_string( 'progress' ); ?>>
					<div <?php $this->print_render_attribute_string( 'progress_inner' ); ?>>
						<span class="avalon-feature-steps__current grid grid-area-1 place-items-start text-heading caption">
							<?php foreach ( range( 1, $count ) as $i ) : ?>
								<span class="<?php echo esc_attr( 1 === $i ? 'is-active' : '' ); ?>">
									<?php echo esc_html( str_pad( $i, 2, '0', STR_PAD_LEFT ) ); ?>
								</span>
							<?php endforeach; ?>
						</span>
						<div <?php $this->print_render_attribute_string( 'bar' ); ?>>
							<div <?php $this->print_render_attribute_string( 'fill' ); ?>></div>
						</div>
						<span class="avalon-feature-steps__total caption">
							<?php echo esc_html( str_pad( (string) $count, 2, '0', STR_PAD_LEFT ) ); ?>
						</span>
					</div>
				</div>

				<div <?php $this->print_render_attribute_string( 'summaries' ); ?>>
					<?php foreach ( $items as $index => $item ) : ?>
						<div class="avalon-feature-steps__summary<?php echo 0 === $index ? ' is-active' : ''; ?>" data-step="<?php echo esc_attr( $index ); ?>">
							<?php if ( ! empty( $item['description'] ) ) : ?>
								<div class="avalon-feature-steps__desc text-body-4 mb-8">
									<?php echo wp_kses_post( nl2br( $item['description'] ) ); ?>
								</div>
							<?php endif; ?>
						<?php if ( ! empty( $item['button_text'] ) ) : ?>
							<?php
							$item_settings                 = $item;
							$item_settings['button_style'] = $settings['button_style'] ?? '';
							$this->button_text( $item_settings );
							?>
						<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

			</div>
		</div>
		<?php
	}
}
