<?php
/**
 * Hamburger Button Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Hamburger Button Widget Class
 */
class Hamburger_Button extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-hamburger-button';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'hamburger-button' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'hamburger-button' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Hamburger Button', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-menu-bar ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'hamburger', 'menu', 'toggle', 'off-canvas' ];
	}

	/**
	 * Get menu options for select control
	 *
	 * @return array
	 */
	private function get_menu_options(): array {
		$menus   = wp_get_nav_menus();
		$options = array_combine( array_column( $menus, 'slug' ), array_column( $menus, 'name' ) );

		return array_merge( [ '' => esc_html__( 'Default (from Customizer)', 'avalon-addons' ) ], $options );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Hamburger Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Menu', 'avalon-addons' ),
				'placeholder' => esc_html__( 'Enter button text', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button--white',
				'options' => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label'      => esc_html__( 'Gap Between', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hamburger_menu_section',
			[
				'label' => esc_html__( 'Hamburger Menu', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'menu',
			[
				'label'   => esc_html__( 'Select Menu', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->get_menu_options(),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text',
			[
				'label'   => esc_html__( 'Text', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Link', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'   => esc_html__( 'Link', 'avalon-addons' ),
				'type'    => Controls_Manager::URL,
				'default' => [ 'url' => '#' ],
			]
		);

		$this->add_control(
			'hamburger_links_switch',
			[
				'label'        => esc_html__( 'Use Custom Links', 'avalon-addons' ),
				'description'  => esc_html__( 'Enable to replace the links set in Customizer.', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hamburger_links',
			[
				'label'       => esc_html__( 'Hamburger Links', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ text }}}',
				'separator'   => 'before',
				'condition'   => [ 'hamburger_links_switch' => 'yes' ],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$panels = \Avalon\Theme::get_prop( 'panels' );

		if ( ! in_array( 'hamburger', $panels, true ) ) {
			\Avalon\Theme::set_prop( 'panels', 'hamburger' );
		}

		if ( ! empty( $settings['menu'] ) ) {
			\Avalon\Theme::set_prop( 'hamburger_menu', $settings['menu'] );
		}

		if ( 'yes' === $settings['hamburger_links_switch'] && ! empty( $settings['hamburger_links'] ) ) {
			$links = [];

			foreach ( $settings['hamburger_links'] as $link ) {
				if ( empty( $link['text'] ) || empty( $link['link']['url'] ) ) {
					continue;
				}

				$links[] = [
					'text' => $link['text'],
					'link' => $link['link']['url'],
				];
			}

			if ( ! empty( $links ) ) {
				\Avalon\Theme::set_prop( 'hamburger_links', $links );
			}
		}

		$button_class = 'hamburger-menu__button';

		if ( ! empty( $settings['button_style'] ) ) {
			$button_class .= ' ' . esc_attr( $settings['button_style'] );
		}

		$this->add_render_attribute(
			'button',
			'class',
			$button_class
		);

		$this->add_render_attribute(
			'button',
			'type',
			'button'
		);

		$this->add_render_attribute(
			'button',
			'aria-label',
			esc_attr__( 'Hamburger menu', 'avalon-addons' )
		);

		$this->add_render_attribute(
			'button',
			'data-toggle',
			'off-canvas'
		);

		$this->add_render_attribute(
			'button',
			'data-target',
			'avalon-hamburger-menu'
		);
		?>
		<button <?php $this->print_render_attribute_string( 'button' ); ?>>
			<?php if ( ! empty( $settings['button_text'] ) ) : ?>
				<span class="button__text hidden lg:inline uppercase"><?php echo esc_html( $settings['button_text'] ); ?></span>
			<?php endif; ?>
			<span class="button__icon grid grid-area-1 place-content-center">
				<span class="bar"></span>
				<span class="bar"></span>
				<span class="bar"></span>
			</span>
		</button>
		<?php
	}
}
