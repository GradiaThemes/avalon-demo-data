<?php
/**
 * Accordion Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Accordion Widget Class
 */
class Accordion extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-accordion';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'accordion' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'accordion' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Accordion', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-accordion ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'accordion', 'toggle', 'faq', 'collapse' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// Content section.
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Accordion', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Accordion Item', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'content',
			[
				'label'   => esc_html__( 'Content', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Accordion content goes here.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'title'   => esc_html__( 'What is included in your service?', 'avalon-addons' ),
						'content' => esc_html__( 'Our service includes comprehensive design, development, and ongoing support tailored to your specific needs.', 'avalon-addons' ),
					],
					[
						'title'   => esc_html__( 'How long does a typical project take?', 'avalon-addons' ),
						'content' => esc_html__( 'Project timelines vary based on scope and complexity. A typical project takes 4-8 weeks from discovery to launch.', 'avalon-addons' ),
					],
					[
						'title'   => esc_html__( 'Do you offer ongoing support?', 'avalon-addons' ),
						'content' => esc_html__( 'Yes, we provide ongoing maintenance and support packages to ensure your project continues to perform optimally.', 'avalon-addons' ),
					],
				],
			]
		);

		$this->add_control(
			'open_first_item',
			[
				'label'        => esc_html__( 'Open First Item', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->end_controls_section();

		// Style - Title.
		$this->start_controls_section(
			'style_title',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-accordion__title-text',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-accordion__title-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-accordion__item.is-active .avalon-accordion__title-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-accordion__item' => '--color-border-secondary: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style - Icon.
		$this->start_controls_section(
			'style_icon',
			[
				'label' => esc_html__( 'Icon', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_style',
			[
				'label'   => esc_html__( 'Icon Style', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'button--white',
				'options' => [
					''              => esc_html__( 'Default', 'avalon-addons' ),
					'button--white' => esc_html__( 'White', 'avalon-addons' ),
					'button--dark'  => esc_html__( 'Dark', 'avalon-addons' ),
					'button--gray'  => esc_html__( 'Gray', 'avalon-addons' ),
				],
			]
		);

		$this->end_controls_section();

		// Style - Content.
		$this->start_controls_section(
			'style_content',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .avalon-accordion__content-inner',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-accordion__content-inner' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-accordion__content-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['items'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-accordion' ] );

		$open_first = ! empty( $settings['open_first_item'] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php foreach ( $settings['items'] as $index => $item ) : ?>
				<?php
				$is_active  = ( $open_first && 0 === $index );
				$item_class = [ 'avalon-accordion__item', 'border-bottom', 'border-color-secondary', 'py-5' ];
				if ( $is_active ) {
					$item_class[] = 'is-active';
				}

				if ( 0 === $index ) {
					$item_class[] = 'border-top';
				}
				?>
				<div class="<?php echo esc_attr( implode( ' ', $item_class ) ); ?>">
				<div class="avalon-accordion__title flex justify-between" aria-expanded="<?php echo esc_attr( $is_active ? 'true' : 'false' ); ?>">
					<span class="avalon-accordion__title-text text-body-1 text-heading flex-1 mt-2"><?php echo wp_kses_post( $item['title'] ); ?></span>
					<div class="button button-icon <?php echo esc_attr( ! empty( $settings['icon_style'] ) ? $settings['icon_style'] : '' ); ?>">
						<span class="avalon-accordion__icon relative shrink-0" aria-hidden="true"></span>
					</div>
				</div>
				<div class="avalon-accordion__content" role="region" aria-hidden="<?php echo esc_attr( $is_active ? 'false' : 'true' ); ?>"<?php echo $is_active ? ' style="display:block"' : ''; ?>>
						<div class="avalon-accordion__content-inner text-body-3">
							<?php echo wp_kses_post( nl2br( $item['content'] ) ); ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
