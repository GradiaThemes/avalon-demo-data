<?php
/**
 * Floating Image Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Floating Image Widget Class
 */
class Floating_Image extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-floating-image';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'floating-image' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'floating-image' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Floating Image', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'floating', 'parallax', 'image', 'mouse', 'hover' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'description' => esc_html__( 'The image floats toward the mouse cursor as the visitor moves the pointer.', 'avalon-addons' ),
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image_size',
				'default' => 'full',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'floating_section',
			[
				'label' => esc_html__( 'Floating', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'depth',
			[
				'label'       => esc_html__( 'Depth', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => -5,
						'max'  => 5,
						'step' => 0.1,
					],
				],
				'default'     => [
					'size' => 1,
				],
				'description' => esc_html__( 'How far the image travels. Positive moves toward the cursor, negative moves away.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'sensitivity',
			[
				'label'       => esc_html__( 'Sensitivity', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.01,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.1,
				],
				'description' => esc_html__( 'Overall intensity of the movement.', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'ease',
			[
				'label'       => esc_html__( 'Smoothness', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.01,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.05,
				],
				'description' => esc_html__( 'Lower values create smoother, more gradual movement.', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_image_style',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'max_width',
			[
				'label'      => esc_html__( 'Max Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'vh', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'selector' => '{{WRAPPER}} .avalon-floating-image',
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .avalon-floating-image',
			]
		);

		$this->add_control(
			'css_filters_heading',
			[
				'label'     => esc_html__( 'CSS Filters', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters',
				'selector' => '{{WRAPPER}} .avalon-floating-image img',
			]
		);

		$this->add_control(
			'opacity',
			[
				'label'     => esc_html__( 'Opacity', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-floating-image img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_hover_effects',
			[
				'label' => esc_html__( 'Hover Effects', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label'        => esc_html__( 'Hover Animation', 'avalon-addons' ),
				'type'         => Controls_Manager::HOVER_ANIMATION,
				'prefix_class' => 'elementor-animation-',
			]
		);

		$this->add_control(
			'transform_heading',
			[
				'label'     => esc_html__( 'Transform', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'transform_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'vw', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 1200,
						'step' => 1,
					],
					'%'  => [
						'min'  => 5,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image:hover img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'transform_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'vh', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 1200,
						'step' => 1,
					],
					'%'  => [
						'min'  => 5,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					'{{WRAPPER}} .avalon-floating-image:hover img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'transform_offset_x',
			[
				'label'      => esc_html__( 'Offset X', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -200,
						'max'  => 200,
						'step' => 1,
					],
					'%'  => [
						'min'  => -100,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 0,
				],
			]
		);

		$this->add_responsive_control(
			'transform_offset_y',
			[
				'label'      => esc_html__( 'Offset Y', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -200,
						'max'  => 200,
						'step' => 1,
					],
					'%'  => [
						'min'  => -100,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 0,
				],
			]
		);

		$this->add_responsive_control(
			'transform_rotation',
			[
				'label'      => esc_html__( 'Rotation', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'deg', 'grad', 'rad', 'turn', 'custom' ],
				'range'      => [
					'deg' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'deg',
					'size' => 0,
				],
			]
		);

		$this->add_responsive_control(
			'transform_scale',
			[
				'label'     => esc_html__( 'Scale', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0.1,
						'max'  => 10,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-floating-image:hover img' => 'transform: translate({{transform_offset_x.SIZE}}{{transform_offset_x.UNIT}}, {{transform_offset_y.SIZE}}{{transform_offset_y.UNIT}}) rotate({{transform_rotation.SIZE}}{{transform_rotation.UNIT}}) scale({{SIZE}});',
				],
			]
		);

		$this->add_control(
			'transition_duration',
			[
				'label'     => esc_html__( 'Transition Duration', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 0.3,
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-floating-image img' => 'transition-duration: {{SIZE}}s;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-floating-image', 'inline-block', 'ratio-image', 'overflow-hidden', 'rounded-sm' ] );
		$this->add_render_attribute( 'wrapper', 'data-animate', 'parallax-floating' );

		if ( ! empty( $settings['depth']['size'] ) && 1 !== (float) $settings['depth']['size'] ) {
			$this->add_render_attribute( 'wrapper', 'data-floating-depth', $settings['depth']['size'] );
		}

		if ( ! empty( $settings['sensitivity']['size'] ) && 0.1 !== (float) $settings['sensitivity']['size'] ) {
			$this->add_render_attribute( 'wrapper', 'data-floating-sensitivity', $settings['sensitivity']['size'] );
		}

		if ( ! empty( $settings['ease']['size'] ) && 0.05 !== (float) $settings['ease']['size'] ) {
			$this->add_render_attribute( 'wrapper', 'data-floating-ease', $settings['ease']['size'] );
		}

		$image = $settings['image'] ?? [];

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php
			if ( ! empty( $image['url'] ) ) {
				echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_size', 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
		</div>
		<?php
	}
}
