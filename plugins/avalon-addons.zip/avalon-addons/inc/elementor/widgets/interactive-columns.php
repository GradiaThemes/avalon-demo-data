<?php
/**
 * Interactive Columns Widget
 *
 * Displays repeater items as equal columns pinned to the bottom.
 * On hover a column expands to 50% of the row while the others
 * share the remaining 50%, revealing description and button.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Interactive Columns Widget Class
 */
class Interactive_Columns extends Widget_Base {

	use Base\Text_Base;
	use Base\Button_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-interactive-columns';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'interactive-columns' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'interactive-columns' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Interactive Columns', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-columns ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'interactive', 'columns', 'hover', 'expand', 'showcase' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__( 'Items', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'number',
			[
				'label'       => esc_html__( 'Number', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'button_type',
			[
				'label'   => esc_html__( 'Button Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'text',
				'options' => [
					'text' => esc_html__( 'Text', 'avalon-addons' ),
					'icon' => esc_html__( 'Icon', 'avalon-addons' ),
				],
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter button text', 'avalon-addons' ),
				'condition'   => [
					'button_type' => 'text',
				],
			]
		);

		$repeater->add_control(
			'button_icon',
			[
				'label'     => esc_html__( 'Button Icon', 'avalon-addons' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => [
					'button_type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Button Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'number'      => esc_html__( '01', 'avalon-addons' ),
						'title'       => esc_html__( 'First Column', 'avalon-addons' ),
						'description' => esc_html__( 'Short description for the first column.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Learn More', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'number'      => esc_html__( '02', 'avalon-addons' ),
						'title'       => esc_html__( 'Second Column', 'avalon-addons' ),
						'description' => esc_html__( 'Short description for the second column.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Learn More', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
					[
						'number'      => esc_html__( '03', 'avalon-addons' ),
						'title'       => esc_html__( 'Third Column', 'avalon-addons' ),
						'description' => esc_html__( 'Short description for the third column.', 'avalon-addons' ),
						'button_text' => esc_html__( 'Learn More', 'avalon-addons' ),
						'button_link' => [
							'url' => '#',
						],
					],
				],
			]
		);

		$this->register_text_controls();

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'       => esc_html__( 'Height', 'avalon-addons' ),
				'description' => esc_html__( 'Default is full screen (h-screen). Set a custom height to override.', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'vh', '%', 'custom' ],
				'selectors'   => [
					'{{WRAPPER}} .avalon-interactive-columns' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Content Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-interactive-columns__inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label'     => esc_html__( 'Divider Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-interactive-columns' => '--border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_number_style',
			[
				'label' => esc_html__( 'Number', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'number_typography',
				'selector' => '{{WRAPPER}} .avalon-interactive-columns__number',
			]
		);

		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-interactive-columns__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_spacing_bottom',
			[
				'label'      => esc_html__( 'Spacing', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-interactive-columns__top' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-interactive-columns__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-interactive-columns__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_desc_style',
			[
				'label' => esc_html__( 'Description', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'selector' => '{{WRAPPER}} .avalon-interactive-columns__description',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-interactive-columns__description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['items'] ?? [];

		if ( empty( $items ) ) {
			return;
		}

		$count      = count( $items );
		$grow_hover = max( 1, $count - 1 );

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-interactive-columns',
				'flex',
				'flex-col',
				'md:flex-row',
				'relative',
				'w-full',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute( 'wrapper', 'role', 'list' );
		$this->add_render_attribute( 'wrapper', 'style', '--count: ' . (int) $count . '; --grow-hover: ' . (int) $grow_hover . ';' );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php foreach ( $items as $index => $item ) : ?>
				<?php
				$number_key = $this->get_repeater_setting_key( 'number', 'items', $index );
				$desc_key   = $this->get_repeater_setting_key( 'description', 'items', $index );
				$title_attr = 'item_title_' . $index;

				$this->add_render_attribute( $number_key, 'class', [ 'avalon-interactive-columns__number', 'h6', 'my-0' ] );
				$this->add_render_attribute( $desc_key, 'class', [ 'avalon-interactive-columns__description', 'text-body-4', 'text-emphasis', 'my-0', 'flex-1', 'sm:no-br' ] );
				$this->add_inline_editing_attributes( $number_key, 'basic' );
				$this->add_inline_editing_attributes( $desc_key, 'basic' );
				$this->add_inline_editing_attributes( $title_attr, 'basic' );
				?>
				<div class="elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?> avalon-interactive-columns__item relative flex flex-col justify-end overflow-hidden flex-auto md:flex-1" role="listitem" tabindex="0">
					<div class="avalon-interactive-columns__overlay absolute inset-0 z-1" aria-hidden="true"></div>
					<div class="avalon-interactive-columns__inner relative z-2 flex flex-col justify-end h-full px-4 py-10 lg:p-10">
						<div class="avalon-interactive-columns__top flex flex-col gap-2">
							<?php if ( ! empty( $item['number'] ) ) : ?>
								<div <?php $this->print_render_attribute_string( $number_key ); ?>><?php echo wp_kses_post( $item['number'] ); ?></div>
							<?php endif; ?>
							<?php
							if ( ! empty( $item['title'] ) ) {
								$this->text_render(
									$item['title'],
									[
										'tag'        => $settings['html_tag'] ?? 'h2',
										'size'       => $settings['size'] ?? '',
										'class'      => [ 'avalon-interactive-columns__title', 'my-0' ],
										'attr'       => $title_attr,
										'linebreaks' => $settings['linebreaks'] ?? 'yes',
									]
								);
							}
							?>
						</div>
						<div class="avalon-interactive-columns__bottom">
							<div class="avalon-interactive-columns__bottom-inner flex items-end justify-between gap-4">
								<?php if ( ! empty( $item['description'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( $desc_key ); ?>><?php echo wp_kses_post( nl2br( $item['description'] ) ); ?></div>
								<?php endif; ?>
								<?php
								if ( ! empty( $item['button_text'] ) || ! empty( $item['button_icon']['value'] ) ) {
									$item_settings                 = $item;
									$item_settings['button_style'] = $settings['button_style'] ?? '';
									echo '<div class="avalon-interactive-columns__button shrink-0">';
									$this->button_render( $item_settings );
									echo '</div>';
								}
								?>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
