<?php
/**
 * Posts Showcase Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;
use AvalonAddons\Admin\Portfolio;
use AvalonAddons\Helper;

/**
 * Posts Showcase Widget Class
 */
class Posts_Showcase extends Widget_Base {

	use Base\Text_Base;
	use Base\Hover_Cursor_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-posts-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'posts-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'posts-showcase' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Posts Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-post-list ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'posts', 'showcase', 'portfolio' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Posts', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'     => esc_html__( 'Limit', 'avalon-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'step'      => 1,
				'default'   => 6,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => esc_html__( 'Default', 'avalon-addons' ),
					'related' => esc_html__( 'Related', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'avalon-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'taxonomy_post',
			[
				'label'     => esc_html__( 'Taxonomy', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'category',
				'options'   => [
					'category' => esc_html__( 'Category', 'avalon-addons' ),
					'post_tag' => esc_html__( 'Tag', 'avalon-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'taxonomy_portfolio',
			[
				'label'     => esc_html__( 'Taxonomy', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => Portfolio::TAXONOMY_SERVICE,
				'options'   => [
					'portfolio_service' => esc_html__( 'Service', 'avalon-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_category',
			[
				'label'       => esc_html__( 'Select Category', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'category',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => '',
					'post_type'     => 'post',
					'taxonomy_post' => 'category',
				],
			]
		);

		$this->add_control(
			'select_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post_tag',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => '',
					'post_type'     => 'post',
					'taxonomy_post' => 'post_tag',
				],
			]
		);

		$this->add_control(
			'select_service',
			[
				'label'       => esc_html__( 'Select Service', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::TAXONOMY_SERVICE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => '',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_service',
				],
			]
		);

		$this->add_control(
			'include_posts_post',
			[
				'label'       => esc_html__( 'Include Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'include_posts_portfolio',
			[
				'label'       => esc_html__( 'Include Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'exclude_posts_post',
			[
				'label'       => esc_html__( 'Exclude Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'exclude_posts_portfolio',
			[
				'label'       => esc_html__( 'Exclude Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_post_post',
			[
				'label'       => esc_html__( 'Select Post', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'select_post_portfolio',
			[
				'label'       => esc_html__( 'Select Post', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'   => esc_html__( 'Order By', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'       => esc_html__( 'Date', 'avalon-addons' ),
					'title'      => esc_html__( 'Title', 'avalon-addons' ),
					'rand'       => esc_html__( 'Random', 'avalon-addons' ),
					'menu_order' => esc_html__( 'Menu Order', 'avalon-addons' ),
					'post__in'   => esc_html__( 'Custom', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => esc_html__( 'Order', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'avalon-addons' ),
					'DESC' => esc_html__( 'Descending', 'avalon-addons' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'intro_section',
			[
				'label' => esc_html__( 'Intro', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'intro_heading',
			[
				'label'       => esc_html__( 'Heading', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter heading', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->add_control(
			'intro_subheading',
			[
				'label'   => esc_html__( 'Subheading', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->register_text_controls();

		$this->add_control(
			'intro_description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
				'default'     => '',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_hover_cursor',
			[
				'label' => esc_html__( 'Hover Cursor', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_hover_cursor_controls(
			'',
			[
				'hover_cursor_type' => 'button_text_icon',
				'hover_cursor_text' => esc_html__( 'Drag', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container',
			[
				'label'   => esc_html__( 'Container', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'container--fluid',
				'options' => [
					'container'         => esc_html__( 'Container', 'avalon-addons' ),
					'container--narrow' => esc_html__( 'Container (Narrow)', 'avalon-addons' ),
					'container--fluid'  => esc_html__( 'Container (Fluid)', 'avalon-addons' ),
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vh', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'intro_opacity',
			[
				'label'      => esc_html__( 'Intro Background Opacity', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 20,
				],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase__intro-bg img' => 'opacity: {{SIZE}}%;',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_intro_style',
			[
				'label' => esc_html__( 'Intro', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'intro_heading_headding',
			[
				'label' => esc_html__( 'Heading', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .avalon-posts-showcase__intro-heading',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__intro-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'intro_heading_subheadding',
			[
				'label'     => esc_html__( 'Subheading', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subheading_typography',
				'selector' => '{{WRAPPER}} .avalon-posts-showcase__intro-subheading',
			]
		);

		$this->add_control(
			'subheading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__intro-subheading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'intro_description_heading',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-posts-showcase__intro-desc',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__intro-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_posts_style',
			[
				'label' => esc_html__( 'Posts', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'posts_navigation_heading',
			[
				'label' => esc_html__( 'Navigation', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'posts_navigation_gap',
			[
				'label'      => esc_html__( 'Spacing between titles', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase__titles' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'posts_navigation_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__title-item' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_navigation_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__title-item.is-active' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_thumbnail_heading',
			[
				'label'     => esc_html__( 'Thumbnail', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'posts_thumbnail_max_width',
			[
				'label'      => esc_html__( 'Max width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase__thumb figure' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'posts_thumbnail_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Set the image ratio. Example: 3 / 2', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-posts-showcase__thumb figure' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'posts_thumbnail_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-posts-showcase__thumb figure' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'posts_taxonomy_heading',
			[
				'label' => esc_html__( 'Taxonomy', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'posts_taxonomy_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__taxonomy' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_details_heading',
			[
				'label'     => esc_html__( 'Details', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'posts_details_button_color',
			[
				'label'     => esc_html__( 'Button Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__detail-item a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_details_button_color_hover',
			[
				'label'     => esc_html__( 'Button Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__detail-item a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_details_title_heading',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'posts_details_title_typography',
				'selector' => '{{WRAPPER}} .avalon-posts-showcase__detail-title',
			]
		);

		$this->add_control(
			'posts_details_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__detail-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'posts_details_year_heading',
			[
				'label' => esc_html__( 'Year', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'posts_details_year_typography',
				'selector' => '{{WRAPPER}} .avalon-posts-showcase__detail-year',
			]
		);

		$this->add_control(
			'posts_details_year_color',
			[
				'label'     => esc_html__( 'Year Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-posts-showcase__detail-year' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_hover_cursor_style',
			[
				'label' => esc_html__( 'Hover Cursor', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_hover_cursor_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Get the fallback theme icon for the hover cursor
	 *
	 * @param string $prefix Prefix.
	 * @return string
	 */
	protected function get_hover_cursor_icon_fallback( $prefix = '' ) {
		return 'drag';
	}

	/**
	 * Get posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_posts( array $settings ): array {
		$source = ! empty( $settings['source'] ) ? $settings['source'] : '';

		if ( 'related' === $source ) {
			return $this->get_related_posts( $settings );
		}

		return $this->get_default_posts( $settings );
	}

	/**
	 * Get default posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_default_posts( array $settings ): array {
		$post_type      = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 6;
		$order_by       = ! empty( $settings['order_by'] ) ? $settings['order_by'] : 'date';
		$order          = ! empty( $settings['order'] ) ? $settings['order'] : 'desc';

		$exclude_posts_key = 'post' === $post_type ? 'exclude_posts_post' : 'exclude_posts_portfolio';
		$exclude_ids       = [];
		if ( ! empty( $settings[ $exclude_posts_key ] ) ) {
			$exclude_ids = array_map( 'absint', explode( ',', $settings[ $exclude_posts_key ] ) );
		}

		$include_posts_key = 'post' === $post_type ? 'include_posts_post' : 'include_posts_portfolio';
		$include_ids       = [];
		if ( ! empty( $settings[ $include_posts_key ] ) ) {
			$include_ids = array_map( 'absint', explode( ',', $settings[ $include_posts_key ] ) );
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'order'                  => $order,
			'orderby'                => $order_by,
			'post__not_in'           => $exclude_ids,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( ! empty( $include_ids ) ) {
			$args['post__in'] = $include_ids;
		}

		$select_term_key = '';
		$taxonomy        = '';

		if ( 'post' === $post_type ) {
			$tax = ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category';
			if ( 'category' === $tax ) {
				$select_term_key = 'select_category';
				$taxonomy        = 'category';
			} elseif ( 'post_tag' === $tax ) {
				$select_term_key = 'select_tag';
				$taxonomy        = 'post_tag';
			}
		} else {
			$select_term_key = 'select_service';
			$taxonomy        = Portfolio::TAXONOMY_SERVICE;
		}

		if ( $select_term_key && ! empty( $settings[ $select_term_key ] ) ) {
			$term_slugs = array_filter( array_map( 'sanitize_text_field', explode( ',', $settings[ $select_term_key ] ) ) );

			if ( ! empty( $term_slugs ) && $taxonomy ) {
				$terms = get_terms(
					[
						'taxonomy' => $taxonomy,
						'slug'     => $term_slugs,
						'fields'   => 'ids',
					]
				);

				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					// phpcs:ignore
					$args['tax_query'] = [
						[
							'taxonomy' => $taxonomy,
							'terms'    => $terms,
							'field'    => 'term_id',
						],
					];
				}
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get related posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_related_posts( array $settings ): array {
		$post_type       = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page  = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 6;
		$select_post_key = 'post' === $post_type ? 'select_post_post' : 'select_post_portfolio';
		$anchor_post_id  = ! empty( $settings[ $select_post_key ] )
			? absint( $settings[ $select_post_key ] )
			: get_the_ID();

		if ( ! $anchor_post_id ) {
			return [];
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'orderby'                => 'rand',
			'post__not_in'           => [ $anchor_post_id ],
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( 'portfolio' === $post_type && post_type_exists( Portfolio::POST_TYPE ) ) {
			$terms = get_the_terms( $anchor_post_id, Portfolio::TAXONOMY_SERVICE );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$term_ids = wp_list_pluck( $terms, 'term_id' );
				// phpcs:ignore
				$args['tax_query'] = [
					[
						'taxonomy' => Portfolio::TAXONOMY_SERVICE,
						'terms'    => $term_ids,
						'field'    => 'term_id',
					],
				];
			}
		} else {
			$category_ids = wp_get_post_categories( $anchor_post_id, [ 'fields' => 'ids' ] );

			if ( ! empty( $category_ids ) ) {
				$args['category__in'] = $category_ids;
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get post taxonomy terms string
	 *
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	private function get_post_terms( \WP_Post $post ): string {
		$terms  = get_the_terms( $post->ID, 'portfolio_service' );
		$output = '';

		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $index => $term ) {
				if ( ! empty( $term->name ) ) {
					if ( $index > 0 ) {
						$output .= Helper::get_svg( 'dot' ); // phpcs:ignore
					}
					$output .= esc_html( $term->name );
				}
			}
		}

		return $output;
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts( $settings );

		if ( empty( $posts ) ) {
			return;
		}

		$first_post = $posts[0];
		?>
		<div class="avalon-posts-showcase h-screen relative overflow-hidden">
			<?php $this->render_items( $settings, $posts ); ?>
			<?php $this->render_intro( $settings, $first_post ); ?>
		</div>
		<?php
	}

	/**
	 * Render intro section
	 *
	 * @param array    $settings Widget settings.
	 * @param \WP_Post $first_post First post for background.
	 */
	private function render_intro( array $settings, \WP_Post $first_post ) {
		$this->add_render_attribute(
			'intro',
			'class',
			[
				'avalon-posts-showcase__intro',
				'absolute',
				'inset-0',
				'z-10',
				'overflow-hidden',
				'pointer-events-none',
				'py-12',
			]
		);

		$this->add_render_attribute(
			'container',
			'class',
			[
				'relative',
				'z-2',
				'h-full',
				'flex',
				'flex-col',
				'md:flex-row',
				'md:items-center',
				'justify-between',
				'gap-4',
				isset( $settings['container'] ) ? esc_attr( $settings['container'] ) : 'container--fluid',
			]
		);

		$thumb_url = get_the_post_thumbnail_url( $first_post->ID, 'full' );
		?>
		<div <?php $this->print_render_attribute_string( 'intro' ); ?>>
			<?php if ( $thumb_url ) { ?>
				<div class="avalon-posts-showcase__intro-bg bg-body absolute inset-0 z-1 ratio-image">
					<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" loading="eager" />
				</div>
			<?php } ?>
			<div <?php $this->print_render_attribute_string( 'container' ); ?>>
				<?php if ( ! empty( $settings['intro_heading'] ) ) { ?>
					<div class="avalon-posts-showcase__intro-heading flex">
					<?php
					$this->text_render(
						$settings['intro_heading'],
						[
							'tag'        => $settings['html_tag'],
							'size'       => $settings['size'],
							'attr'       => 'intro_heading',
							'linebreaks' => $settings['linebreaks'],
							'class'      => [ 'm-0' ],
						]
					);
					?>
					<?php if ( ! empty( $settings['intro_subheading'] ) ) : ?>
						<small class="avalon-posts-showcase__intro-subheading font-xs sm:no-br"><?php echo wp_kses_post( nl2br( $settings['intro_subheading'] ) ); ?></small>
					<?php endif; ?>
					</div>
				<?php } ?>
				<?php if ( ! empty( $settings['intro_description'] ) ) { ?>
					<div class="avalon-posts-showcase__intro-desc sm:no-br text-body-3"><?php echo wp_kses_post( nl2br( $settings['intro_description'] ) ); ?></div>
				<?php } ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render items section
	 *
	 * @param array $settings Widget settings.
	 * @param array $posts    Posts array.
	 */
	private function render_items( array $settings, array $posts ) {
		$this->add_render_attribute(
			'items',
			'class',
			[
				'avalon-posts-showcase__items',
				'h-full',
				'relative',

			]
		);

		$this->add_render_attribute(
			'posts_container',
			'class',
			[
				isset( $settings['container'] ) ? esc_attr( $settings['container'] ) : 'container--fluid',
				'flex',
				'flex-col',
				'md:flex-row',
				'gap-3',
				'justify-between',
				'h-full',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'items' ); ?>>
			<div <?php $this->print_render_attribute_string( 'posts_container' ); ?>>
				<?php $this->render_details( $posts ); ?>
				<?php $this->render_thumbnails( $posts ); ?>
				<?php $this->render_titles( $posts ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render title list
	 *
	 * @param array $posts Posts array.
	 */
	private function render_titles( array $posts ) {
		$this->add_render_attribute(
			'titles',
			'class',
			[
				'avalon-posts-showcase__titles',
				'flex',
				'flex-col',
				'gap-3',
				'text-right',
				'z-3',
				'relative',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'titles' ); ?>>
			<?php
			$count = count( $posts );
			for ( $i = 0; $i < $count; $i++ ) :
				$post = $posts[ $i ];
				?>
				<div class="avalon-posts-showcase__title-item inline-flex gap-2 items-center justify-end text-body-4 <?php echo 0 === $i ? 'is-active' : ''; ?>" data-index="<?php echo esc_attr( $i ); ?>">
					<?php echo esc_html( $post->post_title ); ?>
					<?php echo Helper::get_svg( 'arrow-right-1', 'ui', [ 'class' => 'font-xl' ] ); // phpcs:ignore ?>
				</div>
			<?php endfor; ?>
		</div>
		<?php
	}

	/**
	 * Render thumbnails
	 *
	 * @param array $posts Posts array.
	 */
	private function render_thumbnails( array $posts ) {
		$this->add_render_attribute(
			'thumb-wrapper',
			'class',
			[
				'avalon-posts-showcase__thumb-wrapper',
				'grid',
				'grid-area-1',
				'place-items-center',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'thumb-wrapper' ); ?>>
			<?php
			$count = count( $posts );
			for ( $i = 0; $i < $count; $i++ ) :
				$post      = $posts[ $i ];
				$thumb_url = get_the_post_thumbnail_url( $post->ID, 'full' );
				if ( ! $thumb_url ) {
					continue;
				}
				$this->add_render_attribute(
					"thumb-{$i}",
					'class',
					[
						'avalon-posts-showcase__thumb',
						0 === $i ? 'is-active' : '',
					]
				);
				?>
				<div <?php $this->print_render_attribute_string( "thumb-{$i}" ); ?> <?php $this->render_hover_cursor_attributes(); ?>>
					<?php $this->render_hover_cursor_template(); ?>
					<figure class="ratio-image rounded-sm">
						<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" class="object-cover w-full h-full" loading="lazy" />
					</figure>
					<div class="avalon-posts-showcase__taxonomy text-body-4 mt-5 flex flex-wrap justify-center items-center gap-2 leading-none"><?php echo $this->get_post_terms( $post ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				</div>
			<?php endfor; ?>
		</div>
		<?php
	}

	/**
	 * Render detail items
	 *
	 * @param array $posts Posts array.
	 */
	private function render_details( array $posts ) {
		$this->add_render_attribute(
			'details',
			'class',
			[
				'avalon-posts-showcase__details',
				'grid',
				'grid-area-1',
				'place-items-end',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'details' ); ?>>
			<?php
			$count = count( $posts );
			for ( $i = 0; $i < $count; $i++ ) :
				$post = $posts[ $i ];
				$year = get_the_date( '[Y]', $post->ID );
				?>
				<div class="avalon-posts-showcase__detail-item <?php echo 0 === $i ? 'is-active' : ''; ?>" data-index="<?php echo esc_attr( $i ); ?>">
					<a class="flex items-center gap-2 text-body-4 text-heading" href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>">
						<?php echo Helper::get_svg( 'enter', 'ui', [ 'class' => 'font-xl' ] ); // phpcs:ignore ?>
						<?php esc_html_e( 'View Project', 'avalon-addons' ); ?>
					</a>
					<div class="avalon-posts-showcase__detail-info relative mt-3 flex gap-2">
						<span class="avalon-posts-showcase__detail-title h1 my-0"><?php echo esc_html( $post->post_title ); ?></span>
						<?php if ( $year ) { ?>
							<span class="avalon-posts-showcase__year font-xs"><?php echo esc_html( $year ); ?></span>
						<?php } ?>
					</div>
				</div>
			<?php endfor; ?>
		</div>
		<?php
	}
}
