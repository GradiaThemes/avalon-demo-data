<?php
/**
 * Timezone Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Timezone Widget Class
 *
 * Displays current time with UTC offset in format "GMT+X HH:MM".
 * Supports auto-detection via browser timezone or manual selection.
 */
class Timezone extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-timezone';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'timezone' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'timezone' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Timezone', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-globe ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'timezone', 'time', 'clock', 'gmt', 'utc', 'time zone' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'auto_location',
			[
				'label'   => esc_html__( 'Auto Location', 'avalon-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'timezone',
			[
				'label'     => esc_html__( 'Timezone', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => $this->get_timezone_options(),
				'default'   => 'America/New_York',
				'condition' => [
					'auto_location' => '',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .avalon-timezone__offset, {{WRAPPER}} .avalon-timezone__time',
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-timezone__offset, {{WRAPPER}} .avalon-timezone__time' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$is_auto  = ! empty( $settings['auto_location'] );
		$tz       = $is_auto ? '' : esc_attr( $settings['timezone'] );
		$is_edit  = \Elementor\Plugin::$instance->editor->is_edit_mode();

		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-timezone', 'caption', 'text-emphasis' ] );
		$this->add_render_attribute( 'wrapper', 'data-auto', $is_auto ? '1' : '0' );

		if ( ! $is_auto ) {
			$this->add_render_attribute( 'wrapper', 'data-tz', $tz );
		}
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php
			if ( $is_edit ) :
				$data = $this->get_editor_timezone_data( $is_auto, $settings );
				?>
				<span class="avalon-timezone__offset"><?php echo esc_html( $data['offset'] ); ?></span>
				<span class="avalon-timezone__time"><?php echo esc_html( $data['time'] ); ?></span>
			<?php else : ?>
				<span class="avalon-timezone__offset"></span>
				<span class="avalon-timezone__time"></span>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Get timezone data for Elementor editor preview
	 *
	 * @param bool  $is_auto   Whether auto-detect timezone.
	 * @param array $settings  Widget settings.
	 * @return array ['offset' => string, 'time' => string]
	 */
	private function get_editor_timezone_data( $is_auto, $settings ) {
		$tz_name = $is_auto ? $this->get_detected_timezone() : ( $settings['timezone'] ?? 'UTC' );

		try {
			$tz             = new \DateTimeZone( $tz_name );
			$now            = new \DateTime( 'now', $tz );
			$offset_seconds = $tz->getOffset( $now );
			$hours          = (int) abs( $offset_seconds ) / 3600;
			$sign           = $offset_seconds >= 0 ? '+' : '-';
			$offset_str     = sprintf( 'GMT%s%d', $sign, $hours );
			$time_str       = $now->format( 'H:i' );

			return [
				'offset' => $offset_str,
				'time'   => $time_str,
			];
		} catch ( \Exception $e ) {
			return [
				'offset' => 'GMT+0',
				'time'   => gmdate( 'H:i' ),
			];
		}
	}

	/**
	 * Detect timezone from server timezone setting
	 *
	 * @return string IANA timezone name.
	 */
	private function get_detected_timezone() {
		$timezone = wp_timezone_string();

		if ( ! $timezone ) {
			$timezone = 'UTC';
		}

		return $timezone;
	}

	/**
	 * Get timezone options for SELECT2 control
	 *
	 * @return array Key => label pairs.
	 */
	private function get_timezone_options() {
		$zones = [
			'Pacific/Midway'                 => 'Midway',
			'Pacific/Honolulu'               => 'Honolulu',
			'America/Anchorage'              => 'Anchorage',
			'America/Los_Angeles'            => 'Los Angeles',
			'America/Denver'                 => 'Denver',
			'America/Chicago'                => 'Chicago',
			'America/New_York'               => 'New York',
			'America/Caracas'                => 'Caracas',
			'America/Halifax'                => 'Halifax',
			'America/St_Johns'               => "St. John's",
			'America/Sao_Paulo'              => 'São Paulo',
			'America/Argentina/Buenos_Aires' => 'Buenos Aires',
			'America/Santiago'               => 'Santiago',
			'Atlantic/South_Georgia'         => 'South Georgia',
			'Atlantic/Azores'                => 'Azores',
			'Europe/London'                  => 'London',
			'Europe/Paris'                   => 'Paris',
			'Europe/Berlin'                  => 'Berlin',
			'Europe/Madrid'                  => 'Madrid',
			'Europe/Rome'                    => 'Rome',
			'Europe/Amsterdam'               => 'Amsterdam',
			'Europe/Zurich'                  => 'Zurich',
			'Europe/Vienna'                  => 'Vienna',
			'Europe/Stockholm'               => 'Stockholm',
			'Europe/Copenhagen'              => 'Copenhagen',
			'Europe/Warsaw'                  => 'Warsaw',
			'Europe/Prague'                  => 'Prague',
			'Europe/Budapest'                => 'Budapest',
			'Europe/Bucharest'               => 'Bucharest',
			'Europe/Athens'                  => 'Athens',
			'Europe/Istanbul'                => 'Istanbul',
			'Europe/Moscow'                  => 'Moscow',
			'Asia/Dubai'                     => 'Dubai',
			'Asia/Karachi'                   => 'Karachi',
			'Asia/Kolkata'                   => 'Mumbai',
			'Asia/Colombo'                   => 'Colombo',
			'Asia/Dhaka'                     => 'Dhaka',
			'Asia/Bangkok'                   => 'Bangkok',
			'Asia/Ho_Chi_Minh'               => 'Ho Chi Minh',
			'Asia/Jakarta'                   => 'Jakarta',
			'Asia/Singapore'                 => 'Singapore',
			'Asia/Shanghai'                  => 'Shanghai',
			'Asia/Hong_Kong'                 => 'Hong Kong',
			'Asia/Taipei'                    => 'Taipei',
			'Asia/Tokyo'                     => 'Tokyo',
			'Asia/Seoul'                     => 'Seoul',
			'Australia/Perth'                => 'Perth',
			'Australia/Adelaide'             => 'Adelaide',
			'Australia/Melbourne'            => 'Melbourne',
			'Australia/Sydney'               => 'Sydney',
			'Pacific/Auckland'               => 'Auckland',
			'Pacific/Fiji'                   => 'Fiji',
		];

		return $zones;
	}
}
