<?php
/**
 * Pricing Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Pricing Widget Class
 */
class Pricing extends Widget_Base {

	use Base\Text_Base;
	use Base\Button_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-pricing';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'pricing' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'pricing' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Pricing', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-price-list ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'pricing', 'price', 'plan' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// General section.
		$this->start_controls_section(
			'general_section',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'design',
			[
				'label'   => esc_html__( 'Design', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'avalon-addons' ),
					'window'  => esc_html__( 'Window', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'layout',
			[
				'label'     => esc_html__( 'Layout', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => [
					'default'      => esc_html__( 'Default', 'avalon-addons' ),
					'price_button' => esc_html__( 'Price Button', 'avalon-addons' ),
				],
				'condition' => [
					'design' => 'default',
				],
			]
		);

		$this->add_control(
			'badges',
			[
				'label'       => esc_html__( 'Badges', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'   => [
					'design' => 'default',
					'layout' => 'price_button',
				],
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'     => esc_html__( 'Subtitle', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'separator' => 'before',
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Pricing Plan', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'description',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => '',
				'separator' => 'before',
				'condition' => [
					'design' => 'default',
				],
			]
		);

		$this->add_control(
			'media_image',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->add_control(
			'highlight',
			[
				'label'     => esc_html__( 'Highlight', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'design' => 'default',
				],
			]
		);

		$this->end_controls_section();

		// Price section.
		$this->start_controls_section(
			'price_section',
			[
				'label' => esc_html__( 'Price', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'price',
			[
				'label'       => esc_html__( 'Price', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->register_text_controls(
			[
				'html_tag' => 'div',
				'size'     => 'h4',
			],
			null,
			'price_'
		);

		$this->add_control(
			'text_before_price',
			[
				'label'       => esc_html__( 'Text Before Price', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'   => [
					'design' => 'window',
				],
			]
		);

		$this->add_control(
			'text_after_price',
			[
				'label'       => esc_html__( 'Text After Price', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'   => [
					'design' => 'window',
				],
			]
		);

		$this->end_controls_section();

		// Features section.
		$this->start_controls_section(
			'features_section',
			[
				'label' => esc_html__( 'Features', 'avalon-addons' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon',
			[
				'label'       => esc_html__( 'Icon', 'avalon-addons' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-check',
					'library' => 'fa-solid',
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'feature_title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'feature_content',
			[
				'label'   => esc_html__( 'Content', 'avalon-addons' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => '',
			]
		);

		$this->add_control(
			'features',
			[
				'label'       => esc_html__( 'Features', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ feature_title }}}',
				'default'     => [
					[
						'feature_title' => esc_html__( 'Feature 1', 'avalon-addons' ),
					],
					[
						'feature_title' => esc_html__( 'Feature 2', 'avalon-addons' ),
					],
					[
						'feature_title' => esc_html__( 'Feature 3', 'avalon-addons' ),
					],
				],
			]
		);

		$this->end_controls_section();

		// Button section.
		$this->start_controls_section(
			'button_section',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
			]
		);

		$this->register_button_controls();

		$this->end_controls_section();

		$this->register_style_controls();
	}

	/**
	 * Register widget style controls
	 */
	protected function register_style_controls() {

		// Wrapper section.
		$this->start_controls_section(
			'style_wrapper',
			[
				'label' => esc_html__( 'Wrapper', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'wrapper_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .avalon-pricing',
			]
		);

		$this->add_control(
			'wrapper_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing' => '--color-border-secondary: {{VALUE}};',
				],
				'condition' => [
					'design' => 'default',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Badge section.
		$this->start_controls_section(
			'style_badge',
			[
				'label'     => esc_html__( 'Badge', 'avalon-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout' => 'price_button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'badge_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__badge',
			]
		);

		$this->add_control(
			'badge_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__badge' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'badge_top',
			[
				'label'      => esc_html__( 'Top', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__badge' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_right',
			[
				'label'      => esc_html__( 'Right', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__badge' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__badge' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Highlight section.
		$this->start_controls_section(
			'style_highlight',
			[
				'label'     => esc_html__( 'Highlight', 'avalon-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'highlight' => 'yes',
				],
			]
		);

		$this->add_control(
			'highlight_heading_color',
			[
				'label'     => esc_html__( 'Heading Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing.highlight--yes' => '--color-heading: {{VALUE}}; --color-primary: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'highlight_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .avalon-pricing.highlight--yes::before',
			]
		);

		$this->end_controls_section();

		// Title section.
		$this->start_controls_section(
			'style_title',
			[
				'label' => esc_html__( 'Title', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		// Description section.
		$this->start_controls_section(
			'style_description',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'design' => 'default',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		// Window header section.
		$this->start_controls_section(
			'style_window_header',
			[
				'label'     => esc_html__( 'Window Header', 'avalon-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->add_control(
			'window_dots_heading',
			[
				'label' => esc_html__( 'Dots', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'window_dots_size',
			[
				'label'      => esc_html__( 'Size', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'window_dots_gap',
			[
				'label'      => esc_html__( 'Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__dots' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'window_subtitle_heading',
			[
				'label'     => esc_html__( 'Subtitle', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'window_subtitle_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__subtitle',
			]
		);

		$this->add_control(
			'window_subtitle_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'window_image_heading',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'window_image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'window_image_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'window_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__image' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Price section.
		$this->start_controls_section(
			'style_price',
			[
				'label' => esc_html__( 'Price', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__price',
			]
		);

		$this->add_control(
			'price_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__price' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'price_text_before_after_heading',
			[
				'label'     => esc_html__( 'Text Before/After', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'price_before_after_typography',
				'selector'  => '{{WRAPPER}} .avalon-pricing__price-text',
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->add_control(
			'price_before_after_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__price-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'design' => 'window',
				],
			]
		);

		$this->end_controls_section();

		// Features section.
		$this->start_controls_section(
			'style_features',
			[
				'label' => esc_html__( 'Features', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'feature_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'feature_icon_size',
			[
				'label'      => esc_html__( 'Size', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-pricing__feature-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'feature_icon_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__feature-icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_title_heading',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'feature_title_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__feature-title',
			]
		);

		$this->add_control(
			'feature_title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__feature-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_content_heading',
			[
				'label'     => esc_html__( 'Content', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'feature_content_typography',
				'selector' => '{{WRAPPER}} .avalon-pricing__feature-content',
			]
		);

		$this->add_control(
			'feature_content_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-pricing__feature-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		// Button section.
		$this->start_controls_section(
			'style_button',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( 'window' === $settings['design'] ) {
			$this->render_window( $settings );
		} elseif ( 'price_button' === ( $settings['layout'] ?? '' ) ) {
			$this->render_price_button( $settings );
		} else {
			$this->render_default( $settings );
		}
	}

	/**
	 * Render default design
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_default( $settings ) {
		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-pricing', 'relative', 'rounded-xl', 'p-12', 'yes' === $settings['highlight'] ? 'highlight--yes' : '' ] );

		$this->add_render_attribute( 'title', 'class', [ 'avalon-pricing__title', 'my-0', 'text-body-1', 'text-heading' ] );

		$this->add_render_attribute( 'description', 'class', [ 'avalon-pricing__description', 'text-body-4', 'text-subtle' ] );

		$this->add_render_attribute( 'features', 'class', [ 'avalon-pricing__features' ] );
		$this->add_render_attribute( 'button_wrapper', 'class', [ 'avalon-pricing__button' ] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $settings['title'] ) || ! empty( $settings['description'] ) ) : ?>
				<div class="flex flex-col gap-1 border-bottom border-color-secondary pb-8 mb-4">
				<?php if ( ! empty( $settings['title'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['title'] ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'description' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['description'] ) ); ?>
					</div>
				<?php endif; ?>

				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['price'] ) ) : ?>
				<?php
				$this->text_render(
					$settings['price'],
					[
						'tag'        => $settings['price_html_tag'],
						'size'       => $settings['price_size'],
						'attr'       => 'price',
						'class'      => [ 'avalon-pricing__price', 'my-0' ],
						'linebreaks' => $settings['price_linebreaks'],
					]
				);
				?>
			<?php endif; ?>

			<?php if ( ! empty( $settings['features'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'features' ); ?>>
					<?php foreach ( $settings['features'] as $index => $feature ) : ?>
						<div class="avalon-pricing__feature grid gap-3 grid-cols-2 border-top border-color-secondary pt-4 mt-4">
							<div class="avalon-pricing__feature-left">
								<div class="flex gap-3 text-body-3 items-center">
									<?php if ( ! empty( $feature['icon']['value'] ) ) : ?>
										<span class="avalon-pricing__feature-icon avalon-svg-icon text-heading">
											<?php
											\Elementor\Icons_Manager::render_icon(
												$feature['icon'],
												[
													'aria-hidden' => 'true',
													'fill' => 'currentColor',
												]
											);
											?>
										</span>
									<?php endif; ?>

									<?php if ( ! empty( $feature['feature_title'] ) ) : ?>
										<span class="avalon-pricing__feature-title text-emphasis">
											<?php echo wp_kses_post( $feature['feature_title'] ); ?>
										</span>
									<?php endif; ?>
								</div>
							</div>

							<div class="avalon-pricing__feature-content text-right text-body-4 text-emphasis">
								<?php if ( ! empty( $feature['feature_content'] ) ) : ?>
									<?php echo wp_kses_post( $feature['feature_content'] ); ?>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div <?php $this->print_render_attribute_string( 'button_wrapper' ); ?>>
				<?php $this->button_render( $settings ); ?>
			</div>

		</div>
		<?php
	}

	/**
	 * Render price button design
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_price_button( $settings ) {
		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-pricing', 'avalon-pricing--price-button', 'relative', 'rounded-xl', 'py-8', 'px-4', 'md:px-8', 'yes' === $settings['highlight'] ? 'highlight--yes' : '' ] );

		$this->add_render_attribute( 'title', 'class', [ 'avalon-pricing__title', 'my-0', 'text-body-3', 'text-heading' ] );

		$this->add_render_attribute( 'description', 'class', [ 'avalon-pricing__description', 'text-body-4', 'text-subtle' ] );

		$this->add_render_attribute( 'features', 'class', [ 'avalon-pricing__features' ] );
		$this->add_render_attribute( 'button_wrapper', 'class', [ 'avalon-pricing__button', 'mt-8' ] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $settings['badges'] ) ) : ?>
				<span class="avalon-pricing__badge z-1 inline-flex items-center justify-center text-body-4 font-medium circle">
					<?php echo wp_kses_post( $settings['badges'] ); ?>
				</span>
			<?php endif; ?>

			<?php if ( ! empty( $settings['title'] ) || ! empty( $settings['description'] ) ) : ?>
				<div class="flex flex-col gap-1 mb-8">
				<?php if ( ! empty( $settings['title'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['title'] ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'description' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['description'] ) ); ?>
					</div>
				<?php endif; ?>

				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['price'] ) ) : ?>
				<?php
				$this->text_render(
					$settings['price'],
					[
						'tag'        => $settings['price_html_tag'],
						'size'       => $settings['price_size'],
						'attr'       => 'price',
						'class'      => [ 'avalon-pricing__price', 'my-0' ],
						'linebreaks' => $settings['price_linebreaks'],
					]
				);
				?>
			<?php endif; ?>

			<div <?php $this->print_render_attribute_string( 'button_wrapper' ); ?>>
				<?php $this->button_render( $settings ); ?>
			</div>

			<?php if ( ! empty( $settings['features'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'features' ); ?>>
					<?php foreach ( $settings['features'] as $index => $feature ) : ?>
						<div class="avalon-pricing__feature border-top border-color-secondary pt-8 mt-8">
							<div class="flex gap-3 text-body-3 items-center">
								<?php if ( ! empty( $feature['icon']['value'] ) ) : ?>
									<span class="avalon-pricing__feature-icon avalon-svg-icon text-heading">
										<?php
										\Elementor\Icons_Manager::render_icon(
											$feature['icon'],
											[
												'aria-hidden' => 'true',
												'fill' => 'currentColor',
											]
										);
										?>
									</span>
								<?php endif; ?>

								<?php if ( ! empty( $feature['feature_title'] ) ) : ?>
									<span class="avalon-pricing__feature-title text-emphasis">
										<?php echo wp_kses_post( $feature['feature_title'] ); ?>
									</span>
								<?php endif; ?>
							</div>

							<?php if ( ! empty( $feature['feature_content'] ) ) : ?>
								<div class="avalon-pricing__feature-content text-body-4 text-emphasis">
									<?php echo wp_kses_post( $feature['feature_content'] ); ?>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

		</div>
		<?php
	}

	/**
	 * Render window design
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_window( $settings ) {
		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-pricing', 'avalon-pricing--window', 'relative', 'rounded-sm', 'border', 'h-full' ] );

		$this->add_render_attribute( 'header', 'class', [ 'avalon-pricing__header', 'flex', 'items-center', 'py-3', 'px-26', 'relative' ] );
		$this->add_render_attribute( 'body', 'class', [ 'avalon-pricing__body', 'p-4', 'md:p-8', 'relative', 'h-full' ] );

		$this->add_render_attribute( 'title', 'class', [ 'avalon-pricing__title', 'my-0', 'h5', 'text-heading' ] );

		$this->add_render_attribute( 'features', 'class', [ 'avalon-pricing__features', 'flex', 'flex-col', 'mt-12', 'gap-6' ] );

		$this->add_render_attribute( 'button_wrapper', 'class', [ 'avalon-pricing__button' ] );

		$has_image = ! empty( $settings['media_image']['url'] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'header' ); ?>>
				<div class="flex items-center gap-2 absolute top-1/2 left-5 -translate-y-1/2">
					<span class="avalon-pricing__dot avalon-pricing__dot--red circle"></span>
					<span class="avalon-pricing__dot avalon-pricing__dot--yellow circle"></span>
					<span class="avalon-pricing__dot avalon-pricing__dot--green circle"></span>
				</div>
				<?php if ( ! empty( $settings['subtitle'] ) ) : ?>
					<div class="avalon-pricing__subtitle flex-1 text-center caption uppercase">
						<?php echo wp_kses_post( $settings['subtitle'] ); ?>
					</div>
				<?php endif; ?>
			</div>

			<div <?php $this->print_render_attribute_string( 'body' ); ?>>
				<?php if ( ! empty( $settings['title'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['title'] ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( $has_image ) : ?>
					<div class="avalon-pricing__image absolute right-0 top-8 ratio-image">
						<img src="<?php echo esc_url( $settings['media_image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" />
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $settings['features'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'features' ); ?>>
						<?php foreach ( $settings['features'] as $feature ) : ?>
							<div class="flex gap-2 items-center text-body-3">
								<?php if ( ! empty( $feature['icon']['value'] ) ) : ?>
									<span class="avalon-pricing__feature-icon avalon-svg-icon text-heading">
										<?php
										\Elementor\Icons_Manager::render_icon(
											$feature['icon'],
											[
												'aria-hidden' => 'true',
												'fill' => 'currentColor',
											]
										);
										?>
									</span>
								<?php endif; ?>

								<?php if ( ! empty( $feature['feature_title'] ) ) : ?>
									<span class="avalon-pricing__feature-title text-emphasis">
										<?php echo wp_kses_post( $feature['feature_title'] ); ?>
									</span>
								<?php endif; ?>
							</div>

							<?php if ( ! empty( $feature['feature_content'] ) ) : ?>
								<div class="avalon-pricing__feature-content text-body-4 text-emphasis">
									<?php echo wp_kses_post( $feature['feature_content'] ); ?>
								</div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<div class="flex flex-col md:flex-row md:items-end justify-between gap-x-2 gap-y-8 mt-12 md:mt-24">
					<div class="flex flex-col gap-2">
						<?php if ( ! empty( $settings['text_before_price'] ) ) : ?>
							<span class="avalon-pricing__price-text h5 text-subtle my-0">
								<?php echo wp_kses_post( $settings['text_before_price'] ); ?>
							</span>
						<?php endif; ?>

						<?php if ( ! empty( $settings['price'] ) ) : ?>
							<?php
							$this->text_render(
								$settings['price'],
								[
									'tag'        => $settings['price_html_tag'],
									'size'       => $settings['price_size'],
									'attr'       => 'price',
									'class'      => [ 'avalon-pricing__price', 'my-0' ],
									'linebreaks' => $settings['price_linebreaks'],
								]
							);
							?>
						<?php endif; ?>

						<?php if ( ! empty( $settings['text_after_price'] ) ) : ?>
							<span class="avalon-pricing__price-text text-body-4 text-subtle">
								<?php echo wp_kses_post( $settings['text_after_price'] ); ?>
							</span>
						<?php endif; ?>
					</div>

					<div <?php $this->print_render_attribute_string( 'button_wrapper' ); ?>>
						<?php $this->button_render( $settings ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
