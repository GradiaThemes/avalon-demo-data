<?php
/**
 * Posts Carousel Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use AvalonAddons\Elementor\Elementor;
use AvalonAddons\Admin\Portfolio;

/**
 * Posts Carousel Widget Class
 */
class Posts_Carousel extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-posts-carousel';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'posts-carousel' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'posts-carousel' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Posts Carousel', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-carousel ' . Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'posts', 'carousel' ];
	}

	/**
	 * Cached posts to avoid running the query twice.
	 *
	 * @var array|null
	 */
	protected $posts_cache = null;

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view'    => [
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'space_between'      => [
				'desktop' => 16,
				'tablet'  => 16,
				'mobile'  => 16,
			],
			'infinite'           => '1',
			'navigation'         => 'arrows',
			'show_side_overflow' => 'yes',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Posts Carousel', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'     => esc_html__( 'Limit', 'avalon-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'step'      => 1,
				'default'   => 10,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => esc_html__( 'Default', 'avalon-addons' ),
					'related' => esc_html__( 'Related', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'avalon-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'taxonomy_post',
			[
				'label'     => esc_html__( 'Taxonomy', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'category',
				'options'   => [
					'category' => esc_html__( 'Category', 'avalon-addons' ),
					'post_tag' => esc_html__( 'Tag', 'avalon-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'taxonomy_portfolio',
			[
				'label'     => esc_html__( 'Taxonomy', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => Portfolio::TAXONOMY_SERVICE,
				'options'   => [
					'portfolio_service' => esc_html__( 'Service', 'avalon-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_category',
			[
				'label'       => esc_html__( 'Select Category', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'category',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => '',
					'post_type'     => 'post',
					'taxonomy_post' => 'category',
				],
			]
		);

		$this->add_control(
			'select_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post_tag',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => '',
					'post_type'     => 'post',
					'taxonomy_post' => 'post_tag',
				],
			]
		);

		$this->add_control(
			'select_service',
			[
				'label'       => esc_html__( 'Select Service', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::TAXONOMY_SERVICE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => '',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_service',
				],
			]
		);

		$this->add_control(
			'include_posts_post',
			[
				'label'       => esc_html__( 'Include Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'include_posts_portfolio',
			[
				'label'       => esc_html__( 'Include Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'exclude_posts_post',
			[
				'label'       => esc_html__( 'Exclude Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'exclude_posts_portfolio',
			[
				'label'       => esc_html__( 'Exclude Posts', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_post_post',
			[
				'label'       => esc_html__( 'Select Post', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'select_post_portfolio',
			[
				'label'       => esc_html__( 'Select Post', 'avalon-addons' ),
				'type'        => 'avalon-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'   => esc_html__( 'Order By', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'       => esc_html__( 'Date', 'avalon-addons' ),
					'title'      => esc_html__( 'Title', 'avalon-addons' ),
					'rand'       => esc_html__( 'Random', 'avalon-addons' ),
					'menu_order' => esc_html__( 'Menu Order', 'avalon-addons' ),
					'post__in'   => esc_html__( 'Custom', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => esc_html__( 'Order', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'avalon-addons' ),
					'DESC' => esc_html__( 'Descending', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'hide_article_term_date',
			[
				'label'     => esc_html__( 'Hide Term & Date', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} article .entry-meta' => 'display: none;',
				],
				'condition' => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'hide_article_title',
			[
				'label'     => esc_html__( 'Hide Title', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'{{WRAPPER}} article .article-title' => 'display: none;',
				],
				'condition' => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'hide_article_button',
			[
				'label'     => esc_html__( 'Hide Button', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'{{WRAPPER}} article .button' => 'display: none;',
					'{{WRAPPER}} .swiper'         => 'margin-bottom: 0; padding-bottom: 0;',
				],
				'condition' => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'hide_article_summary_portfolio',
			[
				'label'     => esc_html__( 'Hide Summary', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .article-project span:not(.article-thumbnail)' => 'display: none;',
				],
				'condition' => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_aspect_ratio',
			[
				'label'       => esc_html__( 'Thumbnail Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Set the image ratio. Example: 3 / 2', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .article-thumbnail' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'lightbox_enabled',
			[
				'label' => esc_html__( 'Enable Lightbox', 'avalon-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'hover_cursor',
			[
				'label'        => esc_html__( 'Hover Cursor', 'avalon-addons' ),
				'description'  => esc_html__( 'Remove the default hover cursor from the article cards.', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'condition'    => [
					'post_type' => 'post',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'posts-carousel__slider', 'has-spacing' ];
	}

	/**
	 * Get manual attributes.
	 *
	 * @return array
	 */
	protected function get_manual_attributes(): array {
		$settings = $this->get_settings_for_display();

		if ( 'yes' === $settings['lightbox_enabled'] ) {
			return [ 'data-lightbox' => 'slider' ];
		}

		return [];
	}

	/**
	 * Get posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_posts( array $settings ): array {
		$source = ! empty( $settings['source'] ) ? $settings['source'] : '';

		if ( 'related' === $source ) {
			return $this->get_related_posts( $settings );
		}

		return $this->get_default_posts( $settings );
	}

	/**
	 * Get custom posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_default_posts( array $settings ): array {
		$post_type      = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$order_by       = ! empty( $settings['order_by'] ) ? $settings['order_by'] : 'date';
		$order          = ! empty( $settings['order'] ) ? $settings['order'] : 'desc';

		$taxonomy = 'post' === $post_type
			? ( ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category' )
			: ( ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : Portfolio::TAXONOMY_SERVICE );

		$exclude_posts_key = 'post' === $post_type ? 'exclude_posts_post' : 'exclude_posts_portfolio';
		$exclude_ids       = [];
		if ( ! empty( $settings[ $exclude_posts_key ] ) ) {
			$exclude_ids = array_map( 'absint', explode( ',', $settings[ $exclude_posts_key ] ) );
		}

		$include_posts_key = 'post' === $post_type ? 'include_posts_post' : 'include_posts_portfolio';
		$include_ids       = [];
		if ( ! empty( $settings[ $include_posts_key ] ) ) {
			$include_ids = array_map( 'absint', explode( ',', $settings[ $include_posts_key ] ) );
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'order'                  => $order,
			'orderby'                => $order_by,
			'post__not_in'           => $exclude_ids,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( ! empty( $include_ids ) ) {
			$args['post__in'] = $include_ids;
		}

		$select_term_key = '';
		if ( 'post' === $post_type ) {
			$tax = ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category';
			if ( 'category' === $tax ) {
				$select_term_key = 'select_category';
				$taxonomy        = 'category';
			} elseif ( 'post_tag' === $tax ) {
				$select_term_key = 'select_tag';
				$taxonomy        = 'post_tag';
			}
		} else {
			$select_term_key = 'select_service';
			$taxonomy        = Portfolio::TAXONOMY_SERVICE;
		}

		if ( $select_term_key && ! empty( $settings[ $select_term_key ] ) ) {
			$term_slugs = array_filter( array_map( 'sanitize_text_field', explode( ',', $settings[ $select_term_key ] ) ) );

			if ( ! empty( $term_slugs ) ) {
				$terms = get_terms(
					[
						'taxonomy' => $taxonomy,
						'slug'     => $term_slugs,
						'fields'   => 'ids',
					]
				);

				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					// phpcs:ignore
					$args['tax_query'] = [
						[
							'taxonomy' => $taxonomy,
							'terms'    => $terms,
							'field'    => 'term_id',
						],
					];
				}
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get related posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_related_posts( array $settings ): array {
		$post_type       = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page  = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$select_post_key = 'post' === $post_type ? 'select_post_post' : 'select_post_portfolio';
		$anchor_post_id  = ! empty( $settings[ $select_post_key ] )
			? absint( $settings[ $select_post_key ] )
			: get_the_ID();

		if ( ! $anchor_post_id ) {
			return [];
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'orderby'                => 'rand',
			'post__not_in'           => [ $anchor_post_id ],
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( 'portfolio' === $post_type && post_type_exists( Portfolio::POST_TYPE ) ) {
			$terms = get_the_terms( $anchor_post_id, Portfolio::TAXONOMY_SERVICE );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$term_ids = wp_list_pluck( $terms, 'term_id' );
				// phpcs:ignore
				$args['tax_query'] = [
					[
						'taxonomy' => Portfolio::TAXONOMY_SERVICE,
						'terms'    => $term_ids,
						'field'    => 'term_id',
					],
				];
			}
		} else {
			$category_ids = wp_get_post_categories( $anchor_post_id, [ 'fields' => 'ids' ] );

			if ( ! empty( $category_ids ) ) {
				$args['category__in'] = $category_ids;
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings      = $this->get_settings_for_display();
		$posts         = null !== $this->posts_cache ? $this->posts_cache : $this->get_posts( $settings );
		$post_type     = $settings['post_type'] ?? 'post';
		$template_args = [
			'class'   => 'post-carousel-item swiper-slide swiper-slide--stretch',
			'animate' => true,
		];

		if ( 'post' === $post_type && 'yes' === ( $settings['hover_cursor'] ?? '' ) ) {
			$template_args['hover_cursor'] = true;
		}

		if ( empty( $posts ) ) {
			return;
		}

		foreach ( $posts as $post ) {
			setup_postdata( $GLOBALS['post'] = $post ); // phpcs:ignore

			if ( 'yes' === $settings['lightbox_enabled'] ) {
				?>
				<div class="post-carousel-item swiper-slide swiper-slide--stretch" data-lightbox="item">
				<?php
					get_template_part(
						'template-parts/content',
						$post_type,
						$template_args
					);

					$this->render_lightbox_template( $post_type, $post->ID );
				?>
				</div>
				<?php
			} else {
				get_template_part(
					'template-parts/content',
					$post_type,
					$template_args
				);
			}
		}

		wp_reset_postdata();
	}

	/**
	 * Render widget output.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts( $settings );

		if ( empty( $posts ) ) {
			return;
		}

		$this->posts_cache = $posts;
		?>
		<div class="posts-carousel posts-carousel--elementor">
			<?php $this->render_carousel(); ?>
		</div>
		<?php
	}

	/**
	 * Render lightbox template.
	 *
	 * @param string $post_type Post type.
	 * @param int    $post      Post ID.
	 *
	 * @return void
	 */
	protected function render_lightbox_template( $post_type = 'post', $post = null ) {
		$post = null === $post ? get_the_ID() : $post;

		?>
		<template data-lightbox="header">
			<div class="posts-carousel-lightbox__title">
				<?php the_title(); ?> — <?php the_time( 'Y' ); ?>
			</div>
		</template>
		<template data-lightbox="body">
			<div class="posts-carousel-lightbox__image relative ratio-image w-full h-full">
				<?php the_post_thumbnail(); ?>
				<div class="posts-carousel-lightbox__terms absolute bottom-0 left-0 flex flex-wrap md:flex-col md:items-start gap-2 p-3 md:gap-4 md:p-6">
					<?php
					if ( 'portfolio' === $post_type ) {
						$taxonomy = \AvalonAddons\Admin\Portfolio::TAXONOMY_SERVICE;

						if ( has_term( '', $taxonomy ) ) {
							$terms = get_the_terms( $post, $taxonomy );

							if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
								foreach ( $terms as $term ) {
									?>
									<span><?php echo esc_html( $term->name ); ?></span>
									<?php
								}
							}
						}
					} else {
						the_tags( '', '', '' );
					}
					?>
				</div>
			</div>
		</template>
		<?php
	}
}
