<?php
/**
 * Testimonial Showcase Widget
 *
 * Displays testimonials with a thumbnail avatar slider on top and a main
 * content slider below. The thumbnail slider shows centered avatar images
 * with inactive items blurred. The main slider displays one testimonial
 * at a time with name, role, and comment.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor;

/**
 * Testimonial Showcase Widget Class
 */
class Testimonial_Showcase extends Base\Carousel_Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-testimonial-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'testimonial-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'testimonial-showcase' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Testimonial Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel ' . Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'testimonial', 'showcase', 'quote', 'slider', 'thumb' ];
	}

	/**
	 * Register widget controls.
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Testimonials', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'avalon-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'text',
			[
				'label' => esc_html__( 'Quote', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'name',
			[
				'label' => esc_html__( 'Name', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Job Title', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => esc_html__( 'Testimonials', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'text'  => esc_html__( 'This is an amazing product, highly recommended.', 'avalon-addons' ),
						'name'  => esc_html__( 'John Doe', 'avalon-addons' ),
						'title' => esc_html__( 'CEO, Company', 'avalon-addons' ),
					],
					[
						'text'  => esc_html__( 'A wonderful experience from start to finish.', 'avalon-addons' ),
						'name'  => esc_html__( 'Jane Smith', 'avalon-addons' ),
						'title' => esc_html__( 'Marketing Director', 'avalon-addons' ),
					],
					[
						'text'  => esc_html__( 'Outstanding quality and great support.', 'avalon-addons' ),
						'name'  => esc_html__( 'Robert Brown', 'avalon-addons' ),
						'title' => esc_html__( 'Product Manager', 'avalon-addons' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_carousel_settings',
			[
				'label' => esc_html__( 'Carousel Settings', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls(
			[
				'autoplay',
				'autoplay_speed',
				'speed',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_thumbnails_style',
			[
				'label' => esc_html__( 'Thumbnails', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'thumb_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Set the image ratio. Example: 1 / 1', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-testimonial-showcase__thumbs .swiper' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumb_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__thumbs .swiper' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumb_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__thumbs .swiper' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumb_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumb_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__image' => '--padding: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumb_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__image' => '--ts-progress-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'thumb_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__image' => '--border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'progress_heading',
			[
				'label'     => esc_html__( 'Autoplay Progress', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'progress_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__image' => '--ts-progress-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'index_heading',
			[
				'label'     => esc_html__( 'Number', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'index_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-showcase__index',
			]
		);

		$this->add_control(
			'index_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__index' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content Style', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'spacing_thumbs_content',
			[
				'label'      => esc_html__( 'Spacing Between Thumbnails and Content', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__thumbs .swiper' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'contents_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-testimonial-showcase__contents-container' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'name_heading',
			[
				'label' => esc_html__( 'Name', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-showcase__name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'role_heading',
			[
				'label' => esc_html__( 'Role', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'role_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-showcase__role',
			]
		);

		$this->add_control(
			'role_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__role' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'quote_heading',
			[
				'label' => esc_html__( 'Quote', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'quote_typography',
				'selector' => '{{WRAPPER}} .avalon-testimonial-showcase__quote',
			]
		);

		$this->add_control(
			'quote_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-testimonial-showcase__quote' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the thumbnail slides.
	 *
	 * @param array $items Testimonial items.
	 */
	protected function render_thumbnails( $items ) {
		foreach ( $items as $index => $item ) {
			$image_id  = ! empty( $item['image']['id'] ) ? $item['image']['id'] : 0;
			$image_url = ! empty( $item['image']['url'] ) ? $item['image']['url'] : '';

			if ( empty( $image_id ) && empty( $image_url ) ) {
				continue;
			}

			$slide_key = 'thumb_slide_' . $index;
			$this->add_render_attribute(
				$slide_key,
				'class',
				[
					'swiper-slide',
					'avalon-testimonial-showcase__thumb',
					'relative',
				]
			);
			?>
			<div <?php $this->print_render_attribute_string( $slide_key ); ?>>
				<div class="avalon-testimonial-showcase__image ratio-image w-full h-full circle p-6px">
					<?php if ( $image_id ) : ?>
						<?php
						echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							$image_id,
							'full',
						);
						?>
					<?php else : ?>
						<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $item['name'] ?? '' ); ?>" />
					<?php endif; ?>
				</div>
				<div class="avalon-testimonial-showcase__index caption absolute left-0 top-0 pointer-events-none">
					<?php echo esc_html( str_pad( $index + 1, 2, '0', STR_PAD_LEFT ) . '.' ); ?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render the main content slides.
	 *
	 * @param array $items Testimonial items.
	 */
	protected function render_main_slides( $items ) {
		foreach ( $items as $index => $item ) {
			$slide_key = 'main_slide_' . $index;
			$this->add_render_attribute(
				$slide_key,
				'class',
				[
					'swiper-slide',
					'avalon-testimonial-showcase__slide',
				]
			);
			?>
			<div <?php $this->print_render_attribute_string( $slide_key ); ?>>
				<div class="avalon-testimonial-showcase__content flex flex-col items-center text-center">
					<?php if ( ! empty( $item['name'] ) ) : ?>
						<h3 class="avalon-testimonial-showcase__name text-body-3 my-0 mb-1"><?php echo wp_kses_post( $item['name'] ); ?></h3>
					<?php endif; ?>

					<?php if ( ! empty( $item['title'] ) ) : ?>
						<span class="avalon-testimonial-showcase__role text-body-3 mb-10"><?php echo wp_kses_post( $item['title'] ); ?></span>
					<?php endif; ?>

					<?php if ( ! empty( $item['text'] ) ) : ?>
						<div class="avalon-testimonial-showcase__quote h5 my-0 sm:no-br"><?php echo wp_kses_post( nl2br( $item['text'] ) ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render widget output.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['testimonials'] ?? [];

		// Keep main + thumbs on the SAME item set (1:1 slide count and
		// index labels). Thumbs require an image, so drop items without
		// one before rendering either slider.
		$items = array_values(
			array_filter(
				$items,
				static function ( $item ) {
					return ! empty( $item['image']['id'] ) || ! empty( $item['image']['url'] );
				}
			)
		);

		if ( empty( $items ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-testimonial-showcase', isset( $settings['autoplay'] ) && 'yes' === $settings['autoplay'] ? 'autoplay--enabled' : '' ] );

		$thumb_id = 'avalon-testimonial-showcase-thumbs-' . $this->get_id();

		$thumb_attrs = [
			'effect'             => 'slide',
			'slides-per-view'    => '1',
			'space-between'      => '80',
			'speed'              => '800',
			'loop'               => 'fill',
			'centered-slides'    => 'yes',
			'show_side_overflow' => 'yes',
		];

		$autoplay   = isset( $settings['autoplay'] ) && 'yes' === $settings['autoplay'] ? $settings['autoplay_speed'] : '';
		$main_attrs = [
			'effect'          => 'slide',
			'slides-per-view' => '1',
			'space-between'   => '20',
			'speed'           => $settings['speed'] ?? '800',
			'loop'            => '1',
			'autoplay'        => $autoplay,
			'data-thumbs'     => '#' . $thumb_id,
		];
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<gt-slider id="<?php echo esc_attr( $thumb_id ); ?>" class="avalon-testimonial-showcase__thumbs swiper-show-side-overflow-yes" <?php $this->print_attributes( $thumb_attrs ); ?>>
				<div class="swiper swiper--elementor mb-8">
					<div class="swiper-wrapper">
						<?php $this->render_thumbnails( $items ); ?>
					</div>
				</div>
			</gt-slider>

			<div class="avalon-testimonial-showcase__contents-container relative">
				<gt-slider class="avalon-testimonial-showcase__contents relative" <?php $this->print_attributes( $main_attrs ); ?>>
					<div class="swiper swiper--elementor">
						<div class="swiper-wrapper">
							<?php $this->render_main_slides( $items ); ?>
						</div>
					</div>
					<?php $this->render_arrows(); ?>
				</gt-slider>
			</div>
		</div>
		<?php
	}
}
