<?php
/**
 * Brand Showcase Widget
 *
 * Interactive "Trusted by the bold" brand showcase with
 * circular brand images and 3D sphere composition.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Brand Showcase Widget Class
 */
class Brand_Showcase extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-brand-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'brand-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'brand-showcase' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Brand Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-star-o ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'brand', 'showcase', 'trusted', 'logo', 'partner' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'subtext',
			[
				'label'       => esc_html__( 'Subtext', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( '(Trusted by the bold)', 'avalon-addons' ),
				'default'     => '(Trusted by the bold)',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'brand_name',
			[
				'label'       => esc_html__( 'Brand Name', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter brand name', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'brand_image',
			[
				'label'       => esc_html__( 'Brand Image', 'avalon-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'description' => esc_html__( 'Circular image displayed as a sphere.', 'avalon-addons' ),
				'default'     => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'brand_link',
			[
				'label'       => esc_html__( 'Link', 'avalon-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'sphere_position_heading',
			[
				'label'     => esc_html__( 'Sphere Position', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'sphere_left',
			[
				'label'       => esc_html__( 'Left', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ '%' ],
				'range'       => [
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'     => [
					'unit' => '%',
					'size' => 50,
				],
				'description' => esc_html__( 'Horizontal position of the sphere.', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--sphere-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$repeater->add_control(
			'sphere_top',
			[
				'label'       => esc_html__( 'Top', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ '%' ],
				'range'       => [
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'     => [
					'unit' => '%',
					'size' => 50,
				],
				'description' => esc_html__( 'Vertical position of the sphere.', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--sphere-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$repeater->add_control(
			'sphere_scale',
			[
				'label'       => esc_html__( 'Scale', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0.1,
						'max'  => 2,
						'step' => 0.05,
					],
				],
				'default'     => [
					'size' => 0.8,
				],
				'description' => esc_html__( 'Sphere scale relative to base size.', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--sphere-scale: {{SIZE}};',
				],
			]
		);

		$repeater->add_control(
			'sphere_z_index',
			[
				'label'       => esc_html__( 'Z-Index', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 1,
						'max'  => 20,
						'step' => 1,
					],
				],
				'default'     => [
					'size' => 5,
				],
				'description' => esc_html__( 'Stacking order (higher = in front).', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => '--sphere-z: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'brands',
			[
				'label'       => esc_html__( 'Brands', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ brand_name }}}',
				'default'     => [
					[
						'brand_name'     => esc_html__( 'Brand 1', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 15.3,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 49.4,
						],
						'sphere_scale'   => [ 'size' => 0.8 ],
						'sphere_z_index' => [ 'size' => 10 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 2', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 27,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 30,
						],
						'sphere_scale'   => [ 'size' => 0.75 ],
						'sphere_z_index' => [ 'size' => 5 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 3', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 50,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 15.1,
						],
						'sphere_scale'   => [ 'size' => 0.7 ],
						'sphere_z_index' => [ 'size' => 4 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 4', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 87.8,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 22.3,
						],
						'sphere_scale'   => [ 'size' => 0.55 ],
						'sphere_z_index' => [ 'size' => 3 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 5', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 91.9,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 43.9,
						],
						'sphere_scale'   => [ 'size' => 0.6 ],
						'sphere_z_index' => [ 'size' => 4 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 6', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 77,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 51,
						],
						'sphere_scale'   => [ 'size' => 0.7 ],
						'sphere_z_index' => [ 'size' => 5 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 7', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 54.8,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 70.4,
						],
						'sphere_scale'   => [ 'size' => 0.55 ],
						'sphere_z_index' => [ 'size' => 3 ],
					],
					[
						'brand_name'     => esc_html__( 'Brand 8', 'avalon-addons' ),
						'sphere_left'    => [
							'unit' => '%',
							'size' => 24.5,
						],
						'sphere_top'     => [
							'unit' => '%',
							'size' => 81.8,
						],
						'sphere_scale'   => [ 'size' => 0.5 ],
						'sphere_z_index' => [ 'size' => 2 ],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-brand-showcase__list' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label'     => esc_html__( 'Divider Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-brand-showcase__brand' => '--color-border-primary: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtext_heading',
			[
				'label'     => esc_html__( 'Subtext', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtext_typography',
				'selector' => '{{WRAPPER}} .avalon-brand-showcase__subtext',
			]
		);

		$this->add_control(
			'subtext_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-brand-showcase__subtext' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'subtext_spacing_bottom',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__subtext' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'brand_heading',
			[
				'label'     => esc_html__( 'Brand Names', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'brand_typography',
				'selector' => '{{WRAPPER}} .avalon-brand-showcase__brand',
			]
		);

		$this->add_control(
			'brand_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-brand-showcase__brand' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'brand_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-brand-showcase__brand:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .avalon-brand-showcase__brand.is-active' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'brand_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__brand' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_brand_image_style',
			[
				'label' => esc_html__( 'Brand Image', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'inner_height',
			[
				'label'      => esc_html__( 'Inner Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__sphere-inner' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'brand_image_heading',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'brand_image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__sphere' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'brand_image_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__sphere' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'brand_image_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-brand-showcase__sphere' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$brands   = $settings['brands'] ?? [];

		if ( empty( $brands ) ) {
			return;
		}

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-brand-showcase',
				'grid',
				'grid-cols-1',
				'md:grid-cols-2',
				'md:items-center',
				'gap-3',
				'relative',
			]
		);

		$this->add_render_attribute(
			'list',
			'class',
			[
				'avalon-brand-showcase__list',
				'relative',
				'z-2',
				'flex',
				'flex-col',
				'justify-center',
				'text-right',
			]
		);

		$this->add_render_attribute(
			'spheres',
			'class',
			[
				'avalon-brand-showcase__spheres',
				'relative',
				'w-full',
			]
		);

		$this->add_render_attribute(
			'sphere-inner',
			'class',
			[
				'avalon-brand-showcase__sphere-inner',
				'relative',
				'w-full',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'list' ); ?>>
				<?php if ( ! empty( $settings['subtext'] ) ) : ?>
					<div class="avalon-brand-showcase__subtext text-body-3 text-subtle mb-10">
						<?php echo wp_kses_post( nl2br( $settings['subtext'] ) ); ?>
					</div>
				<?php endif; ?>
				<div class="avalon-brand-showcase__brands flex flex-col">
					<?php
					foreach ( $brands as $index => $brand ) :
						$item_key = 'brand_item_' . $index;
						$is_first = 0 === $index;

						$this->add_render_attribute(
							$item_key,
							'class',
							[
								'avalon-brand-showcase__brand',
								'relative',
								'cursor-pointer',
								'h3',
								'my-0',
								'py-4',
								'border-top',
							]
						);

						if ( $is_first ) {
							$this->add_render_attribute( $item_key, 'class', [ 'is-active' ] );
						}

						$this->add_render_attribute( $item_key, 'data-index', (string) $index );
						$this->add_render_attribute( $item_key, 'role', 'button' );
						$this->add_render_attribute( $item_key, 'tabindex', '0' );
						?>
						<div <?php $this->print_render_attribute_string( $item_key ); ?>>
							<span>
								<?php echo wp_kses_post( $brand['brand_name'] ); ?>
							</span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<div <?php $this->print_render_attribute_string( 'spheres' ); ?>>
				<div <?php $this->print_render_attribute_string( 'sphere-inner' ); ?>>
				<?php
				foreach ( $brands as $index => $brand ) :
					$image     = $brand['brand_image'] ?? [];
					$image_id  = $image['id'] ?? 0;
					$image_url = $image['url'] ?? '';
					$is_first  = 0 === $index;

					if ( empty( $image_id ) && empty( $image_url ) ) {
						continue;
					}

					$sphere_key = 'sphere_' . $index;
					$loading    = $is_first ? 'eager' : 'lazy';

					$this->add_render_attribute(
						$sphere_key,
						'class',
						[
							'elementor-repeater-item-' . esc_attr( $brand['_id'] ),
							'avalon-brand-showcase__sphere',
							'absolute',
							'overflow-hidden',
							'circle',
							'ratio-image',
						]
					);

					if ( $is_first ) {
						$this->add_render_attribute( $sphere_key, 'class', [ 'is-active' ] );
					}
					?>
						<div <?php $this->print_render_attribute_string( $sphere_key ); ?>>
							<?php
							if ( $image_id ) {
								echo wp_get_attachment_image(
									$image_id,
									'full',
									false,
									[
										'title'   => Control_Media::get_image_title( $image ),
										'alt'     => Control_Media::get_image_alt( $image ),
										'loading' => $loading,
									]
								);
							} else {
								printf(
									'<img src="%1$s" title="%2$s" alt="%3$s" loading="%4$s" />',
									esc_url( $image_url ),
									esc_attr( Control_Media::get_image_title( $image ) ),
									esc_attr( Control_Media::get_image_alt( $image ) ),
									esc_attr( $loading )
								);
							}
							?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
