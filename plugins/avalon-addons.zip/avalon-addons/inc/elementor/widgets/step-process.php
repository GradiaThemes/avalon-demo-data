<?php
/**
 * Step Process Widget
 *
 * Displays a step-by-step process with a circular progress dial,
 * scroll-driven animation, and a fixed heading column.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Step Process Widget Class
 */
class Step_Process extends Widget_Base {

	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-step-process';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'step-process' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'step-process' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Step Process', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slideshow ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'step', 'process', 'approach', 'scroll', 'circle' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'   => esc_html__( 'Heading', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Heading', 'avalon-addons' ),
			]
		);

		$this->register_text_controls(
			[
				'html_tag' => 'h2',
			],
		);

		$this->add_control(
			'subheading',
			[
				'label'   => esc_html__( 'Subheading', 'avalon-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Subheading', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_steps',
			[
				'label' => esc_html__( 'Steps', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'step_name',
			[
				'label'       => esc_html__( 'Step Name', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Step 1', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'step_media_type',
			[
				'label'   => esc_html__( 'Media Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'avalon-addons' ),
					'image' => esc_html__( 'Image', 'avalon-addons' ),
				],
			]
		);

		$repeater->add_control(
			'step_icon',
			[
				'label'     => esc_html__( 'Icon', 'avalon-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-check',
					'library' => 'fa-solid',
				],
				'condition' => [
					'step_media_type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'step_image',
			[
				'label'     => esc_html__( 'Image', 'avalon-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'step_media_type' => 'image',
				],
			]
		);

		$repeater->add_control(
			'step_title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'step_description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'steps',
			[
				'label'       => esc_html__( 'Steps', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ step_name }}}',
				'separator'   => 'after',
				'default'     => [
					[
						'step_name'        => esc_html__( 'Step 1', 'avalon-addons' ),
						'step_media_type'  => 'icon',
						'step_icon'        => [
							'value'   => 'fas fa-search',
							'library' => 'fa-solid',
						],
						'step_title'       => esc_html__( 'Consulting', 'avalon-addons' ),
						'step_description' => esc_html__( 'We ask questions to understand your goals, design preferences and target audience.', 'avalon-addons' ),
					],
					[
						'step_name'        => esc_html__( 'Step 2', 'avalon-addons' ),
						'step_media_type'  => 'icon',
						'step_icon'        => [
							'value'   => 'fas fa-pencil-ruler',
							'library' => 'fa-solid',
						],
						'step_title'       => esc_html__( 'Collaborative Review', 'avalon-addons' ),
						'step_description' => esc_html__( 'During the design phase we invite the client to review and provide feedback.', 'avalon-addons' ),
					],
					[
						'step_name'        => esc_html__( 'Step 3', 'avalon-addons' ),
						'step_media_type'  => 'icon',
						'step_icon'        => [
							'value'   => 'fas fa-code',
							'library' => 'fa-solid',
						],
						'step_title'       => esc_html__( 'Make It Pop', 'avalon-addons' ),
						'step_description' => esc_html__( 'Establishing a structure focused on functionality and accessibility.', 'avalon-addons' ),
					],
				],
			]
		);

		$this->add_responsive_control(
			'scroll_distance',
			[
				'label'       => esc_html__( 'Scroll Distance Per Step', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px' ],
				'range'       => [
					'px' => [
						'min'  => 200,
						'max'  => 800,
						'step' => 50,
					],
				],
				'default'     => [
					'size' => 500,
					'unit' => 'px',
				],
				'description' => esc_html__( 'How many pixels of scroll each step takes.', 'avalon-addons' ),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register widget style controls
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_heading_style',
			[
				'label' => esc_html__( 'Heading', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_heading',
			[
				'label' => esc_html__( 'Heading', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .avalon-step-process__heading',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process__heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'subheading_heading',
			[
				'label'     => esc_html__( 'Subheading', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subheading_typography',
				'selector' => '{{WRAPPER}} .avalon-step-process__subheading',
			]
		);

		$this->add_control(
			'subheading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process__subheading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_summary_style',
			[
				'label' => esc_html__( 'Summary', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_image_heading',
			[
				'label' => esc_html__( 'Icon & Image', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'icon_image_spacing_bottom',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__card-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Image Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__icon--image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Image Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__icon--image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Image Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__icon--image' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-step-process__card-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process__card-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-step-process__card-description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process__card-desc' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'description_spacing_top',
			[
				'label'      => esc_html__( 'Spacing Top', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-step-process__card-desc' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_step_style',
			[
				'label' => esc_html__( 'Step', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'step_inactive_color',
			[
				'label'     => esc_html__( 'Inactive Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process' => '--step-inactive-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'step_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process' => '--step-active-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'step_completed_color',
			[
				'label'     => esc_html__( 'Completed Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process' => '--step-completed-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'step_circle_color',
			[
				'label'     => esc_html__( 'Circle Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process' => '--step-circle-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'step_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-step-process' => '--step-circle-border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$steps    = $settings['steps'] ?? [];

		if ( empty( $steps ) ) {
			return;
		}

		$count           = count( $steps );
		$angle           = min( 25, 360 / $count );
		$scroll_distance = $settings['scroll_distance']['size'] ?? 500;
		$total_scroll    = $count * $scroll_distance;

		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-step-process',
				'relative',
				'h-screen',
			]
		);

		$this->add_render_attribute(
			'wrapper',
			'data-step-count',
			esc_attr( $count )
		);

		$this->add_render_attribute(
			'wrapper',
			'data-scroll-distance',
			esc_attr( $scroll_distance )
		);

		$this->add_render_attribute(
			'wrapper',
			'data-total-scroll',
			esc_attr( $total_scroll )
		);

		$this->add_render_attribute(
			'grid',
			'class',
			[
				'avalon-step-process__grid',
				'grid',
				'grid-cols-1',
				'lg:grid-cols-12',
				'gap-3',
				'h-full',
				'relative',
				'overflow-hidden',
			]
		);

		$this->add_render_attribute(
			'left',
			'class',
			[
				'avalon-step-process__left',
				'col-span-1',
				'lg:col-span-3',
				'relative',
				'flex',
				'items-center',
			]
		);

		$this->add_render_attribute( 'heading', 'class', [ 'avalon-step-process__heading', 'my-0' ] );
		$this->add_render_attribute( 'subheading', 'class', [ 'avalon-step-process__subheading', 'caption' ] );

		$this->add_render_attribute(
			'middle',
			'class',
			[
				'avalon-step-process__middle',
				'col-span-1',
				'lg:col-span-6',
				'relative',
				'grid',
				'grid-area-1',
				'place-items-center',
				'text-center',
				'h-full',
			]
		);

		$this->add_render_attribute(
			'right',
			'class',
			[
				'avalon-step-process__right',
				'col-span-1',
				'lg:col-span-3',
				'relative',
				'h-full',
			]
		);

		$this->add_render_attribute(
			'circle',
			'class',
			[
				'avalon-step-process__circle',
				'relative',
				'overflow-visible',
			]
		);

		$this->add_render_attribute(
			'step_wrapper',
			'class',
			[
				'avalon-step-process__step-wrapper',
				'absolute',
				'w-full',
				'h-full',
				'top-0',
				'left-0',
				'overflow-visible',
			]
		);

		$this->add_render_attribute(
			'step_wrapper',
			'data-angle',
			esc_attr( $angle )
		);

		$this->add_render_attribute(
			'highlight_line',
			'class',
			[
				'avalon-step-process__highlight-line',
				'absolute',
				'left-0',
				'top-1/2',
				'-translate-y-1/2',
				'z-3',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'grid' ); ?>>

				<div <?php $this->print_render_attribute_string( 'left' ); ?>>
					<div class="inline-flex items-center gap-2">
					<?php
					$this->text_render(
						$settings['heading'],
						[
							'tag'        => $settings['html_tag'] ?? 'h2',
							'size'       => $settings['size'] ?? '',
							'class'      => [ 'avalon-step-process__heading', 'my-0' ],
							'attr'       => 'heading',
							'linebreaks' => $settings['linebreaks'] ?? 'yes',
						]
					);
					?>
					<?php if ( ! empty( $settings['subheading'] ) ) : ?>
						<div <?php $this->print_render_attribute_string( 'subheading' ); ?>>
							<?php echo wp_kses_post( $settings['subheading'] ); ?>
						</div>
					<?php endif; ?>
					</div>
				</div>

				<div <?php $this->print_render_attribute_string( 'middle' ); ?>>
					<?php foreach ( $steps as $index => $step ) : ?>
						<div class="avalon-step-process__card <?php echo 0 === $index ? 'is-active' : ''; ?>"
							data-step="<?php echo esc_attr( $index ); ?>"
							<?php echo 0 !== $index ? 'aria-hidden="true"' : ''; ?>>

							<div class="avalon-step-process__card-icon font-3xl text-darkest mb-6">
								<?php if ( 'icon' === ( $step['step_media_type'] ?? 'icon' ) && ! empty( $step['step_icon']['value'] ) ) : ?>
									<span class="avalon-step-process__icon avalon-svg-icon">
										<?php
										\Elementor\Icons_Manager::render_icon(
											$step['step_icon'],
											[
												'aria-hidden' => 'true',
												'fill' => 'currentColor',
											]
										);
										?>
									</span>
								<?php elseif ( ! empty( $step['step_image']['url'] ) ) : ?>
									<span class="avalon-step-process__icon avalon-step-process__icon--image ratio-image">
										<?php
										if ( ! empty( $step['step_image']['id'] ) ) {
											echo wp_get_attachment_image(
												$step['step_image']['id'],
												'full',
												false,
											);
										} else {
											printf(
												'<img src="%1$s" alt="%2$s" loading="lazy" />',
												esc_url( $step['step_image']['url'] ),
												esc_attr( $step['step_title'] ?? '' )
											);
										}
										?>
									</span>
								<?php endif; ?>
							</div>

							<?php if ( ! empty( $step['step_title'] ) ) : ?>
								<h5 class="avalon-step-process__card-title my-0">
									<?php echo esc_html( $step['step_title'] ); ?>
								</h5>
							<?php endif; ?>

							<?php if ( ! empty( $step['step_description'] ) ) : ?>
								<div class="avalon-step-process__card-desc text-body-3 mt-6">
									<?php echo wp_kses_post( nl2br( $step['step_description'] ) ); ?>
								</div>
							<?php endif; ?>

						</div>
					<?php endforeach; ?>
				</div>

				<div <?php $this->print_render_attribute_string( 'right' ); ?>>
					<div <?php $this->print_render_attribute_string( 'circle' ); ?>>
						<div class="avalon-step-process__outer-circle absolute inset-0 pointer-events-none h-full circle"></div>

						<div <?php $this->print_render_attribute_string( 'highlight_line' ); ?>></div>

						<div <?php $this->print_render_attribute_string( 'step_wrapper' ); ?>>
							<?php
							foreach ( $steps as $index => $step ) :
								$rotation        = $index * $angle * -1;
								$rotation_mobile = ( $index * $angle + 90 ) * -1;
								$step_name       = $step['step_name'] ?? sprintf( 'Step %d', $index + 1 );
								$is_first        = 0 === $index;
								?>
								<div class="avalon-step-process__arm absolute top-1/2 left-0 flex items-center w-full z-1 <?php echo esc_attr( $is_first ? 'is-active' : '' ); ?>"
									style="--transform: rotate(<?php echo esc_attr( $rotation ); ?>deg); --transform-mobile: rotate(<?php echo esc_attr( $rotation_mobile ); ?>deg);"
									data-step="<?php echo esc_attr( $index ); ?>">

									<div class="avalon-step-process__arm-label">
										<?php echo esc_html( $step_name ); ?>
									</div>

									<div class="avalon-step-process__arm-dot"></div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>

			</div>
		</div>
		<?php
	}
}
