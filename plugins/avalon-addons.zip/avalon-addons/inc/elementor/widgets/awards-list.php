<?php
/**
 * Awards List Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Awards List Widget Class
 */
class Awards_List extends Widget_Base {
	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-awards-list';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'awards-list' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'awards-list' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Awards List', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-bullet-list ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'awards', 'awwwards', 'list', 'winners' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Awards', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'year',
			[
				'label' => esc_html__( 'Year', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'name_product',
			[
				'label' => esc_html__( 'Name Product', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'number_product',
			[
				'label' => esc_html__( 'Number Product', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'name_awwwards',
			[
				'label' => esc_html__( 'Name Awwwards', 'avalon-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'avalon-addons' ),
				'type'  => Controls_Manager::URL,
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'year'          => '2024',
						'name_product'  => esc_html__( 'Product Name 1', 'avalon-addons' ),
						'name_awwwards' => esc_html__( 'Awwwards Name 1', 'avalon-addons' ),
					],
					[
						'year'          => '2023',
						'name_product'  => esc_html__( 'Product Name 2', 'avalon-addons' ),
						'name_awwwards' => esc_html__( 'Awwwards Name 2', 'avalon-addons' ),
					],
					[
						'year'          => '2022',
						'name_product'  => esc_html__( 'Product Name 3', 'avalon-addons' ),
						'name_awwwards' => esc_html__( 'Awwwards Name 3', 'avalon-addons' ),
					],
				],
				'title_field' => '{{{ year }}} - {{{ name_product }}}',
			]
		);

		$this->add_control(
			'name_heading',
			[
				'label'     => esc_html__( 'Name', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->register_text_controls(
			[
				'html_tag' => 'div',
			],
			null,
			'name_'
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_style_section',
			[
				'label' => esc_html__( 'Item', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label'      => esc_html__( 'Spacing between items', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-awards-list' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => esc_html__( 'Padding', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-awards-list__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'item_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color Hover', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item:hover' => 'color: {{VALUE}}; --color-heading: {{VALUE}};',
					'{{WRAPPER}} .avalon-awards-list__year' => 'color: {{VALUE}}; --color-heading: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'product_heading_style',
			[
				'label'     => esc_html__( 'Product', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'product_typography',
				'selector' => '{{WRAPPER}} .avalon-awards-list__product',
			]
		);

		$this->add_control(
			'product_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__product' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'product_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item:hover .avalon-awards-list__product' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'awwwards_heading_style',
			[
				'label'     => esc_html__( 'Awwwards', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'awwwards_typography',
				'selector' => '{{WRAPPER}} .avalon-awards-list__awwwards',
			]
		);

		$this->add_control(
			'awwwards_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__awwwards' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'awwwards_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-awards-list__item:hover .avalon-awards-list__awwwards' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['items'] ) ) {
			return;
		}

		$this->add_render_attribute( 'list', 'class', [ 'avalon-awards-list', 'flex', 'flex-col', 'gap-4', 'text-body-3' ] );

		$this->add_render_attribute( 'year', 'class', [ 'avalon-awards-list__year' ] );
		$this->add_render_attribute( 'product', 'class', [ 'avalon-awards-list__product' ] );
		$this->add_render_attribute( 'awwwards', 'class', [ 'avalon-awards-list__awwwards', 'text-right' ] );
		?>
		<div <?php $this->print_render_attribute_string( 'list' ); ?>>
			<?php
			foreach ( $settings['items'] as $index => $item ) {
				$item_key = $this->get_repeater_setting_key( 'item', 'items', $index );

				$this->add_render_attribute( $item_key, 'class', [ 'avalon-awards-list__item', 'relative', 'flex', 'flex-wrap', 'items-center', 'justify-between', 'gap-4', 'transition' ] );

				if ( ! empty( $item['link']['url'] ) ) {
					$this->add_link_attributes( $item_key, $item['link'] );
				}
				?>
				<?php if ( ! empty( $item['link']['url'] ) ) : ?>
					<a <?php $this->print_render_attribute_string( $item_key ); ?>>
				<?php else : ?>
					<div <?php $this->print_render_attribute_string( $item_key ); ?>>
				<?php endif; ?>

					<?php if ( ! empty( $item['year'] ) ) : ?>
						<div <?php $this->print_render_attribute_string( 'year' ); ?>><?php echo wp_kses_post( $item['year'] ); ?></div>
					<?php endif; ?>

					<?php if ( ! empty( $item['name_product'] ) ) : ?>
						<?php
						$this->text_render(
							$item['name_product'] . ' <span class="text-primary">' . $item['number_product'] . '</span>',
							[
								'tag'        => $settings['name_html_tag'] ?? 'div',
								'size'       => $settings['name_size'] ?? '',
								'class'      => [ 'avalon-awards-list__product', 'my-0' ],
								'attr'       => 'product',
								'linebreaks' => $settings['name_linebreaks'] ?? 'yes',
							]
						);
						?>
					<?php endif; ?>

					<?php if ( ! empty( $item['name_awwwards'] ) ) : ?>
						<div <?php $this->print_render_attribute_string( 'awwwards' ); ?>><?php echo wp_kses_post( $item['name_awwwards'] ); ?></div>
					<?php endif; ?>

				<?php if ( ! empty( $item['link']['url'] ) ) : ?>
					</a>
				<?php else : ?>
					</div>
				<?php endif; ?>
				<?php
			}
			?>
		</div>
		<?php
	}
}
