<?php
/**
 * Marquee Widget
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Marquee Widget Class
 */
class Marquee extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-marquee';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'marquee' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'marquee' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Marquee', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'marquee', 'scroll', 'ticker', 'infinite', 'loop' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// Content section.
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Marquee', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image' => esc_html__( 'Image', 'avalon-addons' ),
					'icon'  => esc_html__( 'Icon', 'avalon-addons' ),
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'      => esc_html__( 'Image', 'avalon-addons' ),
				'type'       => Controls_Manager::MEDIA,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'       => 'image_size',
				'default'    => 'full',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label'      => esc_html__( 'Icon', 'avalon-addons' ),
				'type'       => Controls_Manager::ICONS,
				'default'    => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'type',
							'value' => 'icon',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'avalon-addons' ),
				'type'  => Controls_Manager::URL,
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ type }}}',
				'separator'   => 'after',
				'default'     => [
					[
						'type' => 'image',
					],
					[
						'type' => 'image',
					],
					[
						'type' => 'image',
					],
				],
			]
		);

		$this->add_control(
			'direction',
			[
				'label'   => esc_html__( 'Direction', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'marquee',
				'options' => [
					'marquee'         => esc_html__( 'Right to Left', 'avalon-addons' ),
					'marquee-reverse' => esc_html__( 'Left to Right', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'              => esc_html__( 'Duration (Seconds)', 'avalon-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 15,
				'min'                => 1,
				'max'                => 60,
				'step'               => 1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'hover_pause',
			[
				'label'        => esc_html__( 'Pause on Hover', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		// Style section - Content.
		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label'      => esc_html__( 'Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-inline-end: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style section - Item.
		$this->start_controls_section(
			'section_item_style',
			[
				'label' => esc_html__( 'Item', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'item_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__item' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style section - Image.
		$this->start_controls_section(
			'section_image_style',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style section - Icon.
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Icon', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-marquee__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-marquee__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__( 'Color Hover', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-marquee__item:hover .avalon-marquee__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['items'] ) ) {
			return;
		}

		$classes = [
			'avalon-marquee',
			'avalon-elementor--marquee',
			'marquee--' . esc_attr( $settings['direction'] ?? 'marquee' ),
		];

		if ( ! empty( $settings['hover_pause'] ) && 'yes' === $settings['hover_pause'] ) {
			$classes[] = 'hover-stop';
		}

		$this->add_render_attribute( 'wrapper', 'class', $classes );
		$this->add_render_attribute( 'inner', 'class', [ 'avalon-marquee__inner', 'relative', 'items-center' ] );
		$this->add_render_attribute( 'items', 'class', [ 'avalon-marquee__items', 'avalon-marquee--original', 'items-center' ] );
		$this->add_render_attribute( 'image', 'class', [ 'avalon-marquee__image' ] );
		$this->add_render_attribute( 'icon', 'class', [ 'avalon-marquee__icon', 'avalon-svg-icon' ] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'inner' ); ?>>
				<div <?php $this->print_render_attribute_string( 'items' ); ?>>
					<?php foreach ( $settings['items'] as $index => $item ) : ?>
						<?php
						$item_key = $this->get_repeater_setting_key( 'item', 'avalon-marquee', $index );
						$this->add_render_attribute( $item_key, 'class', [ 'avalon-marquee__item', 'flex', 'items-center', 'justify-center', 'elementor-repeater-item-' . esc_attr( $item['_id'] ) ] );
						?>
						<div <?php $this->print_render_attribute_string( $item_key ); ?>>
							<?php if ( 'image' === $item['type'] ) : ?>
								<?php if ( ! empty( $item['image']['url'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( 'image' ); ?>>
										<?php if ( ! empty( $item['image']['id'] ) ) : ?>
											<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
											<img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="" />
										<?php endif; ?>
									</div>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( 'icon' === $item['type'] ) : ?>
								<?php if ( ! empty( $item['icon'] ) && ! empty( $item['icon']['value'] ) ) : ?>
									<span <?php $this->print_render_attribute_string( 'icon' ); ?>>
										<?php
										Icons_Manager::render_icon(
											$item['icon'],
											[
												'aria-hidden' => 'true',
												'fill' => 'currentColor',
											]
										);
										?>
									</span>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
