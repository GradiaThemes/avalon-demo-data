<?php
/**
 * Counter Widget
 *
 * Displays a number with a prefix/suffix and an optional title. The digits
 * are rendered as vertical 0-9 strips that roll up to the ending value
 * instead of counting up through intermediate numbers.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Utils;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;

/**
 * Counter Widget Class
 */
class Counter extends Widget_Base {
	use Base\Text_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-counter';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'counter' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'counter' )['scripts'];
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Counter', 'avalon-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'counter', 'number', 'stats', 'odometer', 'count' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_counter',
			[
				'label' => esc_html__( 'Counter', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'starting_number',
			[
				'label'   => esc_html__( 'Starting Number', 'avalon-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 0,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'ending_number',
			[
				'label'   => esc_html__( 'Ending Number', 'avalon-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 100,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'prefix',
			[
				'label'       => esc_html__( 'Number Prefix', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'e.g. $', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'suffix',
			[
				'label'       => esc_html__( 'Number Suffix', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'e.g. %', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'duration',
			[
				'label'   => esc_html__( 'Animation Duration', 'avalon-addons' ) . ' (ms)',
				'type'    => Controls_Manager::NUMBER,
				'default' => 2000,
				'min'     => 100,
				'step'    => 100,
			]
		);

		$this->add_control(
			'thousand_separator',
			[
				'label'     => esc_html__( 'Thousand Separator', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'label_on'  => esc_html__( 'Show', 'avalon-addons' ),
				'label_off' => esc_html__( 'Hide', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'thousand_separator_char',
			[
				'label'     => esc_html__( 'Separator', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'condition' => [
					'thousand_separator' => 'yes',
				],
				'options'   => [
					''  => esc_html__( 'Default', 'avalon-addons' ),
					'.' => esc_html__( 'Dot', 'avalon-addons' ),
					' ' => esc_html__( 'Space', 'avalon-addons' ),
					'_' => esc_html__( 'Underline', 'avalon-addons' ),
					"'" => esc_html__( 'Apostrophe', 'avalon-addons' ),
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'separator'   => 'before',
				'dynamic'     => [
					'active' => true,
				],
				'default'     => esc_html__( 'Cool Number', 'avalon-addons' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_html_tag_options(),
				'default'   => 'div',
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_control(
			'title_size',
			[
				'label'     => esc_html__( 'Size', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_size_options(),
				'default'   => 'text-body-3',
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls
	 */
	protected function register_style_controls() {
		$this->register_layout_style_controls();
		$this->register_number_style_controls();
		$this->register_affix_style_controls();
		$this->register_title_style_controls();
	}

	/**
	 * Register layout style controls (title and number placement)
	 */
	protected function register_layout_style_controls() {
		$this->start_controls_section(
			'section_counter_style',
			[
				'label' => esc_html__( 'Counter', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_position',
			[
				'label'                => esc_html__( 'Title Position', 'avalon-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'before' => [
						'title' => esc_html__( 'Before', 'avalon-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'after'  => [
						'title' => esc_html__( 'After', 'avalon-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
					'start'  => [
						'title' => esc_html__( 'Start', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'end'    => [
						'title' => esc_html__( 'End', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors_dictionary' => [
					'before' => 'flex-direction: column;',
					'after'  => 'flex-direction: column-reverse;',
					'start'  => 'flex-direction: row;',
					'end'    => 'flex-direction: row-reverse;',
				],
				'selectors'            => [
					'{{WRAPPER}} .avalon-counter' => '{{VALUE}}',
				],
				'classes'              => 'elementor-control-start-end',
				'condition'            => [
					'title!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'title_horizontal_alignment',
			[
				'label'     => esc_html__( 'Title Horizontal Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'  => [
						'title' => esc_html__( 'Start', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-center',
					],
					'end'    => [
						'title' => esc_html__( 'End', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'separator' => 'before',
				'classes'   => 'elementor-control-start-end',
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__title' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'title_vertical_alignment',
			[
				'label'     => esc_html__( 'Title Vertical Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'  => [
						'title' => esc_html__( 'Top', 'avalon-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__( 'Middle', 'avalon-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'end'    => [
						'title' => esc_html__( 'Bottom', 'avalon-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .avalon-counter' => 'align-items: {{VALUE}};',
				],
				'condition' => [
					'title!'         => '',
					'title_position' => [ 'start', 'end' ],
				],
			]
		);

		$this->add_responsive_control(
			'title_gap',
			[
				'label'      => esc_html__( 'Title Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-counter' => 'gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'title!'         => '',
					'title_position' => [ '', 'before', 'after' ],
				],
			]
		);

		$this->add_responsive_control(
			'number_position',
			[
				'label'                => esc_html__( 'Number Position', 'avalon-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'start'   => [
						'title' => esc_html__( 'Start', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-center',
					],
					'end'     => [
						'title' => esc_html__( 'End', 'avalon-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
					'stretch' => [
						'title' => esc_html__( 'Stretch', 'avalon-addons' ),
						'icon'  => 'eicon-grow',
					],
				],
				'separator'            => 'before',
				'classes'              => 'elementor-control-start-end',
				'selectors_dictionary' => [
					'start'   => 'justify-content: flex-start; --counter-number-grow: 0;',
					'center'  => 'justify-content: center; --counter-number-grow: 0;',
					'end'     => 'justify-content: flex-end; --counter-number-grow: 0;',
					'stretch' => 'justify-content: flex-start; --counter-number-grow: 1;',
				],
				'selectors'            => [
					'{{WRAPPER}} .avalon-counter__number-wrapper' => '{{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'number_alignment',
			[
				'label'     => esc_html__( 'Number Alignment', 'avalon-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'  => [
						'title' => esc_html__( 'Start', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'    => [
						'title' => esc_html__( 'End', 'avalon-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'classes'   => 'elementor-control-start-end',
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__number' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'number_position' => 'stretch',
				],
			]
		);

		$this->add_responsive_control(
			'number_gap',
			[
				'label'      => esc_html__( 'Number Gap', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-counter__number-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'number_position',
							'operator' => '!==',
							'value'    => 'stretch',
						],
						[
							'relation' => 'or',
							'terms'    => [
								[
									'name'     => 'prefix',
									'operator' => '!==',
									'value'    => '',
								],
								[
									'name'     => 'suffix',
									'operator' => '!==',
									'value'    => '',
								],
							],
						],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register number style controls
	 */
	protected function register_number_style_controls() {
		$this->start_controls_section(
			'section_number',
			[
				'label' => esc_html__( 'Number', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Text Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__number-wrapper' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography_number',
				'selector' => '{{WRAPPER}} .avalon-counter__number-wrapper',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'number_shadow',
				'selector' => '{{WRAPPER}} .avalon-counter__number-wrapper',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register prefix and suffix style controls
	 */
	protected function register_affix_style_controls() {
		$this->start_controls_section(
			'section_affix',
			[
				'label' => esc_html__( 'Prefix & Suffix', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'prefix_heading',
			[
				'label' => esc_html__( 'Prefix', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'prefix_typography',
				'selector' => '{{WRAPPER}} .avalon-counter__prefix',
			]
		);

		$this->add_control(
			'prefix_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__prefix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'prefix_margin',
			[
				'label'      => esc_html__( 'Margin', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-counter__prefix' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'suffix_heading',
			[
				'label'     => esc_html__( 'Suffix', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'suffix_typography',
				'selector' => '{{WRAPPER}} .avalon-counter__suffix',
			]
		);

		$this->add_control(
			'suffix_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__suffix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'suffix_margin',
			[
				'label'      => esc_html__( 'Margin', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-counter__suffix' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register title style controls
	 */
	protected function register_title_style_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Text Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-counter__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography_title',
				'selector' => '{{WRAPPER}} .avalon-counter__title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'title_shadow',
				'selector' => '{{WRAPPER}} .avalon-counter__title',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$end_string   = $this->format_number( $settings['ending_number'] ?? 100, $settings );
		$start_string = $this->format_number( $settings['starting_number'] ?? 0, $settings );

		$title  = $settings['title'] ?? '';
		$prefix = $settings['prefix'] ?? '';
		$suffix = $settings['suffix'] ?? '';

		$this->add_render_attribute( 'wrapper', 'class', [ 'avalon-counter', 'flex', 'flex-col', 'gap-2' ] );
		$this->add_render_attribute( 'wrapper', 'data-duration', (int) ( $settings['duration'] ?? 2000 ) );
		$this->add_render_attribute( 'wrapper', 'data-from', $start_string );
		$this->add_render_attribute( 'wrapper', 'data-to', $end_string );

		$this->add_render_attribute( 'number_wrapper', 'class', [ 'avalon-counter__number-wrapper', 'flex', 'items-center', 'gap-1' ] );
		$this->add_render_attribute( 'number', 'class', [ 'avalon-counter__number', 'h1', 'my-0' ] );
		$this->add_render_attribute( 'value', 'class', [ 'avalon-counter__value' ] );
		$this->add_render_attribute( 'title', 'class', [ 'avalon-counter__title', 'my-0', isset( $settings['title_size'] ) ? $settings['title_size'] : 'text-body-3' ] );

		$this->add_inline_editing_attributes( 'title' );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'number_wrapper' ); ?>>

				<?php if ( '' !== $prefix ) : ?>
					<span class="avalon-counter__prefix text-primary">
						<?php echo wp_kses_post( $prefix ); ?>
					</span>
				<?php endif; ?>

				<span <?php $this->print_render_attribute_string( 'number' ); ?>>
					<span class="screen-reader-text">
						<?php echo esc_html( $end_string ); ?>
					</span>

					<span <?php $this->print_render_attribute_string( 'value' ); ?>>
						<?php echo esc_html( $start_string ); ?>
					</span>
				</span>

				<?php if ( '' !== $suffix ) : ?>
					<span class="avalon-counter__suffix text-primary">
						<?php echo wp_kses_post( $suffix ); ?>
					</span>
				<?php endif; ?>

			</div>

			<?php if ( '' !== $title ) : ?>
				<<?php echo esc_attr( $settings['title_tag'] ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>>
					<?php echo wp_kses_post( $title ); ?>
				</<?php echo esc_attr( $settings['title_tag'] ); ?>>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Format a counter value for display
	 *
	 * Non numeric values (for example from a dynamic tag) are returned as is.
	 *
	 * @param mixed $value    Value to format.
	 * @param array $settings Widget settings.
	 * @return string
	 */
	private function format_number( $value, $settings ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '0';
		}

		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		$negative = '-' === $value[0];
		$unsigned = $negative ? substr( $value, 1 ) : $value;
		$parts    = explode( '.', $unsigned, 2 );
		$number   = ( $negative ? '-' : '' ) . $this->group_thousands( $parts[0], $this->get_delimiter( $settings ) );

		if ( isset( $parts[1] ) && '' !== $parts[1] ) {
			$number .= '.' . $parts[1];
		}

		return $number;
	}

	/**
	 * Get the thousand separator character
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	private function get_delimiter( $settings ) {
		if ( empty( $settings['thousand_separator'] ) ) {
			return '';
		}

		$delimiter = $settings['thousand_separator_char'] ?? '';

		return '' === $delimiter ? ',' : $delimiter;
	}

	/**
	 * Group a digit string into thousands
	 *
	 * @param string $digits    Digit string.
	 * @param string $delimiter Separator character.
	 * @return string
	 */
	private function group_thousands( $digits, $delimiter ) {
		if ( '' === $delimiter ) {
			return $digits;
		}

		$length  = strlen( $digits );
		$grouped = '';

		for ( $i = 0; $i < $length; $i++ ) {
			if ( $i > 0 && 0 === ( $length - $i ) % 3 ) {
				$grouped .= $delimiter;
			}

			$grouped .= $digits[ $i ];
		}

		return $grouped;
	}
}
