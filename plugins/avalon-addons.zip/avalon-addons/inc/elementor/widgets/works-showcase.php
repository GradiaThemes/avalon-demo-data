<?php
	/**
	 * Works Showcase Widget
	 *
	 * Displays portfolio works in a stacked scroll-pinned layout with
	 * a radial ripple reveal layer and a fraction indicator.
	 *
	 * @package AvalonAddons
	 */

namespace AvalonAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use AvalonAddons\Elementor\Elementor as AvalonAddons_Elementor;
use AvalonAddons\Helper;
use AvalonAddons\Elementor\Widgets\Base;

/**
 * Works Showcase Widget Class
 */
class Works_Showcase extends Widget_Base {

	use Base\Button_Base;
	use Base\Hover_Cursor_Base;

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-works-showcase';
	}

	/**
	 * Get widget style dependencies
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'works-showcase' )['styles'];
	}

	/**
	 * Get widget script dependencies
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return \AvalonAddons\Elementor\Elementor::get_widget_assets( 'works-showcase' )['scripts'];
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Works Showcase', 'avalon-addons' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slideshow ' . AvalonAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ AvalonAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'avalon', 'works', 'showcase', 'portfolio', 'scroll', 'stacked' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls();
	}

	/**
	 * Register content controls.
	 *
	 * @return void
	 */
	protected function register_content_controls() {
		$this->start_controls_section(
			'section_common',
			[
				'label' => esc_html__( 'Common', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading_left',
			[
				'label'       => esc_html__( 'Heading Left', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter left heading', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading_right',
			[
				'label'       => esc_html__( 'Heading Right', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter right heading', 'avalon-addons' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_button_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__( 'Items', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter title', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'year',
			[
				'label'       => esc_html__( 'Year', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter year', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter description', 'avalon-addons' ),
			]
		);

		$repeater->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'avalon-addons' ),
				'type'  => Controls_Manager::URL,
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'avalon-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'image'       => [],
						'title'       => esc_html__( 'Project 1', 'avalon-addons' ),
						'year'        => esc_html__( '2024', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the first project.', 'avalon-addons' ),
					],
					[
						'image'       => [],
						'title'       => esc_html__( 'Project 2', 'avalon-addons' ),
						'year'        => esc_html__( '2024', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the second project.', 'avalon-addons' ),
					],
					[
						'image'       => [],
						'title'       => esc_html__( 'Project 3', 'avalon-addons' ),
						'year'        => esc_html__( '2023', 'avalon-addons' ),
						'description' => esc_html__( 'Description for the third project.', 'avalon-addons' ),
					],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_hover_cursor',
			[
				'label' => esc_html__( 'Hover Cursor', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_hover_cursor_controls(
			'',
			[
				'hover_cursor_type' => 'button_icon',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style controls.
	 *
	 * @return void
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'section_general_style',
			[
				'label' => esc_html__( 'General', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container',
			[
				'label'   => esc_html__( 'Container', 'avalon-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'container--fluid',
				'options' => [
					'container--fluid'  => esc_html__( 'Fluid', 'avalon-addons' ),
					'container--narrow' => esc_html__( 'Fixed', 'avalon-addons' ),
					'container--full'   => esc_html__( 'Full No Spacing', 'avalon-addons' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_typography_style',
			[
				'label' => esc_html__( 'Typography', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_style_heading',
			[
				'label' => esc_html__( 'Headings', 'avalon-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__overlay-top h2',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__overlay-top h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_style_heading',
			[
				'label'     => esc_html__( 'Title', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'year_style_heading',
			[
				'label'     => esc_html__( 'Year', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'year_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__year',
			]
		);

		$this->add_control(
			'year_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__year' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label'     => esc_html__( 'Description', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__desc',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'skip_style_heading',
			[
				'label'     => esc_html__( 'Skip', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'skip_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__skip',
			]
		);

		$this->add_control(
			'skip_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__skip' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fraction_style_heading',
			[
				'label'     => esc_html__( 'Fraction', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'fraction_typography',
				'selector' => '{{WRAPPER}} .avalon-works-showcase__fraction',
			]
		);

		$this->add_control(
			'fraction_color',
			[
				'label'     => esc_html__( 'Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .avalon-works-showcase__fraction' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_image_style',
			[
				'label' => esc_html__( 'Image', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-works-showcase__image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-works-showcase__image img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Example: 16/9', 'avalon-addons' ),
				'selectors'   => [
					'{{WRAPPER}} .avalon-works-showcase__image img' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'avalon-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .avalon-works-showcase__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_hover_cursor_style',
			[
				'label' => esc_html__( 'Hover Cursor', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_hover_cursor_controls_style();

		$button_icon = '.avalon-cursor__inner .avalon-hover-cursor__{{ID}} .avalon-cursor__button-icon';
		$conditions  = [
			'hover_cursor_type' => [ 'button_icon', 'button_text_icon' ],
		];

		$this->add_responsive_control(
			'hover_cursor_icon_button_width',
			[
				'label'          => esc_html__( 'Button Width', 'avalon-addons' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => 60,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'      => [
					$button_icon => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'      => $conditions,
			]
		);

		$this->add_responsive_control(
			'hover_cursor_icon_button_height',
			[
				'label'          => esc_html__( 'Button Height', 'avalon-addons' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => 60,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors'      => [
					$button_icon => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'      => $conditions,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Get the fallback theme icon for the hover cursor
	 *
	 * @param string $prefix Prefix.
	 * @return string
	 */
	protected function get_hover_cursor_icon_fallback( $prefix = '' ) {
		return 'chevron-right';
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['items'] ?? [];
		$count    = count( $items );

		if ( empty( $items ) || $count < 2 ) {
			return;
		}

		$this->render_works( $settings, $items, $count );
	}

	/**
	 * Render the works showcase layout.
	 *
	 * @param array $settings Widget settings.
	 * @param array $items    Repeater items.
	 * @param int   $count    Number of items.
	 */
	private function render_works( array $settings, array $items, int $count ) {
		$this->add_render_attribute(
			'wrapper',
			'class',
			[
				'avalon-works-showcase',
				'relative',
				'h-screen',
			]
		);

		$this->add_render_attribute(
			'container',
			'class',
			[
				'avalon-works-showcase__container',
				'relative',
				'h-full',
				esc_attr( $settings['container'] ),
			]
		);

		$this->add_render_attribute( 'wrapper', 'data-count', esc_attr( $count ) );
		$this->add_render_attribute( 'wrapper', 'data-water-filter', esc_attr( 'avalon-works-water-' . $this->get_id() ) );

		$this->add_render_attribute(
			'overlay',
			'class',
			[
				'avalon-works-showcase__overlay',
				'absolute',
				'inset-0',
				'w-full',
				'h-screen',
				'py-10',
				'z-2',
				'pointer-events-none',
				'flex',
				'flex-col',
				'justify-between',
			]
		);

		$this->add_render_attribute(
			'overlay_top',
			'class',
			[
				'avalon-works-showcase__overlay-top',
				'flex',
				'justify-between',
				'items-start',
				'gap-4',
				'pointer-events-auto',
			]
		);

		$this->add_render_attribute(
			'heading_left',
			'class',
			[
				'my-0',
			]
		);

		$this->add_render_attribute(
			'heading_right',
			'class',
			[
				'my-0',
			]
		);

		$this->add_render_attribute(
			'overlay_bottom',
			'class',
			[
				'avalon-works-showcase__overlay-bottom',
				'flex',
				'justify-between',
				'items-end',
				'gap-4',
				'pointer-events-auto',
			]
		);

		$this->add_render_attribute(
			'title_collection',
			'class',
			[
				'avalon-works-showcase__title',
				'grid',
				'grid-area-1',
			]
		);

		$this->add_render_attribute(
			'year_collection',
			'class',
			[
				'avalon-works-showcase__year',
				'text-body-4',
				'grid',
				'grid-area-1',
			]
		);

		$this->add_render_attribute(
			'skip',
			'class',
			[
				'avalon-works-showcase__skip',
				'text-body-4',
			]
		);

		$this->add_render_attribute(
			'fraction',
			'class',
			[
				'avalon-works-showcase__fraction',
				'caption',
				'h2',
				'my-0',
				'inline-flex',
				'gap-2',
			]
		);

		$this->add_render_attribute(
			'fraction_current',
			'class',
			[
				'avalon-works-showcase__current',
				'grid',
				'grid-area-1',
				'place-items-center',
			]
		);

		$this->add_render_attribute(
			'track',
			'class',
			[
				'avalon-works-showcase__track',
				'relative',
				'h-full',
				'z-1',
				'flex',
				'flex-col',
				'items-center',
				'justify-center',
				'gap-4',
				'text-center',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<svg class="avalon-works-showcase__svg-defs" aria-hidden="true" focusable="false">
				<defs>
					<filter id="<?php echo esc_attr( 'avalon-works-water-' . $this->get_id() ); ?>" x="-25%" y="-25%" width="150%" height="150%" color-interpolation-filters="sRGB">
						<feTurbulence class="avalon-works-showcase__turb" type="fractalNoise" baseFrequency="0.018" numOctaves="2" seed="3" result="noise" />
						<feDisplacementMap class="avalon-works-showcase__disp" in="SourceGraphic" in2="noise" scale="0" xChannelSelector="R" yChannelSelector="G" />
					</filter>
				</defs>
			</svg>
			<div <?php $this->print_render_attribute_string( 'container' ); ?>>
				<div <?php $this->print_render_attribute_string( 'overlay' ); ?>>
					<div <?php $this->print_render_attribute_string( 'overlay_top' ); ?>>
						<?php if ( ! empty( $settings['heading_left'] ) ) : ?>
							<h2 <?php $this->print_render_attribute_string( 'heading_left' ); ?>>
								<?php echo wp_kses_post( nl2br( $settings['heading_left'] ) ); ?>
							</h2>
						<?php endif; ?>
						<?php if ( ! empty( $settings['heading_right'] ) ) : ?>
							<h2 <?php $this->print_render_attribute_string( 'heading_right' ); ?>>
								<?php echo wp_kses_post( nl2br( $settings['heading_right'] ) ); ?>
							</h2>
						<?php endif; ?>
					</div>

					<div class="avalon-works-showcase__middle flex justify-between items-center pointer-events-none gap-4">
						<h3 <?php $this->print_render_attribute_string( 'title_collection' ); ?>>
							<?php foreach ( $items as $index => $item ) : ?>
								<span class="<?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
									<?php echo wp_kses_post( nl2br( $item['title'] ?? '' ) ); ?>
								</span>
							<?php endforeach; ?>
						</h3>
						<span <?php $this->print_render_attribute_string( 'year_collection' ); ?>>
							<?php foreach ( $items as $index => $item ) : ?>
								<span class="<?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>">
									<?php echo wp_kses_post( $item['year'] ?? '' ); ?>
								</span>
							<?php endforeach; ?>
						</span>
					</div>

					<div <?php $this->print_render_attribute_string( 'overlay_bottom' ); ?>>
						<div <?php $this->print_render_attribute_string( 'skip' ); ?>>
							<span><?php echo esc_html__( 'Keep scrolling →', 'avalon-addons' ); ?></span>
							<span class="avalon-works-showcase__skip-link">
								<?php echo esc_html__( 'or skip ↓', 'avalon-addons' ); ?>
							</span>
						</div>

						<div <?php $this->print_render_attribute_string( 'fraction' ); ?>>
							<span <?php $this->print_render_attribute_string( 'fraction_current' ); ?>>
								<?php foreach ( range( 1, $count ) as $i ) : ?>
									<span class="<?php echo esc_attr( 1 === $i ? 'is-active' : '' ); ?>">
										<?php echo wp_kses_post( str_pad( $i, 2, '0', STR_PAD_LEFT ) ); ?>
									</span>
								<?php endforeach; ?>
							</span>
							<span> / </span>
							<span class="avalon-works-showcase__total">
								<?php echo wp_kses_post( str_pad( (string) $count, 2, '0', STR_PAD_LEFT ) ); ?>
							</span>
						</div>

						<div class="avalon-works-showcase__button">
							<?php $this->button_render( $settings ); ?>
						</div>
					</div>
				</div>

				<div <?php $this->print_render_attribute_string( 'track' ); ?>>
					<div class="avalon-works-showcase__images relative">
						<?php foreach ( $items as $index => $item ) : ?>
							<?php
							$image      = $item['image'] ?? [];
							$image_id   = $image['id'] ?? 0;
							$image_url  = $image['url'] ?? '';
							$has_image  = ! empty( $image_id ) || ! empty( $image_url );
							$first_item = 0 === $index;
							$is_active  = 0 === $index;

							$this->add_render_attribute(
								'link_' . $index,
								'class',
								'avalon-works-showcase__link'
							);
							?>
							<?php if ( $has_image ) : ?>
								<div class="avalon-works-showcase__image relative ratio-image <?php echo esc_attr( $is_active ? 'is-active' : '' ); ?>" data-index="<?php echo esc_attr( $index ); ?>" <?php $this->render_hover_cursor_attributes(); ?>>
									<?php $this->render_hover_cursor_template(); ?>
									<?php if ( ! empty( $item['link']['url'] ) ) : ?>
										<?php $this->add_link_attributes( 'link_' . $index, $item['link'] ); ?>
										<a <?php $this->print_render_attribute_string( 'link_' . $index ); ?>>
									<?php endif; ?>
										<?php
										if ( $image_id ) {
											echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												$image_id,
												'full',
												false,
												[
													'loading' => $first_item ? 'eager' : 'lazy',
												]
											);
										} else {
											printf(
												'<img src="%1$s" alt="%2$s" loading="%3$s" />',
												esc_url( $image_url ),
												esc_attr( Control_Media::get_image_alt( $image ) ),
												esc_attr( $first_item ? 'eager' : 'lazy' ),
											);
										}
										?>
									<?php if ( ! empty( $item['link']['url'] ) ) : ?>
										</a>
									<?php endif; ?>
								</div>
							<?php endif; ?>
							<?php endforeach; ?>
					</div>

					<div class="avalon-works-showcase__descs grid grid-area-1 place-items-center">
						<?php foreach ( $items as $index => $item ) : ?>
							<div class="avalon-works-showcase__desc text-body-4 <?php echo esc_attr( 0 === $index ? 'is-active' : '' ); ?>" data-index="<?php echo esc_attr( $index ); ?>">
								<?php echo wp_kses_post( nl2br( $item['description'] ?? '' ) ); ?>
							</div>
							<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
