<?php
/**
 * Elementor Global init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\Page;

/**
 * Integrate with Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Page_Settings
 */
class Page_Settings {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		if ( ! class_exists( '\Elementor\Core\DocumentTypes\Page' ) ) {
			return;
		}

		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_styles' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'register_display_controls' ] );

		add_filter( 'body_class', [ $this, 'body_classes' ] );
	}

	/**
	 * Inline Style
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_styles() {
		wp_add_inline_style( 'elementor-editor', '#elementor-panel .elementor-control-hide_title{display:none}' );
	}

	/**
	 * Register display controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_display_controls( $document ) {
		if ( ! $document instanceof Page ) {
			return;
		}

		$this->register_page_controls( $document );
		$this->register_color_scheme_controls( $document );
		$this->register_typography_controls( $document );
		$this->register_site_content_controls( $document );
	}

	/**
	 * Register page controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_page_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( 'page' !== $post_type ) {
			return;
		}

		$document->start_injection(
			[
				'of'       => 'post_status',
				'fallback' => [
					'of' => 'post_title',
				],
			]
		);

		$document->add_control(
			'hide_page_title',
			[
				'label'     => esc_html__( 'Hide Title', 'avalon-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'.elementor-' . $document->get_main_id() . ' h1.page-title' => 'display: none !important;',
					'.elementor-page-' . $document->get_main_id() . ' h1.page-title' => 'display: none !important;',
				],
				'separator' => 'before',
			],
		);

		$document->end_injection();
	}

	/**
	 * Register color scheme controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_color_scheme_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( \AvalonAddons\Elementor\Builder\Post_Type::POST_TYPE === $post_type ) {
			return;
		}

		$document->start_controls_section(
			'section_avalon_color_scheme',
			[
				'label' => esc_html__( 'Avalon Color Scheme', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_control(
			'avalon_menu_dark_mode',
			[
				'label'        => esc_html__( 'Menu Dark Mode', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'avalon-menu-dark-mode--',
			]
		);

		$document->add_control(
			'avalon_dark_mode',
			[
				'label'        => esc_html__( 'Dark Mode', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'dark-mode dark-mode--',
			]
		);

		$document->add_control(
			'avalon_color_scheme_heading',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Color Scheme', 'avalon-addons' ),
				'separator' => 'before',
			]
		);

		$document->add_control(
			'avalon_color_primary',
			[
				'label'     => esc_html__( 'Primary Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-primary: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-primary: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_background',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--body-background-color: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--body-background-color: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_text',
			[
				'label'     => esc_html__( 'Text Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-text: {{VALUE}}; color: var(--color-text);',
					'{{WRAPPER}} .dark-mode' => '--color-text: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_heading',
			[
				'label'     => esc_html__( 'Heading Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-heading: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-heading: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_text_emphasis',
			[
				'label'     => esc_html__( 'Text Emphasis Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-text-emphasis: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-text-emphasis: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_text_subtle',
			[
				'label'     => esc_html__( 'Text Subtle Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-text-subtle: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-text-subtle: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_link',
			[
				'label'     => esc_html__( 'Link Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-link: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-link: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_link_hover',
			[
				'label'     => esc_html__( 'Link Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-link-hover: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-link-hover: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_border',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-border-primary: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-border-primary: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_color_border_secondary',
			[
				'label'     => esc_html__( 'Border Color Secondary', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}'            => '--color-border-secondary: {{VALUE}};',
					'{{WRAPPER}} .dark-mode' => '--color-border-secondary: {{VALUE}};',
				],
			]
		);

		$document->end_controls_section();
	}

	/**
	 * Register typography controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_typography_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( \AvalonAddons\Elementor\Builder\Post_Type::POST_TYPE === $post_type ) {
			return;
		}

		$weight_options = $this->get_font_weight_options();

		$document->start_controls_section(
			'section_avalon_typography',
			[
				'label' => esc_html__( 'Avalon Typography', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// Body Font.
		$document->add_control(
			'avalon_popover_body_toggle',
			[
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label'        => esc_html__( 'Body Font', 'avalon-addons' ),
				'label_off'    => esc_html__( 'Default', 'avalon-addons' ),
				'label_on'     => esc_html__( 'Custom', 'avalon-addons' ),
				'return_value' => 'yes',
			]
		);

		$document->start_popover();

		$document->add_control(
			'avalon_body_font_family',
			[
				'label'     => esc_html_x( 'Family', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::FONT,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}' => '--body-font: "{{VALUE}}";',
				],
			]
		);

		$document->add_control(
			'avalon_body_font_weight',
			[
				'label'     => esc_html_x( 'Weight', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $weight_options,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}' => '--body-font-weight: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_body_font_weight_custom',
			[
				'label'      => esc_html_x( 'Weight', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '' ],
				'range'      => [
					'' => [
						'min'  => 100,
						'max'  => 900,
						'step' => 25,
					],
				],
				'default'    => [
					'size' => 400,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--body-font-weight: {{SIZE}};',
				],
				'condition'  => [
					'avalon_body_font_weight' => 'custom',
				],
			]
		);

		$document->add_responsive_control(
			'avalon_body_font_size',
			[
				'label'      => esc_html_x( 'Size', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'vw' ],
				'range'      => [
					'px'  => [
						'min' => 1,
						'max' => 200,
					],
					'em'  => [ 'max' => 20 ],
					'rem' => [ 'max' => 20 ],
					'vw'  => [
						'min'  => 0.1,
						'max'  => 10,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--body-font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->add_control(
			'avalon_body_font_style',
			[
				'label'     => esc_html_x( 'Style', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''        => esc_html__( 'Default', 'avalon-addons' ),
					'normal'  => esc_html_x( 'Normal', 'Typography Control', 'avalon-addons' ),
					'italic'  => esc_html_x( 'Italic', 'Typography Control', 'avalon-addons' ),
					'oblique' => esc_html_x( 'Oblique', 'Typography Control', 'avalon-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => '--body-font-style: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_body_text_transform',
			[
				'label'     => esc_html_x( 'Transform', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''           => esc_html__( 'Default', 'avalon-addons' ),
					'uppercase'  => esc_html_x( 'Uppercase', 'Typography Control', 'avalon-addons' ),
					'lowercase'  => esc_html_x( 'Lowercase', 'Typography Control', 'avalon-addons' ),
					'capitalize' => esc_html_x( 'Capitalize', 'Typography Control', 'avalon-addons' ),
					'none'       => esc_html__( 'Normal', 'avalon-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_body_text_decoration',
			[
				'label'     => esc_html_x( 'Decoration', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''             => esc_html__( 'Default', 'avalon-addons' ),
					'underline'    => esc_html_x( 'Underline', 'Typography Control', 'avalon-addons' ),
					'overline'     => esc_html_x( 'Overline', 'Typography Control', 'avalon-addons' ),
					'line-through' => esc_html_x( 'Line Through', 'Typography Control', 'avalon-addons' ),
					'none'         => esc_html__( 'None', 'avalon-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-decoration: {{VALUE}};',
				],
			]
		);

		$document->add_responsive_control(
			'avalon_body_line_height',
			[
				'label'      => esc_html__( 'Line Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [ 'min' => 1 ],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--body-line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->add_responsive_control(
			'avalon_body_letter_spacing',
			[
				'label'      => esc_html__( 'Letter Spacing', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px'  => [
						'min'  => -5,
						'max'  => 10,
						'step' => 0.1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--body-letter-spacing: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->add_control(
			'avalon_body_font_stretch',
			[
				'label'      => esc_html_x( 'Width', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min'  => 0,
						'max'  => 150,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => 'font-stretch: {{SIZE}}%;',
				],
			]
		);

		$document->end_popover();

		// Heading Font Base.
		$document->add_control(
			'avalon_popover_heading_toggle',
			[
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label'        => esc_html__( 'Heading Font', 'avalon-addons' ),
				'label_off'    => esc_html__( 'Default', 'avalon-addons' ),
				'label_on'     => esc_html__( 'Custom', 'avalon-addons' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$document->start_popover();

		$document->add_control(
			'avalon_heading_font_family',
			[
				'label'     => esc_html_x( 'Family', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::FONT,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}' => '--heading-font: "{{VALUE}}";',
				],
			]
		);

		$document->add_control(
			'avalon_heading_font_stretch',
			[
				'label'      => esc_html_x( 'Width', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min'  => 0,
						'max'  => 150,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} h1, {{WRAPPER}} h2, {{WRAPPER}} h3, {{WRAPPER}} h4, {{WRAPPER}} h5, {{WRAPPER}} h6, {{WRAPPER}} .heading' => 'font-stretch: {{SIZE}}%;',
				],
			]
		);

		$document->end_popover();

		for ( $i = 1; $i <= 6; $i++ ) {
			$this->register_heading_level_controls( $document, $i );
		}

		$document->end_controls_section();
	}

	/**
	 * Get font weight options.
	 *
	 * Matches Elementor's typography control format with 425/475 for Google Sans Flex.
	 *
	 * @return array<string, string>
	 */
	private function get_font_weight_options(): array {
		return [
			''       => esc_html__( 'Default', 'avalon-addons' ),
			'100'    => '100 ' . esc_html__( '(Thin)', 'avalon-addons' ),
			'200'    => '200 ' . esc_html__( '(Extra Light)', 'avalon-addons' ),
			'300'    => '300 ' . esc_html__( '(Light)', 'avalon-addons' ),
			'400'    => '400 ' . esc_html__( '(Normal)', 'avalon-addons' ),
			'500'    => '500 ' . esc_html__( '(Medium)', 'avalon-addons' ),
			'600'    => '600 ' . esc_html__( '(Semi Bold)', 'avalon-addons' ),
			'700'    => '700 ' . esc_html__( '(Bold)', 'avalon-addons' ),
			'800'    => '800 ' . esc_html__( '(Extra Bold)', 'avalon-addons' ),
			'900'    => '900 ' . esc_html__( '(Black)', 'avalon-addons' ),
			'normal' => esc_html__( 'Normal', 'avalon-addons' ),
			'bold'   => esc_html__( 'Bold', 'avalon-addons' ),
			'custom' => esc_html__( 'Custom', 'avalon-addons' ),
		];
	}

	/**
	 * Register heading level typography controls.
	 *
	 * @param object $document Document object.
	 * @param int    $level    Heading level (1-6).
	 *
	 * @return void
	 */
	private function register_heading_level_controls( $document, $level ) {
		$weight_options = $this->get_font_weight_options();
		$selector       = $this->get_heading_selector( $level );

		$document->add_control(
			'avalon_popover_heading_h' . $level . '_toggle',
			[
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label'        => sprintf( 'H%d', $level ),
				'label_off'    => esc_html__( 'Default', 'avalon-addons' ),
				'label_on'     => esc_html__( 'Custom', 'avalon-addons' ),
				'return_value' => 'yes',
			]
		);

		$document->start_popover();

		$document->add_responsive_control(
			'avalon_heading_h' . $level . '_font_size',
			[
				'label'      => esc_html_x( 'Size', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'vw' ],
				'range'      => [
					'px'  => [
						'min' => 1,
						'max' => 200,
					],
					'em'  => [ 'max' => 20 ],
					'rem' => [ 'max' => 20 ],
					'vw'  => [
						'min'  => 0.1,
						'max'  => 10,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--heading-font-size-h' . $level . ': {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->add_responsive_control(
			'avalon_heading_h' . $level . '_line_height',
			[
				'label'      => esc_html__( 'Line Height', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [ 'min' => 1 ],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--heading-line-height-h' . $level . ': {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->add_control(
			'avalon_heading_h' . $level . '_font_weight',
			[
				'label'     => esc_html_x( 'Weight', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $weight_options,
				'default'   => '',
				'selectors' => [
					$selector => 'font-weight: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_heading_h' . $level . '_font_weight_custom',
			[
				'label'      => esc_html_x( 'Weight', 'Typography Control', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '' ],
				'range'      => [
					'' => [
						'min'  => 100,
						'max'  => 900,
						'step' => 25,
					],
				],
				'default'    => [
					'size' => 400,
				],
				'selectors'  => [
					$selector => 'font-weight: {{SIZE}};',
				],
				'condition'  => [
					'avalon_heading_h' . $level . '_font_weight' => 'custom',
				],
			]
		);

		$document->add_control(
			'avalon_heading_h' . $level . '_font_style',
			[
				'label'     => esc_html_x( 'Style', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''        => esc_html__( 'Default', 'avalon-addons' ),
					'normal'  => esc_html_x( 'Normal', 'Typography Control', 'avalon-addons' ),
					'italic'  => esc_html_x( 'Italic', 'Typography Control', 'avalon-addons' ),
					'oblique' => esc_html_x( 'Oblique', 'Typography Control', 'avalon-addons' ),
				],
				'selectors' => [
					$selector => 'font-style: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_heading_h' . $level . '_text_transform',
			[
				'label'     => esc_html_x( 'Transform', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''           => esc_html__( 'Default', 'avalon-addons' ),
					'uppercase'  => esc_html_x( 'Uppercase', 'Typography Control', 'avalon-addons' ),
					'lowercase'  => esc_html_x( 'Lowercase', 'Typography Control', 'avalon-addons' ),
					'capitalize' => esc_html_x( 'Capitalize', 'Typography Control', 'avalon-addons' ),
					'none'       => esc_html__( 'Normal', 'avalon-addons' ),
				],
				'selectors' => [
					$selector => 'text-transform: {{VALUE}};',
				],
			]
		);

		$document->add_control(
			'avalon_heading_h' . $level . '_text_decoration',
			[
				'label'     => esc_html_x( 'Decoration', 'Typography Control', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''             => esc_html__( 'Default', 'avalon-addons' ),
					'underline'    => esc_html_x( 'Underline', 'Typography Control', 'avalon-addons' ),
					'overline'     => esc_html_x( 'Overline', 'Typography Control', 'avalon-addons' ),
					'line-through' => esc_html_x( 'Line Through', 'Typography Control', 'avalon-addons' ),
					'none'         => esc_html__( 'None', 'avalon-addons' ),
				],
				'selectors' => [
					$selector => 'text-decoration: {{VALUE}};',
				],
			]
		);

		$document->add_responsive_control(
			'avalon_heading_h' . $level . '_letter_spacing',
			[
				'label'      => esc_html__( 'Letter Spacing', 'avalon-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px'  => [
						'min'  => -5,
						'max'  => 10,
						'step' => 0.1,
					],
					'em'  => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
					'rem' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors'  => [
					$selector => 'letter-spacing: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$document->end_popover();
	}

	/**
	 * Get heading selector.
	 *
	 * @param int $level Heading level.
	 *
	 * @return string
	 */
	private function get_heading_selector( int $level ): string {
		return '{{WRAPPER}} h' . $level . ', {{WRAPPER}} .h' . $level;
	}

	/**
	 * Register site content controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_site_content_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( \AvalonAddons\Elementor\Builder\Post_Type::POST_TYPE === $post_type ) {
			return;
		}

		$document->start_controls_section(
			'section_site_content_settings',
			[
				'label' => esc_html__( 'Site Content', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_control(
			'site_content_top_spacing',
			[
				'label'       => esc_html__( 'Top Spacing', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					''       => esc_html__( 'Default', 'avalon-addons' ),
					'custom' => esc_html__( 'Custom', 'avalon-addons' ),
				],
				'default'     => 'custom',
				'label_block' => true,
			]
		);

		$document->add_control(
			'site_content_top_padding',
			[
				'label'     => esc_html__( 'Spacing', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'site_content_top_spacing' => 'custom',
				],
			]
		);

		$document->add_control(
			'site_content_bottom_spacing',
			[
				'label'       => esc_html__( 'Bottom Spacing', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					''       => esc_html__( 'Default', 'avalon-addons' ),
					'custom' => esc_html__( 'Custom', 'avalon-addons' ),
				],
				'default'     => 'custom',
				'label_block' => true,
			]
		);

		$document->add_control(
			'site_content_bottom_padding',
			[
				'label'     => esc_html__( 'Spacing', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'site_content_bottom_spacing' => 'custom',
				],
			]
		);

		$document->end_controls_section();
	}

	/**
	 * Body classes.
	 *
	 * @param array $classes Body classes.
	 */
	public function body_classes( $classes ) {
		if ( ! is_singular() || ! class_exists( '\Elementor\Plugin' ) ) {
			return $classes;
		}

		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );
		$page_settings_model   = $page_settings_manager->get_model( get_the_ID() );
		$settings              = $page_settings_model->get_settings();

		if ( ! empty( $settings['avalon_dark_mode'] ) ) {
			$classes[] = 'dark-mode';
			$classes[] = 'dark-mode--yes';
		}

		if ( ! empty( $settings['avalon_menu_dark_mode'] ) ) {
			$classes[] = 'avalon-menu-dark-mode--yes';
		}

		return $classes;
	}
}
