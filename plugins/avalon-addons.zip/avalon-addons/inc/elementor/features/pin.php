<?php
/**
 * Pin Handler
 *
 * Adds GSAP pin controls to all Elementor elements, including the new
 * atomic elements (div block, flexbox, grid).
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;

/**
 * Pin class
 */
class Pin {

	/**
	 * Atomic element types that support the pin control.
	 *
	 * @var array
	 */
	private $atomic_types = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	/**
	 * Instance.
	 *
	 * @var Pin
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @since 1.0.0
	 * @return Pin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Register controls on all elements.
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/container/_section_responsive/after_section_end', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/section/section_advanced/after_section_end', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/column/section_advanced/after_section_end', [ $this, 'register_controls' ], 10, 2 );

		// Register controls on atomic elements (div block, flexbox, grid).
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_atomic_prop' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_atomic_controls' ], 10, 2 );

		// Add data attributes to element wrappers on frontend.
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/container/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/section/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/column/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/e-div-block/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/e-flexbox/before_render', [ $this, 'add_pin_attributes' ] );
		add_action( 'elementor/frontend/e-grid/before_render', [ $this, 'add_pin_attributes' ] );
	}

	/**
	 * Register pin controls.
	 *
	 * @since 1.0.0
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function register_controls( $element ) {
		$element->start_controls_section(
			'avalon_pin',
			[
				'label' => esc_html__( 'GSAP Pin', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'avalon_pin_type',
			[
				'label'       => esc_html__( 'Pin Effect', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'none',
				'options'     => $this->get_pin_options(),
				'description' => esc_html__( 'Pins this element and pairs it with the element directly below it. Reveal (kéo màn): put this on the UPPER section - it is pulled up with the scroll while the next section stands still behind it. Cover: this element stands still while the next section slides up to cover it.', 'avalon-addons' ),
			]
		);

		$element->add_control(
			'avalon_pin_order',
			[
				'label'       => esc_html__( 'Inner First', 'avalon-addons' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'no',
				'label_on'    => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'   => esc_html__( 'No', 'avalon-addons' ),
				'description' => esc_html__( 'Enable when this is the first section on the page. The inner pin (widget) will finish before the outer pin starts.', 'avalon-addons' ),
				'condition'   => [
					'avalon_pin_type!' => 'none',
				],
			]
		);

		$element->add_control(
			'avalon_pin_start',
			[
				'label'       => esc_html__( 'Pin Start', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'top top',
				'options'     => [
					'top top'       => esc_html__( 'Top Top (Default)', 'avalon-addons' ),
					'bottom bottom' => esc_html__( 'Bottom Bottom', 'avalon-addons' ),
				],
				'description' => esc_html__( 'Determines where the pinned element sticks to the viewport.', 'avalon-addons' ),
				'condition'   => [
					'avalon_pin_type' => 'sticky',
				],
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Add pin prop to atomic elements schema.
	 *
	 * @since 1.0.0
	 * @param array $schema The props schema.
	 * @return array
	 */
	public function add_atomic_prop( $schema ) {
		if ( ! class_exists( String_Prop_Type::class ) ) {
			return $schema;
		}

		$schema['avalon_pin_type'] = String_Prop_Type::make()
			->enum( [ 'none', 'reveal', 'cover', 'sticky' ] )
			->default( 'none' );

		if ( class_exists( Boolean_Prop_Type::class ) && class_exists( Dependency_Manager::class ) ) {
			// Hide avalon_pin_order when avalon_pin_type is 'none'.
			$pin_order_deps = Dependency_Manager::make()
				->where(
					[
						'operator' => 'ne',
						'path'     => [ 'avalon_pin_type' ],
						'value'    => 'none',
						'effect'   => 'hide',
					]
				)
				->get();

			$schema['avalon_pin_order'] = Boolean_Prop_Type::make()
				->default( false )
				->set_dependencies( $pin_order_deps );

			// Hide avalon_pin_start when avalon_pin_type is not 'sticky'.
			$pin_start_deps = Dependency_Manager::make()
				->where(
					[
						'operator' => 'eq',
						'path'     => [ 'avalon_pin_type' ],
						'value'    => 'sticky',
						'effect'   => 'hide',
					]
				)
				->get();

			$schema['avalon_pin_start'] = String_Prop_Type::make()
				->enum( [ 'top top', 'bottom bottom' ] )
				->default( 'top top' )
				->set_dependencies( $pin_start_deps );
		}

		return $schema;
	}

	/**
	 * Add pin controls to atomic elements (div block, flexbox, grid).
	 *
	 * @since 1.0.0
	 * @param array                   $controls The atomic controls.
	 * @param \Elementor\Element_Base $element  The element.
	 * @return array
	 */
	public function add_atomic_controls( $controls, $element ) {
		if ( ! class_exists( Section::class ) || ! class_exists( Select_Control::class ) ) {
			return $controls;
		}

		if ( ! in_array( $element->get_name(), $this->atomic_types, true ) ) {
			return $controls;
		}

		$options = [];
		foreach ( $this->get_pin_options() as $value => $label ) {
			$options[] = [
				'value' => $value,
				'label' => $label,
			];
		}

		$items = [
			Select_Control::bind_to( 'avalon_pin_type' )
				->set_label( esc_html__( 'Pin Effect', 'avalon-addons' ) )
				->set_options( $options ),
		];

		if ( class_exists( Switch_Control::class ) ) {
			$items[] = Switch_Control::bind_to( 'avalon_pin_order' )
				->set_label( esc_html__( 'Inner First', 'avalon-addons' ) );
		}

		$pin_start_options = [
			[
				'value' => 'top top',
				'label' => esc_html__( 'Top Top (Default)', 'avalon-addons' ),
			],
			[
				'value' => 'bottom bottom',
				'label' => esc_html__( 'Bottom Bottom', 'avalon-addons' ),
			],
		];

		$items[] = Select_Control::bind_to( 'avalon_pin_start' )
			->set_label( esc_html__( 'Pin Start', 'avalon-addons' ) )
			->set_options( $pin_start_options );

		$controls[] = Section::make()
			->set_id( 'avalon_pin' )
			->set_label( esc_html__( 'GSAP Pin', 'avalon-addons' ) )
			->set_items( $items );

		return $controls;
	}

	/**
	 * Add pin data attributes to element wrapper.
	 *
	 * @since 1.0.0
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function add_pin_attributes( $element ) {
		if ( method_exists( $element, 'get_atomic_settings' ) ) {
			$settings = $element->get_atomic_settings();
			$type     = $settings['avalon_pin_type'] ?? 'none';
		} else {
			$settings = $element->get_settings_for_display();
			$type     = $settings['avalon_pin_type'] ?? 'none';
		}

		if ( 'none' === $type || empty( $type ) ) {
			return;
		}

		$element->add_render_attribute( '_wrapper', 'data-animate', esc_attr( $type ), true );

		// Add data-pin="inner" if pin order is inner-first.
		// Atomic elements return boolean, classic elements return 'yes'/'no' string.
		$pin_order = $settings['avalon_pin_order'] ?? false;
		if ( true === $pin_order || 'yes' === $pin_order ) {
			$element->add_render_attribute( '_wrapper', 'data-pin', 'inner', true );
		}

		// Add data-pin-start for sticky pin type.
		if ( 'sticky' === $type ) {
			$pin_start = $settings['avalon_pin_start'] ?? 'top top';
			if ( 'top top' !== $pin_start ) {
				$element->add_render_attribute( '_wrapper', 'data-pin-start', esc_attr( $pin_start ), true );
			}
		}
	}

	/**
	 * Get pin effect options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_pin_options() {
		return [
			'none'   => esc_html__( 'None', 'avalon-addons' ),
			'reveal' => esc_html__( 'Reveal', 'avalon-addons' ),
			'cover'  => esc_html__( 'Cover', 'avalon-addons' ),
			'sticky' => esc_html__( 'Sticky', 'avalon-addons' ),
		];
	}
}
