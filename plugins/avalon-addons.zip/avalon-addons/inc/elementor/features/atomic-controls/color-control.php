<?php
/**
 * Atomic Color Control
 *
 * Adds a native color picker control for Elementor's atomic elements
 * (div block, flexbox, grid). The control type 'color' is registered by
 * Elementor core and is the same component used by all atomic style pickers.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features\Atomic_Controls;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Color_Control class
 */
class Color_Control extends Atomic_Control_Base {

	/**
	 * Get the control type.
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'color';
	}

	/**
	 * Get the control props.
	 *
	 * @return array
	 */
	public function get_props(): array {
		return [
			'alpha'     => true,
			'clearable' => true,
		];
	}
}
