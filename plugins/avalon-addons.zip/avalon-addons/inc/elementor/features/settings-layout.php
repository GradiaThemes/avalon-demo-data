<?php
/**
 * Settings Layout
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Core\Breakpoints\Manager as Breakpoints_Manager;
use Elementor\Controls_Manager;

/**
 * Class Settings_Layout
 */
class Settings_Layout extends Module {

	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'settings-layout';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/element/kit/section_settings-layout/before_section_end', [ $this, 'update_settings_controls' ], 10, 2 );
	}

	/**
	 * Update settings controls.
	 *
	 * @param \Elementor\Controls_Stack $element Controls_Stack.
	 */
	public function update_settings_controls( $element ) {
		$breakpoints_default_config = Breakpoints_Manager::get_default_config();
		$breakpoint_key_mobile      = Breakpoints_Manager::BREAKPOINT_KEY_MOBILE;
		$breakpoint_key_tablet      = Breakpoints_Manager::BREAKPOINT_KEY_TABLET;
		$element->update_responsive_control(
			'container_width',
			[
				'label'          => esc_html__( 'Content Width', 'avalon-addons' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'        => [
					'size' => 1440,
				],
				'tablet_default' => [
					'size' => $breakpoints_default_config[ $breakpoint_key_tablet ]['default_value'],
				],
				'mobile_default' => [
					'size' => $breakpoints_default_config[ $breakpoint_key_mobile ]['default_value'],
				],
				'range'          => [
					'px' => [
						'min'  => 300,
						'max'  => 1500,
						'step' => 10,
					],
				],
				'description'    => esc_html__( 'Sets the default width of the content area (Default: 1200px)', 'avalon-addons' ),
				'selectors'      => [
					'.elementor-section.elementor-section-boxed > .elementor-container' => 'max-width: {{SIZE}}{{UNIT}}',
					'.e-con' => '--container-max-width: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}
}
