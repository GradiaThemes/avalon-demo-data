<?php
/**
 * Animation Handler
 *
 * Adds GSAP-based animation controls to all Elementor widgets.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

/**
 * Animation class
 */
class Animation {
	/**
	 * Instance.
	 *
	 * @var Animation
	 */
	private static $instance = null;

	/**
	 * Cached element paths.
	 *
	 * @var array
	 */
	private static $element_paths = [];

	/**
	 * Get instance.
	 *
	 * @return Animation
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Register controls on all widgets.
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ], 10, 2 );

		// Add data attributes to widget wrapper on frontend.
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'add_animation_attributes' ] );
	}

	/**
	 * Get animation presets.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_animation_presets() {
		return [
			''              => esc_html__( 'None', 'avalon-addons' ),
			'fade-up'       => esc_html__( 'Fade Up', 'avalon-addons' ),
			'fade-down'     => esc_html__( 'Fade Down', 'avalon-addons' ),
			'fade-left'     => esc_html__( 'Fade Left', 'avalon-addons' ),
			'fade-right'    => esc_html__( 'Fade Right', 'avalon-addons' ),
			'fade-in'       => esc_html__( 'Fade In', 'avalon-addons' ),
			'scale-in'      => esc_html__( 'Scale In', 'avalon-addons' ),
			'zoom-in'       => esc_html__( 'Zoom In', 'avalon-addons' ),
			'zoom-out'      => esc_html__( 'Zoom Out', 'avalon-addons' ),
			'blur-in'       => esc_html__( 'Blur In', 'avalon-addons' ),
			'rotate-in'     => esc_html__( 'Rotate In', 'avalon-addons' ),
			'slide-up'      => esc_html__( 'Slide Up', 'avalon-addons' ),
			'slide-down'    => esc_html__( 'Slide Down', 'avalon-addons' ),
			'slide-left'    => esc_html__( 'Slide Left', 'avalon-addons' ),
			'slide-right'   => esc_html__( 'Slide Right', 'avalon-addons' ),
			'clip-up'       => esc_html__( 'Clip Up', 'avalon-addons' ),
			'clip-down'     => esc_html__( 'Clip Down', 'avalon-addons' ),
			'clip-left'     => esc_html__( 'Clip Left', 'avalon-addons' ),
			'clip-right'    => esc_html__( 'Clip Right', 'avalon-addons' ),
			'split-chars'   => esc_html__( 'Split Characters', 'avalon-addons' ),
			'split-words'   => esc_html__( 'Split Words', 'avalon-addons' ),
			'split-lines'   => esc_html__( 'Split Lines', 'avalon-addons' ),
			'flip-x-in'     => esc_html__( 'Flip X In', 'avalon-addons' ),
			'flip-x-out'    => esc_html__( 'Flip X Out', 'avalon-addons' ),
			'flip-y-in'     => esc_html__( 'Flip Y In', 'avalon-addons' ),
			'flip-y-out'    => esc_html__( 'Flip Y Out', 'avalon-addons' ),
			'rotate-in-90'  => esc_html__( 'Rotate In 90', 'avalon-addons' ),
			'rotate-in-180' => esc_html__( 'Rotate In 180', 'avalon-addons' ),
			'clip-circle'   => esc_html__( 'Clip Circle', 'avalon-addons' ),
			'fade-scale-in' => esc_html__( 'Fade Scale In', 'avalon-addons' ),
			'blur-fade-up'  => esc_html__( 'Blur Fade Up', 'avalon-addons' ),
		];
	}

	/**
	 * Get easing options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_easing_options() {
		return [
			'power1.out'  => 'Power1 Out',
			'power2.out'  => 'Power2 Out (Default)',
			'power3.out'  => 'Power3 Out',
			'power4.out'  => 'Power4 Out',
			'back.out'    => 'Back Out',
			'elastic.out' => 'Elastic Out',
			'bounce.out'  => 'Bounce Out',
			'circ.out'    => 'Circ Out',
			'expo.out'    => 'Expo Out',
			'sine.out'    => 'Sine Out',
		];
	}

	/**
	 * Get ScrollTrigger start options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_trigger_options() {
		return [
			'top 90%'       => esc_html__( 'Top 90%', 'avalon-addons' ),
			'top 85%'       => esc_html__( 'Top 85%', 'avalon-addons' ),
			'top 80%'       => esc_html__( 'Top 80% (Default)', 'avalon-addons' ),
			'top 75%'       => esc_html__( 'Top 75%', 'avalon-addons' ),
			'top 70%'       => esc_html__( 'Top 70%', 'avalon-addons' ),
			'top 60%'       => esc_html__( 'Top 60%', 'avalon-addons' ),
			'top 50%'       => esc_html__( 'Top 50%', 'avalon-addons' ),
			'center center' => esc_html__( 'Center Center', 'avalon-addons' ),
		];
	}

	/**
	 * Get trigger type options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_trigger_type_options() {
		return [
			'self'   => esc_html__( 'Element Itself', 'avalon-addons' ),
			'parent' => esc_html__( 'Parent Container', 'avalon-addons' ),
			'header' => esc_html__( 'Site Header', 'avalon-addons' ),
			'footer' => esc_html__( 'Site Footer', 'avalon-addons' ),
			'custom' => esc_html__( 'Custom Selector', 'avalon-addons' ),
		];
	}

	/**
	 * Find element path in Elementor data structure.
	 *
	 * @param string $target_id Element ID to find.
	 * @param int    $post_id   Post ID (optional).
	 * @return array Element path from root to target.
	 */
	private function find_element_path( string $target_id, $post_id = null ): array {
		if ( ! $post_id ) {
			$post_id = get_the_ID();
		}

		$cache_key = $post_id . '_' . $target_id;

		if ( isset( self::$element_paths[ $cache_key ] ) ) {
			return self::$element_paths[ $cache_key ];
		}

		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return [];
		}

		$document = \Elementor\Plugin::$instance->documents->get( $post_id );

		if ( ! $document ) {
			return [];
		}

		$elements_data = $document->get_elements_data();
		$path          = $this->find_path_recursive( $elements_data, $target_id );

		self::$element_paths[ $cache_key ] = $path;

		return $path;
	}

	/**
	 * Recursively search for element and return its path.
	 *
	 * @param array  $elements  Elements array.
	 * @param string $target_id Target element ID.
	 * @param array  $path      Current path.
	 * @return array
	 */
	private function find_path_recursive( array $elements, string $target_id, array $path = [] ): array {
		foreach ( $elements as $element ) {
			$current_path = array_merge( $path, [ $element ] );
			$current_id   = $element['id'] ?? '';

			if ( $current_id === $target_id ) {
				return $current_path;
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$found = $this->find_path_recursive( $element['elements'], $target_id, $current_path );
				if ( ! empty( $found ) ) {
					return $found;
				}
			}
		}

		return [];
	}

	/**
	 * Register animation controls.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function register_controls( $element ) {
		$element->start_controls_section(
			'avalon_motion_effects',
			[
				'label' => esc_html__( 'GSAP Animations', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'avalon_animation_enable',
			[
				'label'        => esc_html__( 'Enable Animation', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$element->add_control(
			'avalon_animation_preset',
			[
				'label'     => esc_html__( 'Animation', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'fade-up',
				'options'   => $this->get_animation_presets(),
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_duration',
			[
				'label'     => esc_html__( 'Duration', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 0.8,
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_delay',
			[
				'label'     => esc_html__( 'Delay', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 0,
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_ease',
			[
				'label'     => esc_html__( 'Easing', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'power2.out',
				'options'   => $this->get_easing_options(),
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_scroll_heading',
			[
				'label'     => esc_html__( 'Scroll Trigger', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_st_start',
			[
				'label'     => esc_html__( 'Trigger Point', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'top 80%',
				'options'   => $this->get_trigger_options(),
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_trigger_type',
			[
				'label'     => esc_html__( 'Trigger Element', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'self',
				'options'   => $this->get_trigger_type_options(),
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_trigger_custom',
			[
				'label'       => esc_html__( 'Custom Selector', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '#id or .class',
				'description' => esc_html__( 'Enter CSS ID (e.g., #my-id) or Class (e.g., .my-class)', 'avalon-addons' ),
				'label_block' => true,
				'condition'   => [
					'avalon_animation_enable'       => 'yes',
					'avalon_animation_trigger_type' => 'custom',
				],
			]
		);

		$element->add_control(
			'avalon_animation_once',
			[
				'label'        => esc_html__( 'Animate Once', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'avalon-addons' ),
				'label_off'    => esc_html__( 'No', 'avalon-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => esc_html__( 'Run the animation only once when scrolling.', 'avalon-addons' ),
				'condition'    => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'avalon_animation_offset_heading',
			[
				'label'     => esc_html__( 'Offset', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'fade-up', 'fade-down', 'fade-left', 'fade-right' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_offset_y',
			[
				'label'     => esc_html__( 'Vertical Offset', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 10,
					],
				],
				'default'   => [
					'size' => 100,
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'fade-up', 'fade-down' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_offset_x',
			[
				'label'     => esc_html__( 'Horizontal Offset', 'avalon-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 10,
					],
				],
				'default'   => [
					'size' => 100,
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'fade-left', 'fade-right' ],
				],
			]
		);

		// Split Text Settings.
		$element->add_control(
			'avalon_animation_split_heading',
			[
				'label'     => esc_html__( 'Text Split Settings', 'avalon-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_split_selector',
			[
				'label'     => esc_html__( 'Selector', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'avalon',
				'options'   => [
					'avalon'  => esc_html__( 'Avalon Heading', 'avalon-addons' ),
					'element' => esc_html__( 'Elementor Heading', 'avalon-addons' ),
					'custom'  => esc_html__( 'Custom', 'avalon-addons' ),
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_split_selector_custom',
			[
				'label'       => esc_html__( 'Text Selector', 'avalon-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( '.elementor-heading-title', 'avalon-addons' ),
				'description' => esc_html__( 'CSS selector for the text element inside this widget. Leave empty to use the widget wrapper.', 'avalon-addons' ),
				'label_block' => true,
				'condition'   => [
					'avalon_animation_split_selector' => 'custom',
					'avalon_animation_enable'         => 'yes',
					'avalon_animation_preset'         => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_stagger',
			[
				'label'       => esc_html__( 'Stagger', 'avalon-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.1,
				],
				'description' => esc_html__( 'Delay between each character/word/line animation.', 'avalon-addons' ),
				'condition'   => [
					'avalon_animation_enable' => 'yes',
					'avalon_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'avalon_animation_st_end',
			[
				'label'     => esc_html__( 'End Point', 'avalon-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'bottom 20%',
				'options'   => [
					'bottom 20%'    => esc_html__( 'Bottom 20% (Default)', 'avalon-addons' ),
					'bottom 10%'    => esc_html__( 'Bottom 10%', 'avalon-addons' ),
					'bottom 30%'    => esc_html__( 'Bottom 30%', 'avalon-addons' ),
					'center center' => esc_html__( 'Center Center', 'avalon-addons' ),
				],
				'condition' => [
					'avalon_animation_enable' => 'yes',
				],
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Add animation data attributes to widget wrapper.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function add_animation_attributes( $element ) {
		$settings = $element->get_settings_for_display();

		// Check if animation is enabled.
		if ( empty( $settings['avalon_animation_enable'] ) || 'yes' !== $settings['avalon_animation_enable'] ) {
			return;
		}

		$preset = $settings['avalon_animation_preset'] ?? '';

		// Skip if no preset selected.
		if ( empty( $preset ) ) {
			return;
		}

		$attributes = [
			'data-animate' => esc_attr( $preset ),
		];

		// Duration (only if different from default).
		$duration = $settings['avalon_animation_duration']['size'] ?? 0.8;
		if ( 0.8 !== (float) $duration ) {
			$attributes['data-animate-duration'] = esc_attr( $duration );
		}

		// Delay (only if greater than 0).
		$delay = $settings['avalon_animation_delay']['size'] ?? 0;
		if ( $delay > 0 ) {
			$attributes['data-animate-delay'] = esc_attr( $delay );
		}

		// Easing (only if different from default).
		$ease = $settings['avalon_animation_ease'] ?? 'power2.out';
		if ( 'power2.out' !== $ease ) {
			$attributes['data-animate-ease'] = esc_attr( $ease );
		}

		// ScrollTrigger start (only if different from default).
		$st_start = $settings['avalon_animation_st_start'] ?? 'top 80%';
		if ( 'top 80%' !== $st_start ) {
			$attributes['data-st-start'] = esc_attr( $st_start );
		}

		// Trigger element (data-st-trigger).
		$trigger_type = $settings['avalon_animation_trigger_type'] ?? 'self';

		if ( 'parent' === $trigger_type ) {
			// Find topmost container by parsing Elementor data structure.
			$widget_id = $element->get_id();
			$path      = $this->find_element_path( $widget_id );

			if ( ! empty( $path ) ) {
				// Find the first container/section/column in the path (topmost parent).
				foreach ( $path as $el ) {
					$el_type = $el['elType'] ?? '';
					if ( in_array( $el_type, [ 'container', 'section', 'column' ], true ) ) {
						$container_id = $el['id'] ?? '';
						if ( $container_id ) {
							$attributes['data-st-trigger'] = '[data-id="' . esc_attr( $container_id ) . '"]';
						}
						break;
					}
				}
			}
		} elseif ( 'custom' === $trigger_type ) {
			$custom_selector = $settings['avalon_animation_trigger_custom'] ?? '';
			if ( ! empty( $custom_selector ) ) {
				$attributes['data-st-trigger'] = esc_attr( $custom_selector );
			}
		} elseif ( 'header' === $trigger_type ) {
			$attributes['data-st-trigger'] = '.site-header';
		} elseif ( 'footer' === $trigger_type ) {
			$attributes['data-st-trigger'] = '.site-footer';
		}

		// Animate once (only if disabled).
		$once = $settings['avalon_animation_once'] ?? 'yes';
		if ( 'yes' !== $once ) {
			$attributes['data-st-once'] = 'false';
		}

		// Offset Y (for fade-up, fade-down).
		if ( in_array( $preset, [ 'fade-up', 'fade-down' ], true ) ) {
			$offset_y = $settings['avalon_animation_offset_y']['size'] ?? 50;
			if ( 50 !== (int) $offset_y ) {
				$attributes['data-animate-y'] = esc_attr( $offset_y );
			}
		}

		// Offset X (for fade-left, fade-right).
		if ( in_array( $preset, [ 'fade-left', 'fade-right' ], true ) ) {
			$offset_x = $settings['avalon_animation_offset_x']['size'] ?? 50;
			if ( 50 !== (int) $offset_x ) {
				$attributes['data-animate-x'] = esc_attr( $offset_x );
			}
		}

		// Split text settings.
		$split_presets = [ 'split-chars', 'split-words', 'split-lines' ];
		if ( in_array( $preset, $split_presets, true ) ) {
			// Text selector.
			$selector = '';
			if ( 'avalon' === $settings['avalon_animation_split_selector'] ) {
				$selector = '.avalon-heading';
			} elseif ( 'element' === $settings['avalon_animation_split_selector'] ) {
				$selector = '.elementor-heading-title';
			} elseif ( 'custom' === $settings['avalon_animation_split_selector'] ) {
				$selector = $settings['avalon_animation_split_selector_custom'] ?? '';
			}

			if ( ! empty( $selector ) ) {
				$attributes['data-animate-selector'] = esc_attr( $selector );
			}

			// Stagger (only if different from default).
			$stagger = $settings['avalon_animation_stagger']['size'] ?? 0.1;
			if ( 0.1 !== (float) $stagger ) {
				$attributes['data-animate-stagger'] = esc_attr( $stagger );
			}

			// ScrollTrigger end (only if different from default).
			$st_end = $settings['avalon_animation_st_end'] ?? 'bottom 20%';
			if ( 'bottom 20%' !== $st_end ) {
				$attributes['data-st-end'] = esc_attr( $st_end );
			}
		}

		// Add class to disable CSS transitions that conflict with GSAP.
		$element->add_render_attribute( '_wrapper', 'class', 'has-gsap-animation' );
		$element->add_render_attribute( '_wrapper', $attributes );
	}
}
