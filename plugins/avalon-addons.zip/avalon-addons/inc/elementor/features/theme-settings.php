<?php
/**
 * Theme Settings Handler
 *
 * Adds GSAP-based animation controls to all Elementor widgets.
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AvalonAddons\Elementor\Features\Atomic_Controls\Color_Control;
use Elementor\Controls_Manager;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;

/**
 * Theme Settings class
 */
class Theme_Settings {
	/**
	 * Atomic element types that support the theme settings.
	 *
	 * @var array
	 */
	private $atomic_types = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	/**
	 * Instance.
	 *
	 * @var Theme_Settings
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return Theme_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		// Register controls on container, column, and section elements.
		add_action( 'elementor/element/section/section_background/before_section_start', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/column/section_style/before_section_start', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/container/section_background/before_section_start', [ $this, 'register_controls' ], 10, 2 );

		// Register controls on atomic elements (div block, flexbox, grid).
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_atomic_prop' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_atomic_controls' ], 10, 2 );

		// Add classes to atomic element wrappers on frontend.
		add_action( 'elementor/frontend/e-div-block/before_render', [ $this, 'add_dark_mode_class' ] );
		add_action( 'elementor/frontend/e-flexbox/before_render', [ $this, 'add_dark_mode_class' ] );
		add_action( 'elementor/frontend/e-grid/before_render', [ $this, 'add_dark_mode_class' ] );

		// Register the 'color' atomic control type in the editor (Elementor's
		// V2 editing panel does not render unknown control types, see
		// assets/js/elementor/editor/atomic-color-control.js).
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
	}
	/**
	 * Enqueue editor scripts.
	 *
	 * Registers the custom 'color' atomic control type so the color pickers
	 * appear in the atomic elements (div block, flexbox, grid) panel.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function enqueue_editor_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script(
			'avalon-addons-atomic-color-control',
			AVALON_ADDONS_URL . 'assets/js/elementor/editor/atomic-color-control' . $debug . '.js',
			[ 'elementor-common' ],
			AVALON_ADDONS_VERSION,
			true
		);
	}

	/**
	 * Register animation controls.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function register_controls( $element ) {
		$element->start_controls_section(
			'avalon_theme_settings',
			[
				'label' => esc_html__( 'Avalon Theme Settings', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$element->add_control(
			'avalon_menu_dark_mode',
			[
				'label'        => esc_html__( 'Menu Dark Mode', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'avalon-menu-dark-mode--',
			]
		);

		$element->add_control(
			'avalon_menu_hide',
			[
				'label'        => esc_html__( 'Menu Hide', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'avalon-menu-hide--',
			]
		);

		$element->add_control(
			'avalon_dark_mode',
			[
				'label'        => esc_html__( 'Dark Mode', 'avalon-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'dark-mode dark-mode--',
			]
		);

		$element->add_control(
			'avalon_color_scheme_heading',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Color Scheme', 'avalon-addons' ),
				'separator' => 'before',
			]
		);

		$element->add_control(
			'avalon_color_primary',
			[
				'label'     => esc_html__( 'Primary Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-primary: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_background',
			[
				'label'     => esc_html__( 'Background Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--body-background-color: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_text',
			[
				'label'     => esc_html__( 'Text Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-text: {{VALUE}}; color: var(--color-text);',
				],
			]
		);

		$element->add_control(
			'avalon_color_heading',
			[
				'label'     => esc_html__( 'Heading Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-heading: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_text_emphasis',
			[
				'label'     => esc_html__( 'Text Emphasis Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-text-emphasis: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_text_subtle',
			[
				'label'     => esc_html__( 'Text Subtle Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-text-subtle: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_link',
			[
				'label'     => esc_html__( 'Link Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-link: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_link_hover',
			[
				'label'     => esc_html__( 'Link Hover Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-link-hover: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_border',
			[
				'label'     => esc_html__( 'Border Color', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-border-primary: {{VALUE}};',
				],
			]
		);

		$element->add_control(
			'avalon_color_border_secondary',
			[
				'label'     => esc_html__( 'Border Color Secondary', 'avalon-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--color-border-secondary: {{VALUE}};',
				],
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Add dark mode prop to atomic elements schema.
	 *
	 * @param array $schema The props schema.
	 * @return array
	 */
	public function add_atomic_prop( $schema ) {
		if ( ! class_exists( Boolean_Prop_Type::class ) ) {
			return $schema;
		}

		$schema['avalon_menu_dark_mode'] = Boolean_Prop_Type::make()->default( false );
		$schema['avalon_menu_hide']      = Boolean_Prop_Type::make()->default( false );
		$schema['avalon_dark_mode']      = Boolean_Prop_Type::make()->default( false );

		if ( class_exists( Color_Prop_Type::class ) ) {
			$color_dependencies = Dependency_Manager::make()
				->where(
					[
						'operator' => 'ne',
						'path'     => [ 'avalon_dark_mode' ],
						'value'    => false,
						'effect'   => 'hide',
					]
				)
				->get();

			$color_props = [
				'avalon_color_primary'          => '',
				'avalon_color_background'       => '',
				'avalon_color_text'             => '',
				'avalon_color_heading'          => '',
				'avalon_color_text_emphasis'    => '',
				'avalon_color_text_subtle'      => '',
				'avalon_color_link'             => '',
				'avalon_color_link_hover'       => '',
				'avalon_color_border'           => '',
				'avalon_color_border_secondary' => '',
			];

			foreach ( $color_props as $key => $default ) {
				$schema[ $key ] = Color_Prop_Type::make()
					->default( $default );
			}
		}

		return $schema;
	}

	/**
	 * Add theme settings controls to atomic elements (div block, flexbox, grid).
	 *
	 * @param array                   $controls The atomic controls.
	 * @param \Elementor\Element_Base $element  The element.
	 * @return array
	 */
	public function add_atomic_controls( $controls, $element ) {
		if ( ! class_exists( Section::class ) || ! class_exists( Switch_Control::class ) ) {
			return $controls;
		}

		if ( ! in_array( $element->get_name(), $this->atomic_types, true ) ) {
			return $controls;
		}

		$items = [
			Switch_Control::bind_to( 'avalon_menu_dark_mode' )->set_label( esc_html__( 'Menu Dark Mode', 'avalon-addons' ) ),
			Switch_Control::bind_to( 'avalon_menu_hide' )->set_label( esc_html__( 'Menu Hide', 'avalon-addons' ) ),
			Switch_Control::bind_to( 'avalon_dark_mode' )->set_label( esc_html__( 'Dark Mode', 'avalon-addons' ) ),
		];

		if ( class_exists( Color_Control::class ) ) {
			$items[] = Color_Control::bind_to( 'avalon_color_primary' )->set_label( esc_html__( 'Primary Color', 'avalon-addons' ) )
			->set_meta( [ 'topDivider' => true ] );
			$items[] = Color_Control::bind_to( 'avalon_color_background' )->set_label( esc_html__( 'Background Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_text' )->set_label( esc_html__( 'Text Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_heading' )->set_label( esc_html__( 'Heading Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_text_emphasis' )->set_label( esc_html__( 'Text Emphasis Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_text_subtle' )->set_label( esc_html__( 'Text Subtle Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_link' )->set_label( esc_html__( 'Link Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_link_hover' )->set_label( esc_html__( 'Link Hover Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_border' )->set_label( esc_html__( 'Border Color', 'avalon-addons' ) );
			$items[] = Color_Control::bind_to( 'avalon_color_border_secondary' )->set_label( esc_html__( 'Border Color Secondary', 'avalon-addons' ) );
		}

		$controls[] = Section::make()
			->set_id( 'avalon_theme_settings' )
			->set_label( esc_html__( 'Avalon Theme Settings', 'avalon-addons' ) )
			->set_items( $items );

		return $controls;
	}

	/**
	 * Add dark mode class to atomic element wrapper.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function add_dark_mode_class( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) ) {
			return;
		}

		$settings = $element->get_atomic_settings();

		if ( ! empty( $settings['avalon_menu_dark_mode'] ) ) {
			$element->add_render_attribute( '_wrapper', 'class', [ 'avalon-menu-dark-mode--yes' ] );
		}

		if ( ! empty( $settings['avalon_menu_hide'] ) ) {
			$element->add_render_attribute( '_wrapper', 'class', [ 'avalon-menu-hide--yes' ] );
		}

		if ( ! empty( $settings['avalon_dark_mode'] ) ) {
			$element->add_render_attribute( '_wrapper', 'class', [ 'dark-mode', 'dark-mode--yes' ] );
		}

		// Emit the color CSS variables on the wrapper (atomic elements have no
		// `selectors` mechanism, so we set them inline). Mirrors the classic
		// `{{WRAPPER}} => '--color-*: {{VALUE}};'` selectors.
		$color_map = [
			'avalon_color_primary'          => '--color-primary',
			'avalon_color_background'       => '--body-background-color',
			'avalon_color_text'             => '--color-text',
			'avalon_color_heading'          => '--color-heading',
			'avalon_color_text_emphasis'    => '--color-text-emphasis',
			'avalon_color_text_subtle'      => '--color-text-subtle',
			'avalon_color_link'             => '--color-link',
			'avalon_color_link_hover'       => '--color-link-hover',
			'avalon_color_border'           => '--color-border-primary',
			'avalon_color_border_secondary' => '--color-border-secondary',
		];

		foreach ( $color_map as $setting_key => $css_var ) {
			$value = $settings[ $setting_key ] ?? null;

			if ( is_array( $value ) ) {
				$value = $value['value'] ?? '';
			}

			if ( is_string( $value ) && '' !== $value ) {
				$element->add_render_attribute( '_wrapper', 'style', $css_var . ': ' . esc_attr( $value ) . ';' );
			}
		}
	}
}
