( function ( $ ) {
	'use strict';

	const ControlFMautocomplete = elementor.modules.controls.BaseData.extend( {
		onReady() {
			this.avalonAutocomplete( this );

			this.avalonRemoveData( this );

			this.avalonSortable( this );

			this.avalonOnRender( this );
		},
		avalonAutocomplete( self ) {
			let $input_value = self.$el.find( '.avalon_autocomplete_value' ),
				self_value = $input_value.val(),
				multiple = $input_value.data( 'multiple' ),
				step = '',
				item_value = '';

			self.$el
				.find( '.avalon_autocomplete_param' )
				.autocomplete( {
					minLength: 1,
					source( request, response ) {
						$.ajax( {
							url: ajaxurl,
							dataType: 'json',
							method: 'post',
					data: {
						action: 'avalon_get_autocomplete_suggest',
						term: request.term,
						source: $input_value.data( 'source' ),
						nonce: typeof avalon_autocomplete !== 'undefined' ? avalon_autocomplete.nonce : '',
					},
							success( data ) {
								response( data.data );
							},
						} );
					},
					response( event, ui ) {
						self.$el
							.find( '.avalon_autocomplete' )
							.removeClass( 'loading' );
					},
					search( event, ui ) {
						self.$el
							.find( '.avalon_autocomplete' )
							.addClass( 'loading' );
					},
					select( event, ui ) {
						item_value = ui.item.value;

						if ( item_value === 'nothing-found' ) {
							return false;
						}
						self_value = $input_value.val();
						if ( self_value !== '' ) {
							step = ',';
						}

						const template =
							'<li class="avalon_autocomplete-label" data-value="' +
							item_value +
							'">' +
							'<span class="avalon_autocomplete-data">' +
							ui.item.label +
							'</span>' +
							'<a href="#" class="avalon_autocomplete-remove">×</a>' +
							'</li>';

						if ( multiple ) {
							self.$el
								.find( '.avalon_autocomplete' )
								.append( template );
							self_value = self_value + step + item_value;
						} else {
							if (
								self.$el.find(
									'.avalon_autocomplete .avalon_autocomplete-label'
								).length > 0
							) {
								self.$el
									.find(
										'.avalon_autocomplete .avalon_autocomplete-label'
									)
									.replaceWith( template );
							} else {
								self.$el
									.find( '.avalon_autocomplete' )
									.append( template );
							}
							self.$el
								.find(
									'.avalon_autocomplete .avalon_autocomplete-label'
								)
								.replaceWith( template );
							self_value = item_value;
						}

						self.$el.find( '.avalon_autocomplete_param' ).val( '' );
						$input_value.val( self_value );
						self.setValue( self_value );

						return false;
					},
					open( event ) {
						$( event.target )
							.data( 'uiAutocomplete' )
							.menu.activeMenu.addClass(
								'elementor-autocomplete-menu avalon-autocomplete-menu'
							);
					},
				} )
				.autocomplete( 'instance' )._renderItem = function (
				ul,
				item
			) {
				return $( '<li>' )
					.attr( 'data-value', item.value )
					.append( item.label )
					.appendTo( ul );
			};
			return self_value;
		},
		avalonRemoveData( self ) {
			const $input_value = self.$el.find( '.avalon_autocomplete_value' );
			self.$el
				.find( '.avalon_autocomplete' )
				.on( 'click', '.avalon_autocomplete-remove', function ( e ) {
					e.preventDefault();
					let $this = $( this ),
						self_value = '';

					$this.closest( '.avalon_autocomplete-label' ).remove();

					self.$el
						.find( '.avalon_autocomplete' )
						.find( '.avalon_autocomplete-label' )
						.each( function () {
							self_value =
								self_value + ',' + $( this ).data( 'value' );
						} );
					$input_value.val( self_value );
					self.setValue( self_value );
				} );
		},
		avalonSortable( self ) {
			let sortable = self.$el
					.find( '.avalon_autocomplete_value' )
					.data( 'sortable' ),
				self_value = '';
			if ( sortable ) {
				self.$el.find( '.avalon_autocomplete' ).sortable( {
					items: 'li.avalon_autocomplete-label',
					update( event, ui ) {
						self_value = '';

						self.$el
							.find( '.avalon_autocomplete' )
							.find( 'li.avalon_autocomplete-label' )
							.each( function () {
								self_value =
									self_value +
									',' +
									$( this ).data( 'value' );
							} );

						self.setValue( self_value );
					},
				} );
			}
		},
		avalonOnRender( self ) {
			const $input_value = self.$el.find( '.avalon_autocomplete_value' ),
				self_value = $input_value.val();

			$.ajax( {
				url: ajaxurl,
				dataType: 'json',
				method: 'post',
				data: {
					action: 'avalon_get_autocomplete_render',
					term: self_value,
					source: $input_value.data( 'source' ),
					nonce: typeof avalon_autocomplete !== 'undefined' ? avalon_autocomplete.nonce : '',
				},
				success( data ) {
					if ( data ) {
						self.$el
							.find( '.avalon_autocomplete' )
							.append( data.data );
						self.$el
							.find( '.avalon_autocomplete' )
							.find( 'li.avalon_autocomplete-loading' )
							.remove();
					}
				},
			} );
		},
		onBeforeDestroy() {
			if ( this.ui.input.data( 'autocomplete' ) ) {
				this.ui.input.autocomplete( 'destroy' );
			}

			this.$el.remove();
		},
	} );
	elementor.addControlView( 'avalon-autocomplete', ControlFMautocomplete );
} )( jQuery );
