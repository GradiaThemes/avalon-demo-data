<?php
/**
 * AutoComplete Control
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Dynamic_Controls\Autocomplete;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * AutoComplete Control
 */
class Control extends \Elementor\Base_Data_Control {
	/**
	 * Get heading control type.
	 *
	 * Retrieve the control type, in this case `heading`.
	 *
	 * @access public
	 *
	 * @return string Control type.
	 */
	public function get_type() {
		return 'avalon-autocomplete';
	}

	/**
	 * Enqueue Script & Style
	 *
	 * @return void
	 */
	public function enqueue() {
		// Styles.
		wp_enqueue_style(
			'avalon-autocomplete',
			plugins_url( 'css/autocomplete.css', __FILE__ ),
			[],
			'1.0.0'
		);

		// Scripts.
		wp_register_script(
			'avalon-autocomplete',
			plugins_url( 'js/autocomplete.js', __FILE__ ),
			[
				'jquery',
				'jquery-ui-autocomplete',
				'jquery-ui-sortable',
			],
			'1.0.0',
			true
		);

		// Localize script with nonce.
		wp_localize_script(
			'avalon-autocomplete',
			'avalon_autocomplete',
			[
				'nonce' => wp_create_nonce( 'avalon_autocomplete_nonce' ),
			]
		);

		wp_enqueue_script( 'avalon-autocomplete' );
	}

	/**
	 * Get heading control default settings.
	 *
	 * Retrieve the default settings of the heading control. Used to return the
	 * default settings while initializing the heading control.
	 *
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'multiple' => false,
			'sortable' => false,
			'source'   => 'category',
		];
	}

	/**
	 * Render heading control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<# if ( data.label ) {#>
			<label for="<?php echo esc_html( $control_uid ); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<# } #>
			<div class="elementor-control-input-wrapper">
				<ul class="avalon_autocomplete">
					<li class="avalon_autocomplete-input">
						<input class="avalon_autocomplete_param" type="text" placeholder="{{ data.placeholder }}"/>
						<input class="avalon_autocomplete_value" type="hidden" data-source="{{data.source}}"
								data-multiple="{{data.multiple}}"
								data-sortable="{{data.sortable}}" value="{{data.controlValue}}"/>
						<span class="loading"></span>
					</li>

					<li class="avalon_autocomplete-loading">
						<span class="loading"></span>
					</li>
				</ul>

			</div>
		</div>
		<# if ( data.description ) { #>
		<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}
}
