<?php
/**
 * Autocomplete Ajax Loader
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Dynamic_Controls\Autocomplete;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Autocomplete Ajax Loader
 */
class Autocomplete {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Allowed sources for autocomplete
	 *
	 * @var array
	 */
	private $allowed_sources = [
		'post',
		'page',
		'portfolio',
		'elementor_library',
		'category',
		'post_tag',
		'portfolio_type',
		'portfolio_tag',
		'portfolio_service',
		'attribute',
	];

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		// Register controls.
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );

		// AJAX.
		add_action( 'wp_ajax_avalon_get_autocomplete_suggest', [ $this, 'get_autocomplete_suggest' ] );
		add_action( 'wp_ajax_avalon_get_autocomplete_render', [ $this, 'get_autocomplete_render' ] );
	}

	/**
	 * Register autocomplete control
	 *
	 * @param object $controls_manager Controls manager.
	 *
	 * @return void
	 */
	public function register_controls( $controls_manager ) {
		$controls_manager->register( new Control() );
	}

	/**
	 * Autocomplete Suggest
	 *
	 * @return void
	 */
	public function get_autocomplete_suggest() {
		// Verify nonce.
		check_ajax_referer( 'avalon_autocomplete_nonce', 'nonce' );

		// Check capability.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die();
		}

		$result = [];

		$sources = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';
		if ( ! empty( $sources ) ) {
			$sources = explode( ',', $sources );
			foreach ( $sources as $source ) {
				$source = trim( $source );
				// Validate source against whitelist.
				if ( ! in_array( $source, $this->allowed_sources, true ) ) {
					continue;
				}
				$output = call_user_func( [ $this, 'autocomplete_' . $source . '_callback' ] );

				if ( is_array( $output ) ) {
					$result = array_merge( $output, $result );
				}
			}
		}

		wp_send_json_success( $result );

		exit;
	}

	/**
	 * Post callback
	 *
	 * @return array
	 */
	public function autocomplete_post_callback() {
		return $this->autocomplete_post_type_callback( 'post' );
	}

	/**
	 * Page callback
	 *
	 * @return array
	 */
	public function autocomplete_page_callback() {
		return $this->autocomplete_post_type_callback( 'page' );
	}

	/**
	 * Portfolio callback
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_callback() {
		return $this->autocomplete_post_type_callback( 'portfolio' );
	}

	/**
	 * Help Center callback
	 *
	 * @return array
	 */
	public function autocomplete_elementor_library_callback() {
		return $this->autocomplete_post_type_callback( 'elementor_library' );
	}

	/**
	 * Category callback
	 *
	 * @return array
	 */
	public function autocomplete_category_callback() {
		return $this->autocomplete_taxonomy_callback( 'category' );
	}

	/**
	 * Post Tag callback
	 *
	 * @return array
	 */
	public function autocomplete_post_tag_callback() {
		return $this->autocomplete_taxonomy_callback( 'post_tag' );
	}

	/**
	 * Portfolio Type callback
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_type_callback() {
		return $this->autocomplete_taxonomy_callback( 'portfolio_type' );
	}

	/**
	 * Portfolio Tag callback
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_tag_callback() {
		return $this->autocomplete_taxonomy_callback( 'portfolio_tag' );
	}

	/**
	 * Portfolio Service callback
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_service_callback() {
		return $this->autocomplete_taxonomy_callback( 'portfolio_service' );
	}

	/**
	 * Attribute callback
	 *
	 * @return array
	 */
	public function autocomplete_attribute_callback() {
		return $this->autocomplete_attributes_callback();
	}

	/**
	 * Autocomplete Render
	 *
	 * @return void
	 */
	public function get_autocomplete_render() {
		// Verify nonce.
		check_ajax_referer( 'avalon_autocomplete_nonce', 'nonce' );

		// Check capability.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die();
		}

		$result = [];

		$sources = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';
		if ( ! empty( $sources ) ) {
			$sources = explode( ',', $sources );
			foreach ( $sources as $source ) {
				$source = trim( $source );
				// Validate source against whitelist.
				if ( ! in_array( $source, $this->allowed_sources, true ) ) {
					continue;
				}
				$output = call_user_func( [ $this, 'autocomplete_' . $source . '_render' ] );
				if ( is_array( $output ) ) {
					$result = array_merge( $output, $result );
				}
			}
		}

		wp_send_json_success( $result );

		die();
	}

	/**
	 * Post render
	 *
	 * @return array
	 */
	public function autocomplete_post_render() {
		return $this->autocomplete_post_type_render( 'post' );
	}

	/**
	 * Page render
	 *
	 * @return array
	 */
	public function autocomplete_page_render() {
		return $this->autocomplete_post_type_render( 'page' );
	}

	/**
	 * Portfolio render
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_render() {
		return $this->autocomplete_post_type_render( 'portfolio' );
	}

	/**
	 * Help Center render
	 *
	 * @return array
	 */
	public function autocomplete_elementor_library_render() {
		return $this->autocomplete_post_type_render( 'elementor_library' );
	}

	/**
	 * Category render
	 *
	 * @return array
	 */
	public function autocomplete_category_render() {
		return $this->autocomplete_taxonomy_render( 'category' );
	}

	/**
	 * Post Tag render
	 *
	 * @return array
	 */
	public function autocomplete_post_tag_render() {
		return $this->autocomplete_taxonomy_render( 'post_tag' );
	}

	/**
	 * Portfolio Type render
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_type_render() {
		return $this->autocomplete_taxonomy_render( 'portfolio_type' );
	}

	/**
	 * Portfolio Tag render
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_tag_render() {
		return $this->autocomplete_taxonomy_render( 'portfolio_tag' );
	}

	/**
	 * Portfolio Service render
	 *
	 * @return array
	 */
	public function autocomplete_portfolio_service_render() {
		return $this->autocomplete_taxonomy_render( 'portfolio_service' );
	}

	/**
	 * Attribute render
	 *
	 * @return array
	 */
	public function autocomplete_attribute_render() {
		return $this->autocomplete_attributes_render();
	}

	/**
	 * Taxonomy Autocomplete
	 *
	 * @param string $taxonomy Taxonomy.
	 *
	 * @return array
	 */
	public function autocomplete_taxonomy_callback( $taxonomy = 'category' ) {
		// phpcs:ignore
		$cat_id = isset( $_POST['term'] ) ? intval( $_POST['term'] ) : 0;
		// phpcs:ignore
		$query  = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

		$result = [];

		global $wpdb;

		$search_like = '%' . $wpdb->esc_like( stripslashes( $query ) ) . '%';

		// phpcs:ignore
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = %s AND (a.term_id = %d OR b.slug LIKE %s OR b.name LIKE %s )",
				$taxonomy,
				$cat_id > 0 ? $cat_id : - 1,
				$search_like,
				$search_like
			),
			ARRAY_A
		);

		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = [];
				$data['value'] = $value['slug'];
				$data['label'] = esc_html__( 'Id', 'avalon-addons' ) . ': ' . $value['id'] . ' - ' . esc_html__( 'Name', 'avalon-addons' ) . ': ' . $value['name'];
				$result[]      = $data;
			}
		} else {
			$result[] = [
				'value' => 'nothing-found',
				'label' => esc_html__( 'Nothing Found', 'avalon-addons' ),
			];
		}

		return $result;
	}

	/**
	 * Post type Autocomplete
	 *
	 * @param string $post_type Post Type.
	 *
	 * @return array
	 */
	public function autocomplete_post_type_callback( $post_type = 'post' ) {
		// phpcs:ignore
		$query  = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		$result = [];

		$args = [
			'post_type'              => $post_type,
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			's'                      => $query,
		];

		$posts = get_posts( $args );

		if ( is_array( $posts ) && ! empty( $posts ) ) {
			foreach ( $posts as $post ) {
				$data          = [];
				$data['value'] = $post->ID;
				$data['label'] = esc_html__( 'Id', 'avalon-addons' ) . ': ' . $post->ID . ' - ' . esc_html__( 'Title', 'avalon-addons' ) . ': ' . esc_html( $post->post_title );
				$result[]      = $data;
			}
		} else {
			$result[] = [
				'value' => 'nothing-found',
				'label' => esc_html__( 'Nothing Found', 'avalon-addons' ),
			];
		}

		return $result;
	}

	/**
	 * Attributes Autocomplete
	 *
	 * @return array
	 */
	public function autocomplete_attributes_callback() {
		$result = [];

		$attributes = wc_get_attribute_taxonomies();

		if ( is_array( $attributes ) && ! empty( $attributes ) ) {
			foreach ( $attributes as $attribute ) {
				$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
				$terms    = get_terms(
					[
						'taxonomy'   => $taxonomy,
						'hide_empty' => false,
					]
				);

				if ( is_wp_error( $terms ) ) {
					continue;
				}

				foreach ( $terms as $term ) {
					$data          = [];
					$data['value'] = $term->slug;
					$data['label'] = esc_html( $term->name );
					$result[]      = $data;
				}
			}
		} else {
			$result[] = [
				'value' => 'nothing-found',
				'label' => esc_html__( 'Nothing Found', 'avalon-addons' ),
			];
		}

		return $result;
	}


	/**
	 * Taxonomy Render
	 *
	 * @param string $taxonomy Taxonomy.
	 *
	 * @return array
	 */
	public function autocomplete_taxonomy_render( $taxonomy = 'category' ) {
		// phpcs:ignore
		$query = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

		if ( empty( $query ) ) {
			return [];
		}

		$data   = [];
		$values = explode( ',', $query );

		$terms = get_terms(
			[
				'taxonomy' => $taxonomy,
				'slug'     => $values,
				'orderby'  => 'slug__in',
			]
		);

		if ( is_wp_error( $terms ) || ! $terms ) {
			return [];
		}

		foreach ( $terms as $term ) {

			$data[] = sprintf(
				'<li class="avalon_autocomplete-label" data-value="%s">
					<span class="avalon_autocomplete-data">%s%s - %s%s</span>
					<a href="#" class="avalon_autocomplete-remove">&times;</a>
				</li>',
				esc_attr( $term->slug ),
				esc_html__( 'Id: ', 'avalon-addons' ),
				esc_html( $term->term_id ),
				esc_html__( 'Name: ', 'avalon-addons' ),
				esc_html( $term->name )
			);
		}

		return $data;
	}

	/**
	 * Post Type Render
	 *
	 * @param string $post_type Post Type.
	 *
	 * @return array
	 */
	public function autocomplete_post_type_render( $post_type = 'post' ) {
		// phpcs:ignore
		$query = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

		if ( empty( $query ) ) {
			return [];
		}

		$values = explode( ',', $query );

		$data = [];

		$args = [
			'post_type'              => $post_type,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
			'post__in'               => $values,
			'orderby'                => 'post__in',
		];

		$query = new \WP_Query( $args );
		while ( $query->have_posts() ) :
			$query->the_post();
			$data[] = sprintf(
				'<li class="avalon_autocomplete-label" data-value="%s">
					<span class="avalon_autocomplete-data">%s%s - %s%s</span>
					<a href="#" class="avalon_autocomplete-remove">&times;</a>
				</li>',
				esc_attr( get_the_ID() ),
				esc_html__( 'Id: ', 'avalon-addons' ),
				esc_html( get_the_ID() ),
				esc_html__( 'Title: ', 'avalon-addons' ),
				esc_html( get_the_title() )
			);
		endwhile;
		wp_reset_postdata();

		return $data;
	}

	/**
	 * Attributes Render
	 *
	 * @return array
	 */
	public function autocomplete_attributes_render() {
		// phpcs:ignore
		$query = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

		if ( empty( $query ) ) {
			return [];
		}

		$values = explode( ',', $query );

		$attributes = wc_get_attribute_taxonomies();
		$data       = [];
		foreach ( $attributes as $attribute ) {
			$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
			$terms    = get_terms(
				[
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				]
			);

			if ( is_wp_error( $terms ) ) {
				continue;
			}

			foreach ( $terms as $term ) {
				if ( in_array( $term->name, $values, true ) || in_array( $term->slug, $values, true ) ) {
					$data[] = sprintf(
						'<li class="avalon_autocomplete-label" data-value="%s">
							<span class="avalon_autocomplete-data">%s</span>
							<a href="#" class="avalon_autocomplete-remove">&times;</a>
						</li>',
						esc_attr( $term->slug ),
						esc_html( $term->name )
					);
				}
			}
		}

		return $data;
	}
}
