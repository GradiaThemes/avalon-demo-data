<?php
/**
 * Elementor Settings
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

/**
 * Elementor Settings
 */
class Elementor_Settings extends Module {

	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'avalon-elementor-settings';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/documents/register_controls', [ $this, 'register_display_controls' ] );

		add_action( 'elementor/document/after_save', [ $this, 'save_post_meta' ], 10, 2 );
	}


	/**
	 * Register display controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_display_controls( $document ) {
		if ( ! $document instanceof PageBase ) {
			return;
		}

		$post_type = get_post_type( $document->get_main_id() );

		if ( Post_Type::POST_TYPE !== $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), Post_Type::TAXONOMY_TYPE );
		$terms = ! is_wp_error( $terms ) && $terms ? wp_list_pluck( $terms, 'slug' ) : '';

		if ( ! $terms ) {
			return;
		}

		if ( in_array( 'footer', $terms, true ) || in_array( 'header', $terms, true ) ) {
			$this->register_builder_content( $document );
		}
	}

	/**
	 * Register template controls of display.
	 *
	 * @param object $document Document object.
	 */
	protected function register_builder_content( $document ) {
		$document->start_controls_section(
			'section_builder_settings',
			[
				'label' => esc_html__( 'Builder Settings', 'avalon-addons' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$args_types      = $this->get_types();
		$get_types_extra = $this->get_types_extra();

		$document->add_control(
			'include_on',
			[
				'label'       => esc_html__( 'Display On', 'avalon-addons' ),
				'description' => esc_html__( 'Choose where should be displayed.', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => $args_types,
				'default'     => [],
			]
		);

		foreach ( $args_types as $key => $label ) {
			if ( in_array( $key, $get_types_extra, true ) ) {
				continue;
			}

			$document->add_control(
				'include_' . $key . '_ids',
				[
					// phpcs:ignore
					'label'       => sprintf( esc_html__( 'Specific %s', 'avalon-addons' ), $label ),
					'type'        => 'avalon-autocomplete',
					'placeholder' => esc_html__( 'Click here and start typing...', 'avalon-addons' ),
					'default'     => '',
					'multiple'    => true,
					'source'      => $key,
					'sortable'    => true,
					'label_block' => true,
					'conditions'  => [
						'terms' => [
							[
								'name'     => 'include_on',
								'operator' => 'contains',
								'value'    => $key,
							],
						],
					],
				]
			);
		}

		$document->add_control(
			'exclude_on',
			[
				'label'       => esc_html__( 'Exclude From', 'avalon-addons' ),
				'description' => esc_html__( 'Choose where should be excluded.', 'avalon-addons' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => $args_types,
				'default'     => [],
				'separator'   => 'before',
			]
		);

		foreach ( $args_types as $key => $label ) {
			if ( in_array( $key, $get_types_extra, true ) ) {
				continue;
			}

			$document->add_control(
				'exclude_' . $key . '_ids',
				[
					// phpcs:ignore
					'label'       => sprintf( esc_html__( 'Specific %s', 'avalon-addons' ), $label ),
					'type'        => 'avalon-autocomplete',
					'placeholder' => esc_html__( 'Click here and start typing...', 'avalon-addons' ),
					'default'     => '',
					'multiple'    => true,
					'source'      => $key,
					'sortable'    => true,
					'label_block' => true,
					'conditions'  => [
						'terms' => [
							[
								'name'     => 'exclude_on',
								'operator' => 'contains',
								'value'    => $key,
							],
						],
					],
				]
			);
		}

		$document->end_controls_section();
	}

	/**
	 * Save post meta when save page settings in Elementor
	 *
	 * @param object $document Document object.
	 * @param object $data Elementor data.
	 *
	 * @return void
	 */
	public function save_post_meta( $document, $data ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( Post_Type::POST_TYPE !== $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), Post_Type::TAXONOMY_TYPE );
		$terms = ! is_wp_error( $terms ) && $terms ? wp_list_pluck( $terms, 'slug' ) : '';

		if ( ! $terms ) {
			return;
		}

		if ( ! isset( $data['settings'] ) ) {
			return;
		}

		$settings   = $data['settings'];
		$args_types = $this->get_types();

		if ( in_array( 'footer', $terms, true ) || in_array( 'header', $terms, true ) ) {
			// Save include settings.
			$include_on = 0;
			if ( ! empty( $settings['include_on'] ) ) {
				$raw_slugs = $settings['include_on'];

				if ( is_array( $raw_slugs ) ) {
					$raw_slugs = implode( ',', $raw_slugs );
				}

				$raw_slugs  = trim( $raw_slugs, ',' );
				$include_on = ',' . $raw_slugs . ',';
			}
			update_post_meta( $document->get_main_id(), 'include_on', $include_on );

			foreach ( $args_types as $key => $value ) {
				$include_ids = 0;
				if ( ! empty( $settings[ 'include_' . $key . '_ids' ] ) ) {
					$raw_ids = $settings[ 'include_' . $key . '_ids' ];

					if ( is_array( $raw_ids ) ) {
						$raw_ids = array_map( 'intval', $raw_ids );
						$raw_ids = implode( ',', $raw_ids );
					}

					$raw_ids     = preg_replace( '/[^0-9,]/', '', $raw_ids );
					$raw_ids     = trim( $raw_ids, ',' );
					$include_ids = ',' . $raw_ids . ',';
				}
				update_post_meta( $document->get_main_id(), $key . '_include', $include_ids );
			}

			// Save exclude settings.
			$exclude_on = 0;
			if ( ! empty( $settings['exclude_on'] ) ) {
				$raw_slugs = $settings['exclude_on'];

				if ( is_array( $raw_slugs ) ) {
					$raw_slugs = implode( ',', $raw_slugs );
				}

				$raw_ids    = trim( $raw_slugs, ',' );
				$exclude_on = ',' . $raw_slugs . ',';
			}
			update_post_meta( $document->get_main_id(), 'exclude_on', $exclude_on );

			foreach ( $args_types as $key => $value ) {
				$exclude_ids = 0;
				if ( ! empty( $settings[ 'exclude_' . $key . '_ids' ] ) ) {
					$raw_ids = $settings[ 'exclude_' . $key . '_ids' ];

					if ( is_array( $raw_ids ) ) {
						$raw_ids = array_map( 'intval', $raw_ids );
						$raw_ids = implode( ',', $raw_ids );
					}

					$raw_ids     = preg_replace( '/[^0-9,]/', '', $raw_ids );
					$raw_ids     = trim( $raw_ids, ',' );
					$exclude_ids = ',' . $raw_ids . ',';
				}
				update_post_meta( $document->get_main_id(), $key . '_exclude', $exclude_ids );
			}
		}
	}

	/**
	 * Get types.
	 *
	 * @return array
	 */
	public static function get_types() {
		$args = [
			'category'       => esc_html__( 'Categories', 'avalon-addons' ),
			'tag'            => esc_html__( 'Tags', 'avalon-addons' ),
			'page'           => esc_html__( 'Pages', 'avalon-addons' ),
			'not_found_page' => esc_html__( '404 Page', 'avalon-addons' ),
		];

		if ( post_type_exists( 'portfolio' ) ) {
			$args = array_merge(
				$args,
				[
					'portfolio_service' => esc_html__( 'Portfolio Services', 'avalon-addons' ),
				]
			);
		}

		return $args;
	}

	/**
	 * Get types extra.
	 *
	 * @return array
	 */
	public static function get_types_extra() {
		$args = [
			'not_found_page',
		];

		return $args;
	}
}
