<?php
/**
 * Header-Footer page template.
 *
 * @package AvalonAddons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

\Elementor\Plugin::$instance->frontend->add_body_class( 'elementor-template-full-width' );

get_header();
/**
 * Before Header-Footer page template content.
 *
 * Fires before the content of Elementor Header-Footer page template.
 *
 * @since 2.0.0
 */
// @codingStandardsIgnoreLine
do_action( 'elementor/page_templates/header-footer/before_content' );


$classes = apply_filters( 'avalon_builder_container_classes', [] );

if ( is_array( $classes ) ) {
	$classes = implode( ' ', $classes );
}
?>
<div class="<?php echo esc_attr( $classes ); ?>">
	<?php echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Elementor renders and escapes its own markup; wp_kses_post() here would strip script/iframe tags. ?>
</div>
<?php
/**
 * After Header-Footer page template content.
 *
 * Fires after the content of Elementor Header-Footer page template.
 *
 * @since 2.0.0
 */
// @codingStandardsIgnoreLine
do_action( 'elementor/page_templates/header-footer/after_content' );

get_footer();
