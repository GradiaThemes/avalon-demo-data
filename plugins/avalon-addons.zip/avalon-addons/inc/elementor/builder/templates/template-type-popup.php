<?php
/**
 * The Template for displaying all template type
 *
 * @package AvalonAddons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div id="avalon-builder-template-modal" class="avalon-builder-template-modal">
	<div class="modal__backdrop"></div>
	<div class="modal__content">
		<span class="avalon-svg-icon avalon-svg-icon--close modal__button-close"><svg width="24" height="24" aria-hidden="true" role="img" focusable="false" viewBox="0 0 32 32"><path d="M28.336 5.936l-2.272-2.272-10.064 10.080-10.064-10.080-2.272 2.272 10.080 10.064-10.080 10.064 2.272 2.272 10.064-10.080 10.064 10.080 2.272-2.272-10.080-10.064z"></path></svg></span>
		<form class="modal-content__form" action="<?php echo esc_url( admin_url( 'post.php' ) ); ?>">
			<input type="hidden" class="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'avalon_buider_new_template' ) ); ?>">
			<div class="modal-content-form__title"><?php echo esc_html__( 'Choose Template Type', 'avalon-addons' ); ?></div>
			<div  class="elementor-form-field">
				<label for="avalon-builder-template-modal-type" class="elementor-form-field__label"><?php echo esc_html__( 'Select the type of template you want to work on', 'avalon-addons' ); ?></label>
				<select id="avalon-builder-template-modal-type" class="elementor-form-field__select" required>
					<option value="footer"><?php echo esc_html__( 'Footer', 'avalon-addons' ); ?></option>
					<option value="header"><?php echo esc_html__( 'Header', 'avalon-addons' ); ?></option>
				</select>
			</div>
			<div class="elementor-form-field">
				<label for="avalon-builder-template-modal__post-title" class="elementor-form-field__label">
					<?php echo esc_html__( 'Name your template', 'avalon-addons' ); ?>
				</label>
				<input type="text" placeholder="<?php echo esc_attr__( 'Enter template name (optional)', 'avalon-addons' ); ?>" required id="avalon-builder-template-modal__post-title" class="elementor-form-field__text">
			</div>
			<div class="elementor-form-field">
				<input class="elementor-form-field__checkbox" type="checkbox" name="woolentor-template-enable" id="avalon-builder-template-modal__post-enable">
				<label for="avalon-builder-template-modal__post-enable" class="elementor-form-field__label">
					<?php echo esc_html__( 'Enable Builder', 'avalon-addons' ); ?>
				</label>
			</div>
			<button id="avalon-builder-template-modal__submit" class="elementor-button e-primary"><span><?php echo esc_html__( 'Create Template', 'avalon-addons' ); ?></span></button>
			<p class="modal-content-form-message"></p>
		</form>
	</div>
</div>
