<?php
/**
 * Elementor Builder Footer
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Footer {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Template id
	 *
	 * @var $template_id
	 */
	private static $template_id = 0;

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'avalon_footer', [ $this, 'content_builder' ], 5 );
		add_filter( 'avalon_footer_default', [ $this, 'template_default' ] );
	}

	/**
	 * Enqueue scripts
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! apply_filters( 'avalon_footer_builder', true ) ) {
			return;
		}

		self::$template_id = $this->get_template_id();

		if ( empty( self::$template_id ) || ! is_numeric( self::$template_id ) ) {
			return;
		}

		$template_id = intval( self::$template_id );
		if ( $template_id <= 0 ) {
			return;
		}

		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			$css_file = new \Elementor\Core\Files\CSS\Post( $template_id );
			if ( $css_file ) {
				$css_file->enqueue();
			}
		}
	}

	/**
	 * Content builder
	 *
	 * @return void
	 */
	public function content_builder() {
		if ( ! apply_filters( 'avalon_footer_builder', true ) ) {
			return;
		}

		self::$template_id = $this->get_template_id();

		if ( empty( self::$template_id ) || ! is_numeric( self::$template_id ) ) {
			return;
		}

		$template_id = intval( self::$template_id );
		if ( $template_id <= 0 ) {
			return;
		}

		$document = \Elementor\Plugin::instance()->documents->get( $template_id );
		if ( ! empty( $document ) ) {
			echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $template_id ); // phpcs:ignore
		}
	}

	/**
	 * Get Template id
	 *
	 * @return int
	 */
	public function get_template_id() {
		if ( ! empty( self::$template_id ) ) {
			return self::$template_id;
		}

		$template_id = 0;

		if ( is_page() || is_archive() || is_home() || is_404() ) {
			$template_id = Helper::get_query( 'footer' );
		}

		if ( empty( $template_id ) ) {
			$template_id = Helper::get_query( 'footer', true );
		}

		self::$template_id = $template_id;

		return self::$template_id;
	}

	/**
	 * Template default
	 *
	 * @return bool
	 */
	public function template_default() {
		self::$template_id = $this->get_template_id();
		if ( empty( self::$template_id ) ) {
			return true;
		}

		return false;
	}
}
