<?php
/**
 * Elementor Builder Helper init
 *
 * @package AvalonAddons
 */

namespace AvalonAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use AvalonAddons\Admin\Portfolio;
/**
 * Helper
 */
class Helper {

	/**
	 * Is Elementor
	 *
	 * @return bool
	 */
	public static function is_elementor() {
		if ( class_exists( '\Elementor\Plugin' ) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Get template settings
	 *
	 * @param int $template_id Template ID.
	 *
	 * @return array
	 */
	public static function get_template_settings( $template_id ) {
		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );
		$page_settings_model   = $page_settings_manager->get_model( $template_id );

		return $page_settings_model->get_settings();
	}

	/**
	 * Get redirect template
	 *
	 * @param string $template Template.
	 * @param string $template_part Template part.
	 * @param int    $template_id Template ID.
	 *
	 * @return string
	 */
	public static function get_redirect_template( $template, $template_part, $template_id ) {
		if ( ! empty( $template_id ) ) {
			$document        = \Elementor\Plugin::$instance->documents->get_doc_for_frontend( $template_id );
			$template_module = \Elementor\Modules\PageTemplates\Module::instance();

			if ( $document && $document::get_property( 'support_wp_page_templates' ) ) {
				$page_template = $document->get_meta( '_wp_page_template' );
				$page_template = ( in_array( $page_template, [ 'elementor_header_footer', 'elementor_canvas' ], true ) ? $page_template : 'elementor_header_footer' );

				$template_path = $template_module->get_template_path( $page_template );

				if ( 'elementor_theme' !== $page_template && ! $template_path && $document->is_built_with_elementor() ) {
					$kit_default_template = \Elementor\Plugin::$instance->kits_manager->get_current_settings( 'default_page_template' );
					$template_path        = $template_module->get_template_path( $kit_default_template );
				}

				if ( $template_path ) {
					$template = $template_path;
				}
			}

			$template_module->set_print_callback(
				function () use ( $template_id, $template_part ) {
					include_once self::get_template_part( $template_part, $template_id );
				}
			);
		} else {
			$template = self::get_template_part( $template_part, $template_id );
		}
		return $template;
	}

	/**
	 * Get template part
	 *
	 * @param string $slug Slug.
	 * @param int    $template_id Template ID.
	 *
	 * @return string
	 */
	public static function get_template_part( $slug, $template_id ) {
		$template = '';
		if ( 'product' === $slug ) {
			if ( empty( $template_id ) ) {
				$template = plugin_dir_path( __FILE__ ) . 'templates/single-template-builder-empty.php';
			} else {
				$template = plugin_dir_path( __FILE__ ) . 'templates/single-template-builder.php';
			}
		}

		if ( in_array( $slug, [ 'archive', 'cart_page', 'checkout_page', '404_page' ], true ) ) {
			$template = plugin_dir_path( __FILE__ ) . 'templates/archive-template-builder.php';
		}

		return $template;
	}

	/**
	 * Check elementor css print method
	 *
	 * @return boolean
	 */
	public static function check_elementor_css_print_method() {
		if ( get_option( 'elementor_css_print_method' ) === 'internal' ) {
			return true;
		}

		return false;
	}

	/**
	 * Get Template id
	 *
	 * @param string $builder_type Builder type.
	 * @param bool   $get_all Get all.
	 * @param bool   $_get_all Get all.
	 *
	 * @return int
	 */
	public static function get_query( $builder_type = 'footer', $get_all = false, $_get_all = false ) {
		$current_id = get_queried_object_id();

		$types = [];
		if ( is_page() || is_home() ) {
			$types[] = 'page';
		}

		if ( is_category() ) {
			$types[] = 'category';
		}

		if ( is_tag() ) {
			$types[] = 'tag';
		}

		if ( is_404() ) {
			$types[] = 'not_found_page';
		}

		if ( Portfolio::is_portfolio_archive() ) {
			if ( empty( $current_id ) ) {
				$types[]    = 'page';
				$current_id = Portfolio::get_portfolio_page_id();
			}
		}

		if ( term_exists( $current_id, Portfolio::TAXONOMY_SERVICE ) ) {
			$types[] = 'portfolio_service';
		}

		$meta_query = [ 'relation' => 'AND' ];

		if ( $get_all ) {
			$meta_query[] = [
				'key'     => 'include_on',
				'value'   => '0',
				'compare' => '=',
			];

			foreach ( $types as $type ) {
				$exclude_key  = "{$type}_exclude";
				$meta_query[] = [
					'key'     => $exclude_key,
					'value'   => ',' . $current_id . ',',
					'compare' => 'NOT LIKE',
				];
				$meta_query[] = [
					'key'     => 'exclude_on',
					'value'   => ',' . $type . ',',
					'compare' => 'NOT LIKE',
				];
			}
		} else {
			if ( empty( $types ) ) {
				return 0;
			}

			foreach ( $types as $type ) {
				$include_key = "{$type}_include";
				$exclude_key = "{$type}_exclude";

				$meta_query[] = [
					'relation' => 'AND',
					[
						'key'     => $exclude_key,
						'value'   => ',' . $current_id . ',',
						'compare' => 'NOT LIKE',
					],
					[
						'key'     => 'exclude_on',
						'value'   => ',' . $type . ',',
						'compare' => 'NOT LIKE',
					],
					[
						'key'     => 'include_on',
						'value'   => ',' . $type . ',',
						'compare' => 'LIKE',
					],
				];

				if ( $_get_all ) {
					$meta_query[] = [
						'key'     => $include_key,
						'value'   => '0',
						'compare' => '=',
					];
				} else {
					$meta_query[] = [
						'key'     => $include_key,
						'value'   => ',' . $current_id . ',',
						'compare' => 'LIKE',
					];
				}
			}
		}

		$query_args = [
			'post_type'      => Post_Type::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'orderby'        => [
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			],
			'no_found_rows'  => true,
			// phpcs:ignore
			'tax_query'      => [
				'relation' => 'AND',
				[
					'taxonomy' => Post_Type::TAXONOMY_TYPE,
					'field'    => 'slug',
					'terms'    => [ $builder_type ],
				],
				[
					'taxonomy' => Post_Type::TAXONOMY_TYPE,
					'field'    => 'slug',
					'terms'    => [ 'enable' ],
				],
			],
			// phpcs:ignore
			'meta_query'     => $meta_query,
		];

		$query       = new \WP_Query( $query_args );
		$template_id = $query->posts ? $query->posts[0] : 0;

		return $template_id;
	}
}
