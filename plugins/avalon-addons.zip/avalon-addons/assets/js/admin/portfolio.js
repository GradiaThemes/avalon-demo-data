let frameImage;
let frameVideo;
let frameGallery;

function initImagePicker() {
	document.addEventListener( 'click', function ( e ) {
		const button = e.target.closest(
			'.avalon-service-thumbnail-button, .avalon-type-thumbnail-button'
		);
		if ( ! button ) {
			return;
		}

		e.preventDefault();
		const container = button.closest(
			'.avalon-service-thumbnail, .avalon-type-thumbnail'
		);
		if ( ! container ) {
			return;
		}

		if ( frameImage ) {
			frameImage.open();
			return;
		}

		frameImage = wp.media( {
			title: 'Select or Upload Image',
			button: { text: 'Use this image' },
			multiple: false,
		} );

		frameImage.on( 'select', function () {
			const attachment = frameImage
				.state()
				.get( 'selection' )
				.first()
				.toJSON();
			const idInput = container.querySelector(
				'.avalon-service-thumbnail-id, .avalon-type-thumbnail-id'
			);
			const preview = container.querySelector(
				'.avalon-service-thumbnail-preview, .avalon-type-thumbnail-preview'
			);
			const removeBtn = container.querySelector(
				'.avalon-service-thumbnail-remove, .avalon-type-thumbnail-remove'
			);

			if ( idInput ) {
				idInput.value = attachment.id;
				idInput.dispatchEvent( new Event( 'change' ) );
			}

			if ( preview ) {
				preview.src =
					attachment.sizes && attachment.sizes.thumbnail
						? attachment.sizes.thumbnail.url
						: attachment.url;
				preview.style.display = 'block';
			}

			if ( removeBtn ) {
				removeBtn.style.display = '';
			}
		} );

		frameImage.open();
	} );
}

function initVideoPicker() {
	document.addEventListener( 'click', function ( e ) {
		const button = e.target.closest( '.avalon-type-video-button' );
		if ( ! button ) {
			return;
		}

		e.preventDefault();
		const container = button.closest( '.avalon-type-video' );
		if ( ! container ) {
			return;
		}

		if ( frameVideo ) {
			frameVideo.open();
			return;
		}

		frameVideo = wp.media( {
			title: 'Select or Upload Video',
			library: { type: 'video' },
			button: { text: 'Use this video' },
			multiple: false,
		} );

		frameVideo.on( 'select', function () {
			const attachment = frameVideo
				.state()
				.get( 'selection' )
				.first()
				.toJSON();
			const idInput = container.querySelector( '.avalon-type-video-id' );
			const preview = container.querySelector(
				'.avalon-type-video-preview'
			);
			const removeBtn = container.querySelector(
				'.avalon-type-video-remove'
			);

			if ( idInput ) {
				idInput.value = attachment.id;
				idInput.dispatchEvent( new Event( 'change' ) );
			}

			if ( preview ) {
				const title =
					attachment.title || attachment.filename || attachment.url;
				preview.textContent = title;
				preview.style.display = 'block';
			}

			if ( removeBtn ) {
				removeBtn.style.display = 'block';
			}
		} );

		frameVideo.open();
	} );
}

function updateGalleryInput( container ) {
	const grid = container.querySelector( '.avalon-portfolio-gallery-grid' );
	const input = container.querySelector( '.avalon-portfolio-gallery-ids' );
	if ( ! grid || ! input ) {
		return;
	}

	const items = grid.querySelectorAll( '.avalon-portfolio-gallery-item' );
	const ids = [];
	items.forEach( function ( item ) {
		const id = item.getAttribute( 'data-id' );
		if ( id ) {
			ids.push( id );
		}
	} );
	input.value = ids.join( ',' );
}

function initGalleryPicker() {
	document.addEventListener( 'click', function ( e ) {
		const button = e.target.closest( '.avalon-portfolio-gallery-add' );
		if ( ! button ) {
			return;
		}

		e.preventDefault();
		const container = button.closest( '.avalon-portfolio-gallery' );
		if ( ! container ) {
			return;
		}

		if ( frameGallery ) {
			frameGallery.open();
			return;
		}

		frameGallery = wp.media( {
			title: 'Select Images',
			button: { text: 'Add to gallery' },
			multiple: true,
		} );

		frameGallery.on( 'select', function () {
			const selection = frameGallery.state().get( 'selection' );
			const grid = container.querySelector(
				'.avalon-portfolio-gallery-grid'
			);

			selection.each( function ( attachment ) {
				const att = attachment.toJSON();
				const src =
					att.sizes && att.sizes.thumbnail
						? att.sizes.thumbnail.url
						: att.url;

				const item = document.createElement( 'div' );
				item.className = 'avalon-portfolio-gallery-item';
				item.setAttribute( 'data-id', att.id );
				item.innerHTML =
					'<img src="' +
					src +
					'" alt="" />' +
					'<button type="button" class="avalon-portfolio-gallery-item-remove" aria-label="Remove image">&times;</button>';
				grid.appendChild( item );
			} );

			updateGalleryInput( container );
		} );

		frameGallery.open();
	} );
}

function initGalleryRemove() {
	document.addEventListener( 'click', function ( e ) {
		const removeBtn = e.target.closest(
			'.avalon-portfolio-gallery-item-remove'
		);
		if ( ! removeBtn ) {
			return;
		}

		e.preventDefault();
		const item = removeBtn.closest( '.avalon-portfolio-gallery-item' );
		const container = removeBtn.closest( '.avalon-portfolio-gallery' );
		if ( item ) {
			item.remove();
		}
		if ( container ) {
			updateGalleryInput( container );
		}
	} );
}

function initGallerySortable() {
	if ( typeof jQuery === 'undefined' ) {
		return;
	}

	const $ = jQuery;
	$( document ).on( 'mouseenter', '.avalon-portfolio-gallery-grid', function () {
		const $grid = $( this );
		if ( $grid.data( 'ui-sortable' ) ) {
			return;
		}
		$grid.sortable( {
			items: '.avalon-portfolio-gallery-item',
			cursor: 'grab',
			opacity: 0.7,
			stop: function () {
				const container = $grid.closest( '.avalon-portfolio-gallery' )[ 0 ];
				if ( container ) {
					updateGalleryInput( container );
				}
			},
		} );
	} );
}

function initRemoveHandlers() {
	document.addEventListener( 'click', function ( e ) {
		const removeBtn = e.target.closest(
			'.avalon-service-thumbnail-remove, .avalon-type-thumbnail-remove'
		);
		if ( removeBtn ) {
			e.preventDefault();
			const container = removeBtn.closest(
				'.avalon-service-thumbnail, .avalon-type-thumbnail'
			);
			if ( ! container ) {
				return;
			}

			const idInput = container.querySelector(
				'.avalon-service-thumbnail-id, .avalon-type-thumbnail-id'
			);
			const preview = container.querySelector(
				'.avalon-service-thumbnail-preview, .avalon-type-thumbnail-preview'
			);

			if ( idInput ) {
				idInput.value = '';
			}
			if ( preview ) {
				preview.style.display = 'none';
				preview.src = '';
			}
			removeBtn.style.display = 'none';
		}

		const videoRemoveBtn = e.target.closest( '.avalon-type-video-remove' );
		if ( videoRemoveBtn ) {
			e.preventDefault();
			const container = videoRemoveBtn.closest( '.avalon-type-video' );
			if ( ! container ) {
				return;
			}

			const idInput = container.querySelector( '.avalon-type-video-id' );
			const preview = container.querySelector(
				'.avalon-type-video-preview'
			);

			if ( idInput ) {
				idInput.value = '';
			}
			if ( preview ) {
				preview.style.display = 'none';
				preview.textContent = '';
			}
			videoRemoveBtn.style.display = 'none';
		}
	} );
}

function initSourceToggle() {
	document.addEventListener( 'change', function ( e ) {
		const select = e.target.closest( '.avalon-type-video-source' );
		if ( ! select ) {
			return;
		}

		const container = select.closest( '.avalon-type-video' );
		if ( ! container ) {
			return;
		}

		const youtubeEl = container.querySelector(
			'.avalon-type-video-youtube'
		);
		const selfhostEl = container.querySelector(
			'.avalon-type-video-selfhost'
		);

		if ( youtubeEl ) {
			youtubeEl.style.display = 'none';
		}
		if ( selfhostEl ) {
			selfhostEl.style.display = 'none';
		}

		if ( select.value === 'youtube' && youtubeEl ) {
			youtubeEl.style.display = 'block';
		} else if ( select.value === 'selfhost' && selfhostEl ) {
			selfhostEl.style.display = 'block';
		}
	} );

	document
		.querySelectorAll( '.avalon-type-video-source' )
		.forEach( function ( select ) {
			select.dispatchEvent( new Event( 'change' ) );
		} );
}

document.addEventListener( 'DOMContentLoaded', function () {
	initImagePicker();
	initVideoPicker();
	initGalleryPicker();
	initGalleryRemove();
	initGallerySortable();
	initRemoveHandlers();
	initSourceToggle();
} );
