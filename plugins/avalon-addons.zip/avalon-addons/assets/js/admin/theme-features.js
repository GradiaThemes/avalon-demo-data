(function ( $ ) {
	'use strict';

	const config = window.avalonThemeFeatures;

	if ( ! config || ! config.ajaxUrl ) {
		return;
	}

	const grid = $( '.avalon-features__grid' );

	if ( ! grid.length ) {
		return;
	}

	function setBusy( busy ) {
		grid.find( '.avalon-toggle__input' ).prop( 'disabled', busy );
		$( '.avalon-bulk-toggle' ).prop( 'disabled', busy );
		grid.toggleClass( 'is-saving', busy );
	}

	function updateCard( card, enabled ) {
		const badge = card.find( '.avalon-feature-card__badge' );

		card.toggleClass( 'is-enabled', enabled );
		badge
			.removeClass( 'avalon-feature-card__badge--active avalon-feature-card__badge--inactive' )
			.addClass( 'avalon-feature-card__badge--' + ( enabled ? 'active' : 'inactive' ) )
			.text( enabled ? config.activeText : config.inactiveText );
	}

	function saveChanges( changes ) {
		return $.post(
			config.ajaxUrl,
			{
				action: 'avalon_addons_save_modules',
				nonce: config.nonce,
				changes: changes,
			},
			null,
			'json'
		);
	}

	grid.on( 'change', '.avalon-toggle__input', function () {
		const input = $( this );
		const card = input.closest( '.avalon-feature-card' );
		const moduleId = input.data( 'module' );
		const enabled = input.prop( 'checked' );

		setBusy( true );

		saveChanges( { [ moduleId ]: enabled } )
			.done( function ( response ) {
				if ( response.success ) {
					updateCard( card, enabled );
				} else {
					input.prop( 'checked', ! enabled );
				}
			} )
			.fail( function () {
				input.prop( 'checked', ! enabled );
			} )
			.always( function () {
				setBusy( false );
			} );
	} );

	$( '.avalon-bulk-toggle' ).on( 'click', function () {
		const enabled = 'activate' === $( this ).data( 'action' );
		const changes = {};

		grid.find( '.avalon-toggle__input:not(:disabled)' ).each( function () {
			const input = $( this );
			const checked = input.prop( 'checked' );

			if ( checked !== enabled ) {
				changes[ input.data( 'module' ) ] = enabled;
			}
		} );

		if ( ! Object.keys( changes ).length ) {
			return;
		}

		setBusy( true );

		saveChanges( changes )
			.done( function ( response ) {
				if ( ! response.success ) {
					return;
				}

				$.each( changes, function ( moduleId, value ) {
					const input = grid.find( '.avalon-toggle__input[data-module="' + moduleId + '"]' );

					input.prop( 'checked', value );
					updateCard( input.closest( '.avalon-feature-card' ), value );
				} );
			} )
			.always( function () {
				setBusy( false );
			} );
	} );
})( jQuery );
