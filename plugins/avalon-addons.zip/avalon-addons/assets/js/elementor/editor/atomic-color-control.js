/**
 * Atomic Color Control
 *
 * Registers the 'color' atomic control type in Elementor's V2 editing
 * panel. The PHP-side settings (Orvian Theme Settings: Dark Mode text,
 * heading, link colors) bind color props via the custom
 * `Color_Control` (type 'color'), but Elementor's editor only renders
 * control types listed in its `controlsRegistry`. Without this
 * registration the editor throws `ControlTypeNotFoundError` and the
 * color pickers never appear.
 *
 * @package AvalonAddons
 */
( function () {
	'use strict';

	/**
	 * Register the 'color' atomic control type once the Elementor V2
	 * packages are available on the editor.
	 *
	 * @return {boolean} True once registered (or already registered).
	 */
	function registerColorControl() {
		const editingPanel    = window.elementorV2 && window.elementorV2.editorEditingPanel;
		const editorControls  = window.elementorV2 && window.elementorV2.editorControls;
		const editorProps     = window.elementorV2 && window.elementorV2.editorProps;
		const registry        = editingPanel && editingPanel.controlsRegistry;
		const ColorControl    = editorControls && editorControls.ColorControl;

		if ( ! registry || ! ColorControl ) {
			return false;
		}

		// Already registered (e.g. by another integration) - nothing to do.
		if ( registry.get( 'color' ) ) {
			return true;
		}

		registry.register(
			'color',
			ColorControl,
			'two-columns',
			editorProps && editorProps.colorPropTypeUtil
		);

		return true;
	}

	// The V2 packages load asynchronously; poll until they are ready.
	if ( ! registerColorControl() ) {
		var interval = setInterval( function () {
			if ( registerColorControl() ) {
				clearInterval( interval );
			}
		}, 250 );

		// Give up after 15s so the editor is never left busy forever.
		setTimeout( function () {
			clearInterval( interval );
		}, 15000 );
	}
}() );
