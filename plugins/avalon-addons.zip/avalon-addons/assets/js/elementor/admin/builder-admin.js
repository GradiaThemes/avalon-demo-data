function getUrlParameter( param ) {
	const sPageURL = decodeURIComponent(
		window.location.search.substring( 1 )
	);
	const sURLVariables = sPageURL.split( '&' );

	for ( let i = 0; i < sURLVariables.length; i++ ) {
		const sParameterName = sURLVariables[ i ].split( '=' );

		if ( sParameterName[ 0 ] === param ) {
			return sParameterName[ 1 ] === undefined
				? true
				: sParameterName[ 1 ];
		}
	}
	return undefined;
}

function initBuilderToggle() {
	document.addEventListener( 'change', function ( e ) {
		const checkbox = e.target.closest( '.avalon-builder__enabled' );
		if ( ! checkbox ) {
			return;
		}

		e.preventDefault();
		const newState = e.target.checked ? 1 : 0;
		const builderId = checkbox.dataset.builderId;
		const nonce = checkbox.dataset.nonce;

		const table = checkbox.closest( 'table' );
		if ( table ) {
			table.classList.add( 'avalon-loading' );
		}

		fetch( ajaxurl, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams( {
				action: 'avalon_save_builder_enable',
				nonce,
				post_ID: builderId,
				enabled: newState,
			} ).toString(),
		} )
			.then( function () {
				if ( table ) {
					table.classList.remove( 'avalon-loading' );
				}
			} )
			.catch( function () {
				if ( table ) {
					table.classList.remove( 'avalon-loading' );
				}
			} );
	} );
}

function initModal() {
	document.addEventListener( 'click', function ( e ) {
		const addButton = e.target.closest( '.page-title-action' );
		if (
			addButton &&
			document.body.classList.contains( 'post-type-avalon_builder' )
		) {
			e.preventDefault();
			const modal = document.querySelector(
				'#avalon-builder-template-modal'
			);
			if ( modal ) {
				modal.style.display = 'fadeIn' in modal.style ? '' : 'block';
				modal.classList.add( 'modal--open' );
			}
		}

		const closeButton = e.target.closest(
			'.modal__button-close, .modal__backdrop'
		);
		if ( closeButton ) {
			e.preventDefault();
			const modal = document.querySelector(
				'#avalon-builder-template-modal'
			);
			if ( modal ) {
				modal.style.display = 'none';
				modal.classList.remove( 'modal--open' );
			}
		}

		const submitButton = e.target.closest(
			'#avalon-builder-template-modal__submit'
		);
		if ( submitButton ) {
			e.preventDefault();
			const button = submitButton;
			const form = button.closest( '.modal-content__form' );
			if ( ! form ) {
				return;
			}

			const nonce = form.querySelector( '._wpnonce' )?.value;
			const postTitle = form.querySelector(
				'#avalon-builder-template-modal__post-title'
			)?.value;
			const templateType = form.querySelector(
				'#avalon-builder-template-modal-type'
			)?.value;
			const enableBuilder = form.querySelector(
				'#avalon-builder-template-modal__post-enable'
			)?.checked
				? 'yes'
				: 'no';

			const messageEl = form.querySelector(
				'.modal-content-form-message'
			);
			if ( messageEl ) {
				messageEl.innerHTML = '';
			}

			if ( ! postTitle ) {
				const titleInput = form.querySelector(
					'#avalon-builder-template-modal__post-title'
				);
				if ( titleInput ) {
					titleInput.focus();
				}
				return false;
			}

			button.classList.add( 'avalon-loading' );
			button.disabled = true;

			fetch( ajaxurl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams( {
					action: 'avalon_builder_template_type',
					nonce,
					post_title: postTitle,
					template_type: templateType,
					enable_builder: enableBuilder,
				} ).toString(),
			} )
				.then( function ( response ) {
					return response.json();
				} )
				.then( function ( data ) {
					const responseData = data.data;

					if ( responseData && responseData.id ) {
						const action =
							form.getAttribute( 'action' ) +
							'?post=' +
							responseData.id +
							'&action=elementor';
						window.location.replace( action );
					} else if ( responseData && responseData.message ) {
						if ( messageEl ) {
							messageEl.innerHTML = responseData.message;
						}
						button.classList.remove( 'avalon-loading' );
						button.disabled = false;
					} else {
						button.classList.remove( 'avalon-loading' );
						button.disabled = false;
					}
				} )
				.catch( function () {
					button.classList.remove( 'avalon-loading' );
					button.disabled = false;
				} );
		}
	} );
}

function initSortable() {
	const tbody = document.querySelector( 'tbody#the-list' );
	if ( ! tbody ) {
		return;
	}

	let draggedEl = null;
	let startY = 0;
	let startTop = 0;

	tbody.addEventListener( 'mousedown', function ( e ) {
		const row = e.target.closest( 'tr.type-avalon_builder' );
		if ( ! row ) {
			return;
		}
		draggedEl = row;
		startY = e.clientY;
		startTop = row.offsetTop;
	} );

	document.addEventListener( 'mousemove', function ( e ) {
		if ( ! draggedEl ) {
			return;
		}

		const rows = Array.from(
			tbody.querySelectorAll( 'tr.type-avalon_builder' )
		);
		const rect = tbody.getBoundingClientRect();
		const mouseY = e.clientY - rect.top;

		let targetRow = null;
		for ( let i = 0; i < rows.length; i++ ) {
			const row = rows[ i ];
			const rowMiddle = row.offsetTop + row.offsetHeight / 2;
			if ( mouseY < rowMiddle ) {
				targetRow = row;
				break;
			}
		}

		if ( targetRow && targetRow !== draggedEl ) {
			tbody.insertBefore( draggedEl, targetRow );
		}
	} );

	document.addEventListener( 'mouseup', function ( e ) {
		if ( ! draggedEl ) {
			return;
		}

		const order = [];
		tbody
			.querySelectorAll( 'tr.type-avalon_builder' )
			.forEach( function ( row ) {
				order.push( row.dataset.id );
			} );

		if ( order.length > 0 ) {
			tbody.classList.add( 'loading' );

			let paged = getUrlParameter( 'paged' );
			if ( typeof paged === 'undefined' ) {
				paged = 1;
			}

			fetch( ajaxurl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams( {
					action: 'avalon_sortable_builder',
					nonce:
						( typeof avalonBuilderAdmin !== 'undefined' &&
							avalonBuilderAdmin.sortableNonce ) ||
						'',
					order: 'post[]=' + order.join( '&post[]=' ),
					paged,
				} ).toString(),
			} )
				.then( function () {
					tbody.classList.remove( 'loading' );
				} )
				.catch( function () {
					tbody.classList.remove( 'loading' );
				} );
		}

		draggedEl = null;
	} );
}

document.addEventListener( 'DOMContentLoaded', function () {
	initBuilderToggle();
	initModal();
	initSortable();
} );
