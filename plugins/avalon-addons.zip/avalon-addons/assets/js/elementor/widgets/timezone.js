class AvalonTimezoneHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				container: '.avalon-timezone',
				offset: '.avalon-timezone__offset',
				time: '.avalon-timezone__time',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			container: this.$element[0].querySelector( selectors.container ),
			offsetEl: this.$element[0].querySelector( selectors.offset ),
			timeEl: this.$element[0].querySelector( selectors.time ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._isAuto = this.elements.container.getAttribute( 'data-auto' ) === '1';
		this._tz = this.elements.container.getAttribute( 'data-tz' ) || null;
		this._interval = null;

		this.updateClock();
		this._interval = setInterval( () => this.updateClock(), 1000 );
	}

	onDestroy() {
		if ( this._interval ) {
			clearInterval( this._interval );
		}

		super.onDestroy();
	}

	detectTimezone() {
		try {
			return Intl.DateTimeFormat().resolvedOptions().timeZone;
		} catch ( e ) {
			return null;
		}
	}

	getOffsetString( date, tz ) {
		if ( ! tz ) {
			return 'GMT+0';
		}

		const options = { timeZone: tz, timeZoneName: 'shortOffset' };
		const parts = new Intl.DateTimeFormat( 'en-US', options ).formatToParts( date );

		for ( let i = 0; i < parts.length; i++ ) {
			if ( parts[ i ].type === 'timeZoneName' ) {
				return parts[ i ].value;
			}
		}

		return 'GMT+0';
	}

	getTimeString( date, tz ) {
		const options = { hour: '2-digit', minute: '2-digit', hour12: false };

		if ( tz ) {
			options.timeZone = tz;
		}

		return new Intl.DateTimeFormat( 'en-GB', options ).format( date );
	}

	updateClock() {
		if ( ! this.elements.offsetEl || ! this.elements.timeEl ) {
			return;
		}

		const now = new Date();
		const tz = this._isAuto ? this.detectTimezone() : this._tz;

		if ( ! tz ) {
			return;
		}

		this.elements.offsetEl.textContent = this.getOffsetString( now, tz );
		this.elements.timeEl.textContent = this.getTimeString( now, tz );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-timezone.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonTimezoneHandler,
				{ $element }
			);
		}
	);
} );
