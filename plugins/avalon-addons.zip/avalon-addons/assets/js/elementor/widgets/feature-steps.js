class AvalonFeatureStepsHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-feature-steps',
				titles: '.avalon-feature-steps__title',
				summaries: '.avalon-feature-steps__summary',
				fill: '.avalon-feature-steps__fill',
				current: '.avalon-feature-steps__current span',
			},
		};
	}

	getDefaultElements() {
		const s = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( s.widget ),
			titles: [ ...this.$element[0].querySelectorAll( s.titles ) ],
			summaries: [ ...this.$element[0].querySelectorAll( s.summaries ) ],
			fill: this.$element[0].querySelector( s.fill ),
			currents: this.$element[0].querySelectorAll( s.current ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		if ( this.tl ) {
			this.tl.kill();
			this.tl = null;
		}

		super.onDestroy();
	}

	initAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { widget, titles, summaries, fill, currents } = this.elements;

		if ( ! widget || ! titles.length ) {
			return;
		}

		const count = titles.length;

		const setActiveIndex = ( idx ) => {
			titles.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
			summaries.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
			currents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
		};

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			this.tl = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					scrub: 1,
					pin: true,
				},
			} );

			this.tl.to( fill, {
				width: '100%',
				ease: 'none',
				duration: 1,
			}, 0 );

			this.tl.eventCallback( 'onUpdate', () => {
				const progress = this.tl.progress();
				const activeStep = Math.min(
					Math.floor( progress * count ),
					count - 1
				);
				setActiveIndex( activeStep );
			} );

			window.AvalonAddons.widget.pinReady( this.$element );
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-feature-steps.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonFeatureStepsHandler,
				{ $element }
			);
		}
	);
} );
