class AvalonTestimonialShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-testimonial-showcase',
				contents: '.avalon-testimonial-showcase__contents',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( selectors.wrapper ),
			contents: this.$element[0].querySelector( selectors.contents ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._swiper = null;
		this._onTimeLeft = null;
		this._onSliderInit = ( event ) => {
			this.bindSwiper( event.detail && event.detail.swiper );
		};

		const { wrapper, contents } = this.elements;

		if ( ! wrapper || ! contents || ! wrapper.classList.contains( 'autoplay--enabled' ) ) {
			return;
		}

		this._wrapper = wrapper;

		if ( contents.swiper ) {
			this.bindSwiper( contents.swiper );
		}

		contents.addEventListener( 'gt-slider:init', this._onSliderInit );
	}

	bindSwiper( swiper ) {
		if ( ! swiper || swiper === this._swiper ) {
			return;
		}

		this.unbindSwiper();

		this._swiper = swiper;
		this._onTimeLeft = ( instance, timeLeft, progress ) => {
			const remaining = typeof progress === 'number' && ! isNaN( progress ) ? progress : 1;
			const fill = ( 1 - remaining ) * 100;

			this._wrapper.style.setProperty( '--ts-progress', Math.max( 0, Math.min( 100, fill ) ).toFixed( 1 ) );
		};

		swiper.on( 'autoplayTimeLeft', this._onTimeLeft );
	}

	unbindSwiper() {
		if ( this._swiper && this._onTimeLeft ) {
			this._swiper.off( 'autoplayTimeLeft', this._onTimeLeft );
		}

		this._swiper = null;
		this._onTimeLeft = null;
	}

	onDestroy() {
		const contents = this.elements.contents;

		if ( contents && this._onSliderInit ) {
			contents.removeEventListener( 'gt-slider:init', this._onSliderInit );
		}

		this.unbindSwiper();

		super.onDestroy();
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-testimonial-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonTestimonialShowcaseHandler,
				{ $element }
			);
		}
	);
} );
