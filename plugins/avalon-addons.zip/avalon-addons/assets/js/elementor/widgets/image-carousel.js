class AvalonImageCarouselHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-image-carousel',
				grid: '.avalon-image-carousel__grid',
				items: '.avalon-image-carousel__item',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( selectors.wrapper ),
			grid: this.$element[0].querySelector( selectors.grid ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.onReady( this.$element, () => {
			this.initCarouselAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._cycleInterval ) {
			clearInterval( this._cycleInterval );
			this._cycleInterval = null;
		}

		if ( this._timeline ) {
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this._resizeHandler ) {
			window.removeEventListener( 'resize', this._resizeHandler );
			this._resizeHandler = null;
		}

		if ( this.mm ) {
			this.mm.kill();
			this.mm = null;
		}

		super.onDestroy();
	}

	initCarouselAnimation() {
		const { wrapper, grid } = this.elements;

		if ( ! wrapper || ! grid ) {
			return;
		}

		const items = Array.from( wrapper.querySelectorAll( '.avalon-image-carousel__item' ) );

		if ( items.length < 2 || typeof gsap === 'undefined' ) {
			return;
		}

		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}

		const autoplaySpeed = parseInt( wrapper.dataset.autoplaySpeed, 10 ) || 3000;
		const STAGGER       = 0.08;
		const DURATION      = 0.6;
		const ease          = 'power2.out';

		const getColumns = () => {
			const computed = getComputedStyle( grid ).gridTemplateColumns;
			return computed.split( ' ' ).length;
		};

		const buildColumnSets = () => {
			const colCount = getColumns();
			const sets     = Array.from( { length: colCount }, () => [] );

			items.forEach( ( item, i ) => {
				sets[ i % colCount ].push( item );
			} );

			return sets;
		};

		let columnSets = buildColumnSets();
		let colHeight  = grid.offsetHeight;

		const initColumns = () => {
			columnSets.forEach( ( set ) => {
				set._ci = 0;

				if ( set.length < 2 ) {
					return;
				}

				gsap.set( set, { willChange: 'transform, opacity' } );

				set.forEach( ( item, i ) => {
					gsap.set( item, {
						y: 0 === i ? 0 : colHeight,
						opacity: 0 === i ? 1 : 0,
					} );
				} );
			} );
		};

		const cycle = () => {
			if ( this._destroyed ) {
				return;
			}

			const tl = gsap.timeline( {
				onComplete: () => {
					if ( this._destroyed ) {
						return;
					}
					columnSets.forEach( ( set ) => {
						if ( set.length < 2 ) {
							return;
						}
						set._ci = ( ( set._ci || 0 ) + 1 ) % set.length;
					} );
				},
			} );

			columnSets.forEach( ( set, colIdx ) => {
				if ( set.length < 2 ) {
					return;
				}

				const ci        = set._ci || 0;
				const exitItem  = set[ ci ];
				const ni        = ( ci + 1 ) % set.length;
				const enterItem = set[ ni ];
				const delay     = colIdx * STAGGER;

				tl.to( exitItem, {
					y: -colHeight,
					opacity: 0,
					duration: DURATION,
					ease,
				}, delay );

				gsap.set( enterItem, { y: colHeight, opacity: 0 } );

				tl.to( enterItem, {
					y: 0,
					opacity: 1,
					duration: DURATION,
					ease,
				}, delay + STAGGER * 0.4 );
			} );

			this._timeline = tl;
		};

		const startCycle = () => {
			initColumns();
			this._cycleInterval = setInterval( cycle, autoplaySpeed );
		};

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			startCycle();

			let resizeTimer;
			this._resizeHandler = () => {
				clearTimeout( resizeTimer );
				resizeTimer = setTimeout( () => {
					if ( this._destroyed ) {
						return;
					}

					if ( this._cycleInterval ) {
						clearInterval( this._cycleInterval );
						this._cycleInterval = null;
					}

					if ( this._timeline ) {
						this._timeline.kill();
						this._timeline = null;
					}

					gsap.set( items, { clearProps: 'transform,opacity,willChange' } );

					columnSets = buildColumnSets();
					colHeight  = grid.offsetHeight;

					startCycle();
				}, 200 );
			};

			window.addEventListener( 'resize', this._resizeHandler );
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-image-carousel.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonImageCarouselHandler,
				{ $element }
			);
		}
	);
} );
