class AvalonWorksShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-works-showcase',
				track: '.avalon-works-showcase__track',
				items: '.avalon-works-showcase__item',
				images: '.avalon-works-showcase__image',
				descs: '.avalon-works-showcase__desc',
				titleCurrent: '.avalon-works-showcase__title span',
				yearCurrent: '.avalon-works-showcase__year span',
				fractionCurrent: '.avalon-works-showcase__current span',
				skipLink: '.avalon-works-showcase__skip-link',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			track: this.$element[0].querySelector( selectors.track ),
			items: [ ...this.$element[0].querySelectorAll( selectors.items ) ],
			images: [ ...this.$element[0].querySelectorAll( selectors.images ) ],
			descs: [ ...this.$element[0].querySelectorAll( selectors.descs ) ],
			titleCurrents: [ ...this.$element[0].querySelectorAll( selectors.titleCurrent ) ],
			yearCurrents: [ ...this.$element[0].querySelectorAll( selectors.yearCurrent ) ],
			fractionCurrents: [ ...this.$element[0].querySelectorAll( selectors.fractionCurrent ) ],
			skipLink: this.$element[0].querySelector( selectors.skipLink ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	initAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const isRTL = document.documentElement.dir === 'rtl';

		const { widget, track, items, images, descs, titleCurrents, yearCurrents, fractionCurrents, skipLink } = this.elements;

		if ( ! widget || ! track || ! items.length ) {
			return;
		}

		const count = items.length;

		this.mm = gsap.matchMedia();

		this.mm.add( '(min-width: 1024px) and (prefers-reduced-motion: no-preference)', () => {
			gsap.set( track, { willChange: 'transform' } );

			const getItemWidth = () => items[0].offsetWidth;

			const timeline = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					end: () => '+=' + ( count - 1 ) * getItemWidth(),
					scrub: true,
					pin: true,
					invalidateOnRefresh: true,
				},
			} );

			timeline.to( track, {
				x: () => ( isRTL ? 1 : -1 ) * ( count - 1 ) * getItemWidth(),
				ease: 'none',
				duration: count - 1,
			} );

			const setActiveIndex = ( idx ) => {
				titleCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				yearCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				fractionCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
			};

			setActiveIndex( 0 );

			timeline.eventCallback( 'onUpdate', () => {
				const progress = timeline.progress();
				const exactIndex = progress * ( count - 1 );
				const activeIndex = Math.min( Math.round( exactIndex ), count - 1 );
				const fadeRange = 1;
				const maxBlur = 24;
				const maxScale = 1.05;

				items.forEach( ( el, i ) => {
					const dist = Math.abs( exactIndex - i );
					const t = dist >= fadeRange ? 0 : 1 - dist / fadeRange;

					if ( images[ i ] ) {
						const blur = ( 1 - t ) * maxBlur;
						const scale = maxScale - t * ( maxScale - 1 );
						images[ i ].style.transform = `scale(${ scale })`;
						images[ i ].style.filter = `blur(${ blur }px)`;
						images[ i ].style.opacity = String( t );
					}

					if ( descs[ i ] ) {
						descs[ i ].style.opacity = String( t );
					}
				} );

				setActiveIndex( activeIndex );
			} );

			this._timeline = timeline;
			this._scrollTrigger = timeline.scrollTrigger;

			window.AvalonAddons.widget.pinReady( this.$element );

			return () => {
				gsap.set( track, { clearProps: 'transform,willChange' } );
			};
		} );

		this.mm.add( '(max-width: 1023px) and (prefers-reduced-motion: no-preference)', () => {
			this._mobileTriggers = [];

			const overlay = widget.querySelector( '.avalon-works-showcase__overlay' );

			if ( overlay ) {
				const pin = ScrollTrigger.create( {
					trigger: widget,
					start: 'top top',
					endTrigger: widget,
					end: 'bottom bottom',
					pin: overlay,
					pinSpacing: false,
				} );
				this._mobileTriggers.push( pin );
			}

			const fadeRange = 1;
			const maxBlur = 24;
			const maxScale = 1.05;

			const updateOpacity = () => {
				const vh = window.innerHeight;
				const center = vh / 2;

				items.forEach( ( el, i ) => {
					const rect = el.getBoundingClientRect();
					const itemCenter = rect.top + rect.height / 2;
					const dist = Math.abs( itemCenter - center ) / vh;
					const t = dist >= fadeRange ? 0 : 1 - dist / fadeRange;

					if ( images[ i ] ) {
						const blur = ( 1 - t ) * maxBlur;
						const scale = maxScale - t * ( maxScale - 1 );
						images[ i ].style.transform = `scale(${ scale })`;
						images[ i ].style.filter = `blur(${ blur }px)`;
						images[ i ].style.opacity = String( t );
					}

					if ( descs[ i ] ) {
						descs[ i ].style.opacity = String( t );
					}
				} );
			};

			updateOpacity();

			const scrollTrigger = ScrollTrigger.create( {
				trigger: widget,
				start: 'top top',
				end: 'bottom bottom',
				onUpdate: updateOpacity,
			} );
			this._mobileTriggers.push( scrollTrigger );

			const setActiveIndex = ( idx ) => {
				titleCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				yearCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				fractionCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
			};

			setActiveIndex( 0 );

			items.forEach( ( item, i ) => {
				const trigger = ScrollTrigger.create( {
					trigger: item,
					start: 'top center',
					end: 'bottom center',
					onEnter: () => setActiveIndex( i ),
					onEnterBack: () => setActiveIndex( i ),
				} );
				this._mobileTriggers.push( trigger );
			} );

			window.AvalonAddons.widget.pinReady( this.$element );

			return () => {
				this._mobileTriggers.forEach( ( trigger ) => trigger.kill() );
				this._mobileTriggers = [];
			};
		} );

		if ( skipLink ) {
			skipLink.addEventListener( 'click', ( e ) => {
				e.preventDefault();
				skipLink.style.display = 'none';

				const endScroll = this._scrollTrigger
					? this._scrollTrigger.end
					: widget.offsetTop + widget.offsetHeight;

				if ( typeof ScrollTrigger !== 'undefined' && ScrollTrigger.scrollTo ) {
					ScrollTrigger.scrollTo( endScroll, { autoKill: false } );
				} else {
					window.scrollTo( { top: endScroll, behavior: 'smooth' } );
				}
			} );
		}
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-works-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonWorksShowcaseHandler,
				{ $element }
			);
		}
	);
} );
