class AvalonWorksShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-works-showcase',
				track: '.avalon-works-showcase__track',
				images: '.avalon-works-showcase__images .avalon-works-showcase__image',
				descs: '.avalon-works-showcase__descs .avalon-works-showcase__desc',
				disp: '.avalon-works-showcase__disp',
				turb: '.avalon-works-showcase__turb',
				titleCurrent: '.avalon-works-showcase__title span',
				yearCurrent: '.avalon-works-showcase__year span',
				fractionCurrent: '.avalon-works-showcase__current span',
				skipLink: '.avalon-works-showcase__skip-link',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			track: this.$element[0].querySelector( selectors.track ),
			images: [ ...this.$element[0].querySelectorAll( selectors.images ) ],
			descs: [ ...this.$element[0].querySelectorAll( selectors.descs ) ],
			disp: this.$element[0].querySelector( selectors.disp ),
			turb: this.$element[0].querySelector( selectors.turb ),
			titleCurrents: [ ...this.$element[0].querySelectorAll( selectors.titleCurrent ) ],
			yearCurrents: [ ...this.$element[0].querySelectorAll( selectors.yearCurrent ) ],
			fractionCurrents: [ ...this.$element[0].querySelectorAll( selectors.fractionCurrent ) ],
			skipLink: this.$element[0].querySelector( selectors.skipLink ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._activeIndex = -1;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {
			this.initAnimation();
		}, () => this._destroyed );

		this.bindSkipLink();
	}

	onDestroy() {
		this._destroyed = true;

		this.unbindSkipLink();

		if ( this._scrollTrigger ) {
			this._scrollTrigger.kill();
			this._scrollTrigger = null;
		}

		if ( this._timeline ) {
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this._waterTween ) {
			this._waterTween.kill();
			this._waterTween = null;
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	getWaterFilterId() {
		return this.elements.widget?.dataset.waterFilter || '';
	}

	getImageByIndex( idx ) {
		return this.elements.images.find(
			( el ) => Number( el.dataset.index ) === idx
		) || null;
	}

	setActiveTexts( idx ) {
		const { titleCurrents, yearCurrents, fractionCurrents } = this.elements;

		titleCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
		yearCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
		fractionCurrents.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
	}

	setActiveDesc( idx ) {
		this.elements.descs.forEach( ( el ) => {
			el.classList.toggle( 'is-active', Number( el.dataset.index ) === idx );
		} );
	}

	getItemCount() {
		const { widget, images, descs } = this.elements;
		const declared = widget ? parseInt( widget.dataset.count, 10 ) : NaN;

		if ( ! Number.isNaN( declared ) && declared > 0 ) {
			return declared;
		}

		return Math.max( images.length, descs.length );
	}

	getWidgetRoot() {
		if ( this.$element && this.$element[ 0 ] ) {
			return this.$element[ 0 ];
		}

		return this.elements.widget || null;
	}

	isSectionCandidate( element ) {
		if ( ! element || element === document.body || element === document.documentElement ) {
			return false;
		}

		if ( ! element.getBoundingClientRect().height ) {
			return false;
		}

		const style = window.getComputedStyle( element );

		return 'none' !== style.display && 'hidden' !== style.visibility;
	}

	findNextSection() {
		const root = this.getWidgetRoot();

		if ( ! root ) {
			return null;
		}

		let node = root;

		while ( node && node !== document.body ) {
			let sibling = node.nextElementSibling;

			while ( sibling ) {
				if ( this.isSectionCandidate( sibling ) ) {
					return sibling;
				}

				sibling = sibling.nextElementSibling;
			}

			node = node.parentElement;
		}

		const footer = document.querySelector(
			'footer#colophon, footer.site-footer, .site-footer, .elementor-location-footer'
		);

		return footer && footer.getBoundingClientRect().height ? footer : null;
	}

	scrollToSection( target ) {
		if ( ! target ) {
			return;
		}

		const reduceMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		const smoother = window.ScrollSmoother && window.ScrollSmoother.get();

		if ( smoother ) {
			smoother.scrollTo( target, ! reduceMotion );
			return;
		}

		const rect = target.getBoundingClientRect();
		const margin = parseFloat( window.getComputedStyle( target ).scrollMarginTop ) || 0;

		window.scrollTo( {
			top: rect.top + window.scrollY - margin,
			behavior: reduceMotion ? 'auto' : 'smooth',
		} );
	}

	bindSkipLink() {
		const { skipLink } = this.elements;

		if ( ! skipLink || this._skipHandler ) {
			return;
		}

		this._skipHandler = ( event ) => {
			event.preventDefault();
			this.scrollToSection( this.findNextSection() );
		};

		skipLink.addEventListener( 'click', this._skipHandler );
	}

	unbindSkipLink() {
		const { skipLink } = this.elements;

		if ( skipLink && this._skipHandler ) {
			skipLink.removeEventListener( 'click', this._skipHandler );
		}

		this._skipHandler = null;
	}

	resetImage( el ) {
		el.classList.remove( 'is-active', 'is-underneath' );
		el.style.zIndex = '';
		el.style.filter = '';
		gsap.set( el, { clearProps: 'filter' } );
		el.style.removeProperty( '--spread' );
	}

	playWaterSpread( incoming, outgoing ) {
		const { disp, turb } = this.elements;
		const filterId = this.getWaterFilterId();
		const duration = 2;

		if ( this._waterTween ) {
			this._waterTween.kill();
		}

		incoming.classList.add( 'is-active' );
		incoming.style.zIndex = '2';

		outgoing.classList.remove( 'is-active' );
		outgoing.classList.add( 'is-underneath' );
		outgoing.style.zIndex = '1';
		outgoing.style.filter = '';
		gsap.set( outgoing, { '--spread': '150%' } );

		gsap.set( incoming, { '--spread': '0%' } );
		gsap.set( incoming, { filter: 'blur(10px)' } );

		const waterFilter = filterId ? `url(#${ filterId }) ` : '';

		const tl = gsap.timeline( {
			onComplete: () => {
				if ( this._destroyed ) {
					return;
				}

				incoming.style.filter = '';
				gsap.set( incoming, { '--spread': '150%' } );
				incoming.style.zIndex = '2';

				if ( this._activeIndex !== Number( outgoing.dataset.index ) ) {
					this.resetImage( outgoing );
				}

				this._waterTween = null;
			},
		} );

		tl.fromTo(
			incoming,
			{ '--spread': '0%' },
			{
				'--spread': '150%',
				duration,
				ease: 'power2.out',
			},
			0
		);

		tl.fromTo(
			incoming,
			{ filter: `${ waterFilter }blur(10px)` },
			{
				filter: `${ waterFilter }blur(0px)`,
				duration: duration * 0.75,
				ease: 'power2.out',
			},
			0
		);

		if ( disp ) {
			tl.fromTo(
				disp,
				{ attr: { scale: 45 } },
				{ attr: { scale: 0 }, duration, ease: 'power2.out' },
				0
			);
		}

		if ( turb ) {
			tl.fromTo(
				turb,
				{ attr: { baseFrequency: 0.02 } },
				{ attr: { baseFrequency: 0.01 }, duration, ease: 'power1.out' },
				0
			);
		}

		this._waterTween = tl;
	}

	activate( idx ) {
		const count = this.getItemCount();

		if ( idx === this._activeIndex || idx < 0 || idx >= count ) {
			return;
		}

		const prev = this._activeIndex;
		const incoming = this.getImageByIndex( idx );
		let outgoing = this.elements.images.find(
			( el ) => el !== incoming && el.classList.contains( 'is-active' )
		) || null;

		if ( ! outgoing && prev >= 0 ) {
			outgoing = this.getImageByIndex( prev );
		}

		if ( this._waterTween ) {
			this._waterTween.kill();
			this._waterTween = null;
		}

		gsap.killTweensOf( this.elements.images );

		this._activeIndex = idx;
		this.setActiveTexts( idx );
		this.setActiveDesc( idx );

		if ( ! incoming ) {
			this.elements.images.forEach( ( el ) => this.resetImage( el ) );
			return;
		}

		this.elements.images.forEach( ( el ) => {
			if ( el !== incoming && el !== outgoing ) {
				this.resetImage( el );
			}
		} );

		if ( ! outgoing || outgoing === incoming ) {
			this.resetImage( incoming );
			incoming.classList.add( 'is-active' );
			gsap.set( incoming, { '--spread': '150%' } );
			return;
		}

		this.playWaterSpread( incoming, outgoing );
	}

	initAnimation() {
		const { widget, images } = this.elements;

		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || ! widget ) {
			window.AvalonAddons.widget.pinReady( this.$element );
			return;
		}

		const count = this.getItemCount();

		if ( count < 2 ) {
			window.AvalonAddons.widget.pinReady( this.$element );
			return;
		}

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			images.forEach( ( el, i ) => {
				this.resetImage( el );
				if ( i === 0 ) {
					el.classList.add( 'is-active' );
					gsap.set( el, { '--spread': '150%' } );
				}
			} );
			this.setActiveDesc( 0 );
			this.setActiveTexts( 0 );
			this._activeIndex = 0;

			const timeline = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					end: () => '+=' + ( count - 1 ) * ( widget.offsetHeight || window.innerHeight ),
					scrub: false,
					pin: true,
					invalidateOnRefresh: true,
					onUpdate: ( self ) => {
						const idx = Math.min( Math.floor( self.progress * count ), count - 1 );
						this.activate( idx );
					},
					onLeave: () => this.activate( count - 1 ),
					onLeaveBack: () => this.activate( 0 ),
				},
			} );

			timeline.to( {}, { duration: count - 1 } );

			this._timeline = timeline;
			this._scrollTrigger = timeline.scrollTrigger;

			window.AvalonAddons.widget.pinReady( this.$element );

			return () => {
				if ( this._waterTween ) {
					this._waterTween.kill();
					this._waterTween = null;
				}

				gsap.killTweensOf( images );
				images.forEach( ( el ) => this.resetImage( el ) );
			};
		} );

		this.mm.add( '(prefers-reduced-motion: reduce)', () => {
			images.forEach( ( el, i ) => {
				this.resetImage( el );
				if ( i === 0 ) {
					el.classList.add( 'is-active' );
				}
			} );
			this.setActiveDesc( 0 );
			this.setActiveTexts( 0 );
			this._activeIndex = 0;

			window.AvalonAddons.widget.pinReady( this.$element );
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-works-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonWorksShowcaseHandler,
				{ $element }
			);
		}
	);
} );
