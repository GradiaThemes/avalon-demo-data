class AvalonServicesWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				header: '.avalon-services__header',
				details: '.avalon-services__details',
				description: '.avalon-services__description',
				servicesList: '.avalon-services__services',
				serviceItem: '.avalon-services__service',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			header: this.$element[0].querySelector( selectors.header ),
			details: this.$element[0].querySelector( selectors.details ),
			description: this.$element[0].querySelector( selectors.description ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._servicesTriggers = [];

		window.AvalonAddons.widget.onReady( this.$element, () => {
			this.initServicesAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._servicesTriggers ) {
			this._servicesTriggers.forEach( ( trigger ) => trigger.kill() );
			this._servicesTriggers = [];
		}

		if ( this.mm ) {
			this.mm.revert();
		}

		super.onDestroy();
	}

	initServicesAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { header, details, description } = this.elements;

		if ( ! details || ! description ) {
			return;
		}

		this.initServicesItemsAnimation();

		// The header is pinned to the top of the viewport for the whole widget
		// at every screen size, so it lives outside the matchMedia block.
		if ( typeof ScrollSmoother !== 'undefined' && ScrollSmoother.get() && header ) {
			this.initServicesHeaderSticky( header );
		}

		this.mm = gsap.matchMedia();

		this.mm.add( '(min-width: 768px)', () => {
			const cleanups = [];

			// Split-line reveal. Works with or without ScrollSmoother since it
			// is a plain ScrollTrigger scrub.
			if ( typeof SplitText !== 'undefined' && details.offsetHeight > description.offsetHeight ) {
				cleanups.push( this.initServicesSplitLines( details, description ) );
			}

			// Native CSS sticky (sticky bottom-0 classes) works when ScrollSmoother
			// is off, and serves as fallback when GSAP is unavailable. The transform
			// approach is only needed while ScrollSmoother breaks position: sticky.
			if ( typeof ScrollSmoother !== 'undefined' && ScrollSmoother.get() ) {
				cleanups.push( this.initServicesSticky( details, description ) );
			}

			return () => cleanups.forEach( ( cleanup ) => {
				if ( cleanup ) {
					cleanup();
				}
			} );
		} );
	}

	/**
	 * Reveal each services item as it enters the viewport from the bottom.
	 * Scrubbed to the bottom viewport edge so scrolling forward reveals the
	 * item from below and scrolling backward hides it again. Runs at all
	 * screen sizes.
	 */
	initServicesItemsAnimation() {
		const selectors = this.getSettings( 'selectors' );
		const list = this.$element[0].querySelector( selectors.servicesList );

		if ( ! list ) {
			return;
		}

		const items = list.querySelectorAll( selectors.serviceItem );

		if ( ! items.length ) {
			return;
		}

		gsap.set( items, { willChange: 'transform' } );

		const tween = gsap.fromTo( items, { y: 100, opacity: 0 }, {
			y: 0,
			opacity: 1,
			duration: 2,
			ease: 'power4.out',
			stagger: .2,
			scrollTrigger: {
				trigger: list,
				start: 'top bottom',
				end: 'bottom top',
				scrub: true,
			},
		} );

		if ( tween.scrollTrigger ) {
			this._servicesTriggers.push( tween.scrollTrigger );
		}
	}

	/**
	 * Pin the widget header to the top of the viewport while scrolling through
	 * the whole widget content. CSS position: sticky is broken by ScrollSmoother,
	 * so the header is translated down within its container as the user scrolls.
	 */
	initServicesHeaderSticky( header ) {
		const container = header.parentElement;

		if ( ! container ) {
			return;
		}

		let travel = 0;
		let disabled = false;
		let trigger = null;

		const measure = () => {
			travel = container.offsetHeight - header.offsetHeight;
		};

		const update = ( self ) => {
			if ( disabled ) {
				return;
			}

			gsap.set( header, { y: self.progress * travel } );
		};

		measure();

		if ( travel <= 0 ) {
			return;
		}

		gsap.set( header, { willChange: 'transform' } );

		trigger = ScrollTrigger.create( {
			trigger: container,
			start: 'top top',
			end: () => 'bottom top+=' + header.offsetHeight,
			onUpdate: update,
			onRefresh: ( self ) => {
				measure();

				if ( travel <= 0 ) {
					disabled = true;
					gsap.set( header, { clearProps: 'y,willChange' } );
					requestAnimationFrame( () => {
						if ( trigger ) {
							trigger.kill();
						}
					} );
					return;
				}

				update( self );
			},
		} );

		this._servicesTriggers.push( trigger );
	}

	/**
	 * Split the description into masked lines and reveal them with a scrubbed
	 * scroll animation. Lines appear top-to-bottom when scrolling forward and
	 * hide bottom-to-top when scrolling backward.
	 */
	initServicesSplitLines( details, description ) {
		const split = SplitText.create( description, { type: 'lines', mask: 'lines' } );
		const lines = split.lines;

		if ( ! lines || ! lines.length ) {
			split.revert();
			return null;
		}

		gsap.set( lines, { yPercent: 120 } );

		const timeline = gsap.timeline( {
			scrollTrigger: {
				trigger: details,
				start: () => 'top bottom-=' + description.offsetHeight,
				end: 'bottom bottom',
				scrub: true,
			},
		} );

		timeline.fromTo( lines, { yPercent: 120 }, {
			yPercent: 0,
			duration: 1,
			ease: 'none',
			stagger: { each: 0.25 },
		} );

		return () => {
			if ( timeline.scrollTrigger ) {
				timeline.scrollTrigger.kill();
			}
			timeline.kill();
			split.revert();
		};
	}

	/**
	 * Implement the sticky bottom behavior with ScrollTrigger transforms.
	 * CSS position: sticky is broken by ScrollSmoother, so the description is
	 * translated down within the details column as the user scrolls.
	 */
	initServicesSticky( details, description ) {
		let travel = 0;
		let disabled = false;
		let trigger = null;

		const measure = () => {
			travel = details.offsetHeight - description.offsetHeight;
		};

		const update = ( self ) => {
			if ( disabled ) {
				return;
			}

			gsap.set( description, { y: self.progress * travel } );
		};

		measure();

		if ( travel <= 0 ) {
			return null;
		}

		gsap.set( description, { willChange: 'transform' } );

		trigger = ScrollTrigger.create( {
			trigger: details,
			start: () => 'top bottom-=' + description.offsetHeight,
			end: 'bottom bottom',
			onUpdate: update,
			onRefresh: ( self ) => {
				measure();

				if ( travel <= 0 ) {
					disabled = true;
					gsap.set( description, { clearProps: 'y,willChange' } );
					requestAnimationFrame( () => {
						if ( trigger ) {
							trigger.kill();
						}
					} );
					return;
				}

				update( self );
			},
		} );

		return () => {
			if ( trigger ) {
				trigger.kill();
			}
			gsap.set( description, { clearProps: 'y,willChange' } );
		};
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-services.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonServicesWidgetHandler,
				{ $element }
			);
		}
	);
} );
