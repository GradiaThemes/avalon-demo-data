class AvalonTextHighlightHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				container: '.avalon-text-highlight',
				text: '.avalon-text-highlight > :first-child',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			container: this.$element[0].querySelector( selectors.container ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.onReady( this.$element, () => {
			this.initHighlightAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this._split ) {
			this._split.revert();
			this._split = null;
		}

		super.onDestroy();
	}

	/**
	 * Highlight each character progressively with a scrubbed scroll
	 * animation. Characters flip from the default color to the highlight
	 * color one by one as the user scrolls.
	 */
	initHighlightAnimation() {
		const container = this.elements.container;

		if ( ! container || 'yes' !== container.dataset.scrollHighlight ) {
			return;
		}

		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || typeof SplitText === 'undefined' ) {
			return;
		}

		const text = container.querySelector( this.getSettings( 'selectors' ).text );

		if ( ! text || ! text.textContent.trim() ) {
			return;
		}

		const styles = getComputedStyle( container );
		const defaultColor = styles.getPropertyValue( '--text-highlight-default' ).trim() || 'currentColor';
		const highlightColor = styles.getPropertyValue( '--text-highlight-color' ).trim() || defaultColor;

		// Show the end state without animation in the editor and for
		// users who prefer reduced motion.
		if ( document.body.classList.contains( 'elementor-editor-active' ) || ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) ) {
			gsap.set( text, { color: highlightColor } );
			return;
		}

		this._split = SplitText.create( text, { type: 'words', wordsClass: 'avalon-text-highlight__word' } );

		const words = this._split.words;

		if ( ! words || ! words.length ) {
			this._split.revert();
			this._split = null;
			return;
		}

		gsap.set( words, { color: defaultColor } );

		this._timeline = gsap.timeline( {
			scrollTrigger: {
				trigger: container,
				start: 'top bottom',
				end: 'center center',
				scrub: 1,
			},
		} );

		// Each word: when its turn comes the color jumps to the highlight color
		// while the opacity ramps up from 0.4 to 1. Words overlap by 50% so
		// the highlight flows continuously instead of stepping word by word.
		words.forEach( ( word, i ) => {
			this._timeline.fromTo(
				word,
				{ color: highlightColor, opacity: 0.4 },
				{ opacity: 1, duration: 1, ease: 'power2.out' },
				i * 0.5
			);
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-text-highlight.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonTextHighlightHandler,
				{ $element }
			);
		}
	);
} );
