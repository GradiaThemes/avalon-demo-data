class AvalonImageShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				main: '.avalon-image-showcase__main',
				left: '.avalon-image-showcase__side--left',
				right: '.avalon-image-showcase__side--right',
				images: '.avalon-image-showcase__images',
				widget: '.avalon-image-showcase',
				content: '.avalon-image-showcase__content',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			main: this.$element[0].querySelector( selectors.main ),
			left: this.$element[0].querySelector( selectors.left ),
			right: this.$element[0].querySelector( selectors.right ),
			images: this.$element[0].querySelector( selectors.images ),
			widget: this.$element[0].querySelector( selectors.widget ),
			content: this.$element[0].querySelector( selectors.content ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		// Declare early (before the theme initializes its animations) that
		// this widget will create its own pin, so any outer pin containing
		// this widget is deferred until this pin has finished.
		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			// Check if outer pin is still active - if so, wait for it to finish
			// before creating the widget's own pin (for default "outer first" behavior).
			this.initShowcaseAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	/**
	 * Replicate the "c-careers-hero" scroll effect: the whole widget (title
	 * and images) pins at the top of the viewport while the title fades out
	 * and the main image grows from its initial width to 100% of the
	 * container. The side images keep their fixed width and slide off-screen
	 * (clipped by the row's overflow hidden); they are never touched by JS.
	 * The trigger starts at scroll position 0 so the pin engages immediately
	 * when the widget sits at the top of the page. Desktop and reduced-motion
	 * aware only.
	 */
	initShowcaseAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { main, content, images, widget } = this.elements;

		if ( ! main || ! widget ) {
			return;
		}

		this.mm = gsap.matchMedia();

		this.mm.add( '(min-width: 1024px) and (prefers-reduced-motion: no-preference)', () => {
			gsap.set( main, { willChange: 'width' } );

			const timeline = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					end: '+=100%',
					scrub: true,
					pin: true,
				},
			} );

			if ( content ) {
				timeline.to( content, { autoAlpha: 0, ease: 'power4.out', duration: 1 }, 0 );
			}

			if ( images ) {
				timeline.fromTo( images, { y: 0, yPercent: 38 }, { yPercent: 0, ease: 'none', duration: 1 }, 0 );
			}

			timeline.to( main, { width: '100%', borderRadius: 0, ease: 'none', duration: 1 }, 0 );
		} );

		// Announce to the theme that this widget's pin is ready, so any outer
		// pin (data-animate="pin" / "cover" / "sticky") containing this widget is
		// deferred until this pin has finished.
		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-image-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonImageShowcaseHandler,
				{ $element }
			);
		}
	);
} );
