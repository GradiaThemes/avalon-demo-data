class AvalonStackedShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-stacked-showcase',
				backdropImages: '.avalon-stacked-showcase__backdrop-image',
				stack: '.avalon-stacked-showcase__stack',
				titleItems: '.avalon-stacked-showcase__title-item',
				imageItems: '.avalon-stacked-showcase__image-item',
				detailItems: '.avalon-stacked-showcase__detail-item',
				fractionCurrent: '.avalon-stacked-showcase__current span',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( selectors.wrapper ),
			backdropImages: [ ...this.$element[0].querySelectorAll( selectors.backdropImages ) ],
			stack: this.$element[0].querySelector( selectors.stack ),
			titleItems: [ ...this.$element[0].querySelectorAll( selectors.titleItems ) ],
			imageItems: [ ...this.$element[0].querySelectorAll( selectors.imageItems ) ],
			detailItems: [ ...this.$element[0].querySelectorAll( selectors.detailItems ) ],
			fractionCurrents: [ ...this.$element[0].querySelectorAll( selectors.fractionCurrent ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initStackedAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._fractionST ) {
			this._fractionST.kill();
			this._fractionST = null;
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	/**
	 * Initialise the stacked showcase scroll-pinned animation.
	 *
	 * Images are stacked and pinned via CSS sticky. Each image slides
	 * straight up as the user scrolls, revealing the next image.
	 * Titles and details scroll naturally with 50vh gaps.
	 */
	initStackedAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { wrapper, backdropImages, stack, titleItems, imageItems, detailItems, fractionCurrents } = this.elements;

		if ( ! wrapper || ! stack || ! titleItems.length ) {
			return;
		}

		const count = titleItems.length;

		if ( count < 2 ) {
			return;
		}

		this.mm = gsap.matchMedia();

		this.mm.add( '(min-width: 768px) and (prefers-reduced-motion: no-preference)', () => {
			const GAP = window.innerHeight * 0.5;

			// Images are stacked via CSS (all visible, position absolute).
			// z-index: highest on top (index 0), lowest on bottom.
			imageItems.forEach( ( img, i ) => {
				img.style.zIndex = count - i;
			} );

			// Each image (except last) slides up to reveal the one underneath.
			// Image[i] starts at y:0, ends at y:-viewportHeight (off screen top).
			// Trigger: title[i+1] top reaches viewport bottom (= images-wrapper bottom).
			imageItems.forEach( ( img, i ) => {
				if ( i === count - 1 ) {
					return;
				}

				gsap.fromTo( img,
					{ y: 0 },
					{
						y: -window.innerHeight,
						ease: 'none',
						scrollTrigger: {
							trigger: titleItems[ i + 1 ],
							start: 'top bottom',
							end: () => '+=' + GAP,
							scrub: true,
							onUpdate: ( self ) => {
								const activeIndex = self.progress >= 0.8 ? i + 1 : i;
								fractionCurrents.forEach( ( el, j ) => el.classList.toggle( 'is-active', j === activeIndex ) );
								backdropImages.forEach( ( el, j ) => el.classList.toggle( 'is-active', j === activeIndex ) );
							},
						},
					}
				);
			} );

			// Fraction: update active index based on scroll progress.
			const fractionST = ScrollTrigger.create( {
				trigger: wrapper,
				start: 'top center',
				end: 'bottom center',
				scrub: true,
			} );

			this._fractionST = fractionST;
		} );

		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-stacked-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonStackedShowcaseHandler,
				{ $element }
			);
		}
	);
} );
