class AvalonStackedShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-stacked-showcase',
				backdropImages: '.avalon-stacked-showcase__backdrop-image',
				stack: '.avalon-stacked-showcase__stack',
				titleItems: '.avalon-stacked-showcase__title-item',
				imagesWrapper: '.avalon-stacked-showcase__images-wrapper',
				imageItems: '.avalon-stacked-showcase__image-item',
				detailItems: '.avalon-stacked-showcase__detail-item',
				fractionCurrent: '.avalon-stacked-showcase__current span',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( selectors.wrapper ),
			backdropImages: [ ...this.$element[0].querySelectorAll( selectors.backdropImages ) ],
			stack: this.$element[0].querySelector( selectors.stack ),
			titleItems: [ ...this.$element[0].querySelectorAll( selectors.titleItems ) ],
			imagesWrapper: this.$element[0].querySelector( selectors.imagesWrapper ),
			imageItems: [ ...this.$element[0].querySelectorAll( selectors.imageItems ) ],
			detailItems: [ ...this.$element[0].querySelectorAll( selectors.detailItems ) ],
			fractionCurrents: [ ...this.$element[0].querySelectorAll( selectors.fractionCurrent ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initStackedAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	/**
	 * Initialise the stacked showcase flow-down scroll animation.
	 *
	 * All images start stacked at the top of the images column. The whole
	 * stack of not-yet-stopped images flows down 1:1 with the scroll,
	 * beginning when the stack's centre reaches the viewport centre.
	 * image[i] stops and stays exactly when its top meets the top of
	 * title[i], then scrolls away together with its title. The images
	 * behind it keep flowing and peel off at their own titles. z-index
	 * (highest on index 0) keeps each stopped image in front of the ones
	 * that flow past behind it, forming a shingled column of title-paired
	 * images.
	 */
	initStackedAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { wrapper, backdropImages, stack, titleItems, imagesWrapper, imageItems, fractionCurrents } = this.elements;

		if ( ! wrapper || ! stack || ! imagesWrapper || ! titleItems.length ) {
			return;
		}

		const count = titleItems.length;

		imageItems.forEach( ( img, i ) => {
			img.style.zIndex = count - i;
		} );

		this.mm = gsap.matchMedia();

		this.mm.add( '(min-width: 768px) and (prefers-reduced-motion: no-preference)', () => {
			const progresses = imageItems.map( () => 0 );

			// Scroll distance between the top of the image stack and the
			// top of title[i] - the travel image[i] must cover to stop
			// exactly on its title. Clamped at 0 so the trigger range can
			// never invert (title[i] already aligned or above the stack).
			const getOffset = ( i ) => {
				const title = titleItems[ i ];
				const titleTop = title.getBoundingClientRect().top + window.scrollY;
				const imageTop = imagesWrapper.getBoundingClientRect().top + window.scrollY;

				return Math.max( 0, titleTop - imageTop );
			};

			const setActive = ( activeIndex ) => {
				fractionCurrents.forEach( ( el, j ) => el.classList.toggle( 'is-active', j === activeIndex ) );
				backdropImages.forEach( ( el ) => el.classList.toggle( 'is-active', Number( el.dataset.index ) === activeIndex ) );
			};

			imageItems.forEach( ( img, i ) => {
				gsap.fromTo( img,
					{ y: 0 },
					{
						y: () => getOffset( i ),
						ease: 'none',
						scrollTrigger: {
							trigger: imagesWrapper,
							start: 'center center',
							end: () => 'center+=' + Math.max( 1, getOffset( i ) ) + ' center',
							scrub: true,
							invalidateOnRefresh: true,
							onUpdate: ( self ) => {
								progresses[ i ] = self.progress;

								// The active index is the highest image whose
								// travel is (nearly) complete - independent of
								// the order the triggers report in.
								let activeIndex = 0;

								progresses.forEach( ( progress, j ) => {
									if ( progress >= 0.8 ) {
										activeIndex = j;
									}
								} );

								setActive( activeIndex );
							},
						},
					}
				);
			} );
		} );

		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-stacked-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonStackedShowcaseHandler,
				{ $element }
			);
		}
	);
} );
