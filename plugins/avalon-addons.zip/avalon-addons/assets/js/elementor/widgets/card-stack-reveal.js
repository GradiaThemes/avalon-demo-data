class AvalonCardStackRevealHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				stack: '.avalon-card-stack-reveal',
				items: '.avalon-card-stack-reveal__item',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			stack: this.$element[0].querySelector( selectors.stack ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.onReady( this.$element, () => {
			this.initStackAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._cycleInterval ) {
			clearInterval( this._cycleInterval );
			this._cycleInterval = null;
		}

		if ( this._timeline ) {
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this._tween ) {
			this._tween.kill();
			this._tween = null;
		}

		super.onDestroy();
	}

	/**
	 * Initialise the card-stack cycling animation.
	 *
	 * Every 3 seconds the top card (0°) lifts up slightly and fades out
	 * while every other card shifts rotation by one step (–15° with 5 cards).
	 * The exiting card is repositioned to the bottom of the stack
	 * (rotation 60°, z-index 1) and faded back in. Z-index is updated
	 * so the 0° card is always topmost.
	 */
	initStackAnimation() {
		const { stack } = this.elements;

		if ( ! stack ) {
			return;
		}

		const items = Array.from( stack.querySelectorAll( this.getSettings( 'selectors' ).items ) );
		const count = items.length;

		if ( count < 2 || typeof gsap === 'undefined' ) {
			return;
		}

		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}

		// Fixed parameters per spec.
		const INTERVAL = 3;
		const MAX_ROT  = 60;
		const LIFT     = 25;
		const ease     = 'power2.out';

		const duration = parseFloat( stack.dataset.stackDuration ) || 0.5;
		const step     = MAX_ROT / ( count - 1 );

		let topIndex = 0;
		let cycling  = false;

		const logicalPos = ( i ) => ( i - topIndex + count ) % count;

		gsap.set( items, {
			transformOrigin: 'center center',
			willChange: 'transform, opacity, z-index',
		} );

		items.forEach( ( card, i ) => {
			const pos = logicalPos( i );
			gsap.set( card, {
				rotation: pos * step,
				zIndex: count - pos,
				opacity: 1,
				y: 0,
			} );
		} );

		const cycle = () => {
			if ( cycling || this._destroyed ) {
				return;
			}
			cycling = true;

			const oldTop  = topIndex;
			const topCard = items[ oldTop ];

			const tl = gsap.timeline( {
				onComplete: () => {
					if ( this._destroyed ) {
						return;
					}

					// Advance: old top card moves to the bottom.
					topIndex = ( topIndex + 1 ) % count;

					// Reposition old top card to bottom (instant).
					gsap.set( topCard, {
						rotation: MAX_ROT,
						zIndex: 1,
						opacity: 0,
						y: 0,
					} );

					// Update z-index for all cards so the 0° card is topmost.
					items.forEach( ( card, i ) => {
						gsap.set( card, { zIndex: count - logicalPos( i ) } );
					} );

					// Fade in the card now at the bottom of the stack.
					this._tween = gsap.to( topCard, {
						opacity: 1,
						duration: duration,
						ease: ease,
						onComplete: () => {
							cycling = false;
						},
					} );
				},
			} );

			// Top card: lift up + fade out.
			tl.to( topCard, {
				y: -LIFT,
				opacity: 0,
				duration: duration,
				ease: ease,
			}, 0 );

			// Other cards: shift rotation down by one step.
			for ( let i = 0; i < count; i++ ) {
				if ( i === oldTop ) {
					continue;
				}
				const currentRot = ( ( i - oldTop + count ) % count ) * step;
				tl.to( items[ i ], {
					rotation: currentRot - step,
					duration: duration,
					ease: ease,
				}, 0 );
			}

			this._timeline = tl;
		};

		this._cycle = cycle;
		this._cycleInterval = setInterval( cycle, INTERVAL * 1000 );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-card-stack-reveal.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonCardStackRevealHandler,
				{ $element }
			);
		}
	);
} );
