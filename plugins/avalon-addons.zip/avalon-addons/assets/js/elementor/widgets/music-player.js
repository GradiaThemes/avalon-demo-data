class AvalonMusicPlayerHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				container: '.avalon-elementor--music-player',
				text: '.avalon-music-player__text',
				bars: '.avalon-music-player__bars',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			...super.getDefaultElements(),
			$container: this.$element.find( selectors.container ),
			$text: this.$element.find( selectors.text ),
			$bars: this.$element.find( selectors.bars ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._soundOn = false;
		this._fadeRAF = null;

		this.$container = this.elements.$container;
		this.$text = this.elements.$text;
		this.$bars = this.elements.$bars;
		this.container = this.$container[0];

		if ( ! this.container ) {
			return;
		}

		this._onClick = this.toggleSound.bind( this );
		this.container.addEventListener( 'click', this._onClick );

		this.initAudio();
		this.setPlaying( false );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._fadeRAF ) {
			cancelAnimationFrame( this._fadeRAF );
			this._fadeRAF = null;
		}

		if ( this.container ) {
			this.container.removeEventListener( 'click', this._onClick );
		}

		if ( this.media ) {
			this.media.pause();
			this.media.src = '';
			this.media.load();
			this.media = null;
		}

		super.onDestroy();
	}

	initAudio() {
		const src = this.container.getAttribute( 'data-src' );
		const mime = this.container.getAttribute( 'data-mime' );

		if ( ! src ) {
			return;
		}

		const audio = new Audio();
		audio.preload = 'auto';
		audio.loop = this.container.getAttribute( 'data-loop' ) === '1';
		audio.muted = true;
		audio.volume = 0;

		if ( ! mime ) {
			audio.src = src;
		} else {
			const source = document.createElement( 'source' );
			source.src = src;
			source.type = mime || 'audio/mpeg';
			audio.appendChild( source );
		}

		this.media = audio;
	}

	toggleSound( event ) {
		event.preventDefault();

		if ( ! this.media ) {
			return;
		}

		if ( this._soundOn ) {
			this.fadeOut();
			this.setPlaying( false );
		} else {
			this.media.muted = false;
			if ( this.media.paused ) {
				const p = this.media.play();
				if ( p && p.catch ) {
					p.catch( () => {} );
				}
			}
			this.fadeIn();
			this.setPlaying( true );
		}

		this._soundOn = ! this._soundOn;
	}

	fadeIn() {
		if ( ! this.media ) {
			return;
		}

		if ( this._fadeRAF ) {
			cancelAnimationFrame( this._fadeRAF );
			this._fadeRAF = null;
		}

		const target = parseFloat( this.container.getAttribute( 'data-volume' ) || '1' );
		const duration = 500;
		const start = performance.now();
		const from = this.media.volume;

		const step = ( now ) => {
			if ( this._destroyed || ! this.media ) {
				return;
			}
			const progress = Math.max( 0, Math.min( ( now - start ) / duration, 1 ) );
			const eased = 1 - ( 1 - progress ) * ( 1 - progress );
			this.media.volume = from + ( target - from ) * eased;
			if ( progress < 1 ) {
				this._fadeRAF = requestAnimationFrame( step );
			} else {
				this._fadeRAF = null;
			}
		};

		this._fadeRAF = requestAnimationFrame( step );
	}

	fadeOut() {
		if ( ! this.media ) {
			return;
		}

		if ( this._fadeRAF ) {
			cancelAnimationFrame( this._fadeRAF );
			this._fadeRAF = null;
		}

		const duration = 500;
		const start = performance.now();
		const from = this.media.volume;

		const step = ( now ) => {
			if ( this._destroyed || ! this.media ) {
				return;
			}
			const progress = Math.max( 0, Math.min( ( now - start ) / duration, 1 ) );
			const eased = 1 - ( 1 - progress ) * ( 1 - progress );
			this.media.volume = from * ( 1 - eased );
			if ( progress < 1 ) {
				this._fadeRAF = requestAnimationFrame( step );
			} else {
				this.media.volume = 0;
				this.media.muted = true;
				this._fadeRAF = null;
			}
		};

		this._fadeRAF = requestAnimationFrame( step );
	}

	setPlaying( playing ) {
		if ( ! this.container ) {
			return;
		}

		this.container.classList.toggle( 'is-playing', playing );
		this.container.classList.toggle( 'is-off', ! playing );

		if ( this.$text ) {
			const onText = this.container.getAttribute( 'data-on-text' ) || '';
			const offText = this.container.getAttribute( 'data-off-text' ) || '';
			this.$text.text( playing ? onText : offText );
		}

		this.container.setAttribute( 'aria-pressed', playing ? 'true' : 'false' );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-music-player.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonMusicPlayerHandler,
				{ $element }
			);
		}
	);
} );
