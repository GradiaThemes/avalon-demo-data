class AvalonHeroShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-hero-showcase',
				text: '.avalon-hero-showcase__text',
				main: '.avalon-hero-showcase__main',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			text: this.$element[0].querySelector( selectors.text ),
			main: this.$element[0].querySelector( selectors.main ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this.initTextMask();

		// Declare early (before the theme initializes its animations) that
		// this widget will create its own pin, so any outer pin containing
		// this widget is deferred until this pin has finished.
		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			// Check if outer pin is still active - if so, wait for it to finish
			// before creating the widget's own pin (for default "outer first" behavior).
			this.initShowcaseAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._maskOnResize ) {
			window.removeEventListener( 'resize', this._maskOnResize );
			this._maskOnResize = null;
		}

		if ( this._maskOnLoad ) {
			window.removeEventListener( 'load', this._maskOnLoad );
			this._maskOnLoad = null;
		}

		if ( this._maskOnMediaQueryChange ) {
			if ( this._maskMediaQuery && this._maskMediaQuery.removeEventListener ) {
				this._maskMediaQuery.removeEventListener( 'change', this._maskOnMediaQueryChange );
			} else if ( this._maskMediaQuery && this._maskMediaQuery.removeListener ) {
				this._maskMediaQuery.removeListener( this._maskOnMediaQueryChange );
			}
			this._maskOnMediaQueryChange = null;
		}

		clearTimeout( this._maskResizeTimer );
		this._maskRectKey = null;

		if ( this.elements.text ) {
			this.elements.text.style.maskImage = '';
			this.elements.text.style.webkitMaskImage = '';
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	/**
	 * Punch holes in the text block background exactly where the main text
	 * glyphs are, so whatever sits behind the block (media or plain page
	 * background) shows through the letters while the panel background stays
	 * everywhere else. The mask is drawn to an offscreen canvas from the
	 * real rendered text metrics and applied as a data-URI mask on the
	 * panel, so it needs no media element at all.
	 */
	initTextMask() {
		const { text, main } = this.elements;

		if ( ! text || ! main || ! main.textContent.trim() ) {
			return;
		}

		this._maskCanvas = document.createElement( 'canvas' );
		this.syncTextMask();

		// Make sure the exact webfont is ready before the canvas rasterizes,
		// otherwise the mask glyphs get drawn with a fallback font.
		if ( document.fonts && document.fonts.load ) {
			document.fonts.load( this.getMainFontString() )
				.catch( () => {} )
				.then( () => this.syncTextMask() );
		}

		this._maskOnResize = () => {
			clearTimeout( this._maskResizeTimer );
			this._maskResizeTimer = setTimeout( () => {
				const textEl = this.elements.text;
				const mainEl = this.elements.main;

				if ( textEl && mainEl ) {
					const panel = textEl.getBoundingClientRect();
					const main = mainEl.getBoundingClientRect();
					const key = `${Math.round( panel.width )}x${Math.round( panel.height )}@${Math.round( main.width )}x${Math.round( main.height )}`;

					if ( this._maskRectKey && this._maskRectKey === key ) {
						return;
					}
				}

				this.syncTextMask();
			}, 150 );
		};
		window.addEventListener( 'resize', this._maskOnResize );

		this._maskOnLoad = () => this.syncTextMask();
		window.addEventListener( 'load', this._maskOnLoad );

		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( () => this.syncTextMask() );
		}

		// Re-sync when the <br> visibility toggles at the sm breakpoint
		// (theme utility .sm\:no-br) without a window resize.
		this._maskMediaQuery = window.matchMedia( '(min-width: 768px)' );
		this._maskOnMediaQueryChange = () => this.syncTextMask();
		if ( this._maskMediaQuery.addEventListener ) {
			this._maskMediaQuery.addEventListener( 'change', this._maskOnMediaQueryChange );
		} else if ( this._maskMediaQuery.addListener ) {
			this._maskMediaQuery.addListener( this._maskOnMediaQueryChange );
		}

		this._maskRetryCount = 0;
		this.retryTextMask();
	}

	/**
	 * Retry measuring the text until the layout is complete (fonts, images,
	 * containers), then apply the mask. Stops after a fixed number of frames.
	 */
	retryTextMask() {
		if ( this._destroyed || this._maskRetryCount >= 30 ) {
			return;
		}

		this._maskRetryCount++;

		requestAnimationFrame( () => {
			const lines = this.getTextLines( this.elements.main );
			const hasLines = lines.some( ( line ) => line.rect && line.rect.width && line.rect.height );

			if ( hasLines ) {
				this.syncTextMask();
				return;
			}

			this.retryTextMask();
		} );
	}

	syncTextMask() {
		const { text, main } = this.elements;

		if ( this._destroyed || ! text || ! main || ! this._maskCanvas ) {
			return;
		}

		const panelRect = text.getBoundingClientRect();
		const mainRect = main.getBoundingClientRect();

		if ( ! panelRect.width || ! panelRect.height || ! mainRect.width || ! mainRect.height ) {
			return;
		}

		this._maskRectKey = `${Math.round( panelRect.width )}x${Math.round( panelRect.height )}@${Math.round( mainRect.width )}x${Math.round( mainRect.height )}`;

		const MAX_MASK_DIMENSION = 2048;
		let scale = 2;
		const maxDimension = Math.max( panelRect.width, panelRect.height );

		if ( maxDimension > MAX_MASK_DIMENSION ) {
			scale = Math.min( 2, MAX_MASK_DIMENSION / maxDimension );
		}

		const canvas = this._maskCanvas;

		canvas.width = Math.ceil( panelRect.width * scale );
		canvas.height = Math.ceil( panelRect.height * scale );

		const ctx = canvas.getContext( '2d' );

		ctx.scale( scale, scale );

		// Opaque white keeps the text block background; the glyphs are then
		// erased from the alpha channel so the mask punches holes in the panel
		// exactly where the letters are (alpha-based masking, colors ignored).
		ctx.fillStyle = '#ffffff';
		ctx.fillRect( 0, 0, panelRect.width, panelRect.height );

		const styles = getComputedStyle( main );
		const fontSize = parseFloat( styles.fontSize );

		if ( ! fontSize || fontSize <= 0 ) {
			return;
		}

		ctx.font = this.getMainFontString();
		ctx.textAlign = 'center';
		ctx.textBaseline = 'alphabetic';

		if ( 'letterSpacing' in ctx ) {
			ctx.letterSpacing = styles.letterSpacing;
		}

		const textTransform = styles.textTransform;
		const xOffset = mainRect.left - panelRect.left;
		const ascent = ctx.measureText( 'M' ).actualBoundingBoxAscent || fontSize * 0.8;
		const lineHeightPx = 'normal' === styles.lineHeight ? fontSize * 1.2 : parseFloat( styles.lineHeight );
		const halfLeading = ( lineHeightPx - fontSize ) / 2;

		ctx.globalCompositeOperation = 'destination-out';

		this.getTextLines( main ).forEach( ( line ) => {
			// Center the glyphs on the measured line box so the mask stays
			// aligned whatever the text alignment or font metrics are. The
			// baseline sits at the line top plus half of the extra leading.
			ctx.fillText(
				this.applyTextTransform( line.text, textTransform ),
				xOffset + ( line.rect.left - mainRect.left ) + line.rect.width / 2,
				line.rect.top - panelRect.top + halfLeading + ascent
			);
		} );

		ctx.globalCompositeOperation = 'source-over';

		const dataUrl = canvas.toDataURL( 'image/png' );

		text.style.maskImage = 'url(' + dataUrl + ')';
		text.style.webkitMaskImage = 'url(' + dataUrl + ')';
		text.style.maskSize = '100% 100%';
		text.style.webkitMaskSize = '100% 100%';
		text.style.maskRepeat = 'no-repeat';
		text.style.webkitMaskRepeat = 'no-repeat';
		text.style.maskMode = 'alpha';
		text.style.webkitMaskMode = 'alpha';
	}

	/**
	 * Build the canvas font shorthand from the main text computed styles.
	 *
	 * @return {string} Canvas font string.
	 */
	getMainFontString() {
		const styles = getComputedStyle( this.elements.main );
		const parts = [ styles.fontStyle, styles.fontWeight ];
		const fontStretch = this.normalizeFontStretch( styles.fontStretch );

		if ( fontStretch ) {
			parts.push( fontStretch );
		}

		parts.push( styles.fontSize, styles.fontFamily );

		return parts.join( ' ' );
	}

	/**
	 * Normalize the CSS font-stretch into a canvas-compatible keyword.
	 * Percentages (e.g. 90%) break the canvas/document fonts parser, so
	 * unknown values are dropped and the remaining metrics still match.
	 *
	 * @param {string} stretch Computed font-stretch value.
	 * @return {string} Keyword or empty string.
	 */
	normalizeFontStretch( stretch ) {
		if ( ! stretch || 'normal' === stretch ) {
			return '';
		}

		const keywords = {
			'50%': 'ultra-condensed',
			'62.5%': 'extra-condensed',
			'75%': 'condensed',
			'87.5%': 'semi-condensed',
			'100%': 'normal',
			'112.5%': 'semi-expanded',
			'125%': 'expanded',
			'150%': 'extra-expanded',
			'200%': 'ultra-expanded',
		};

		if ( keywords[ stretch ] ) {
			return keywords[ stretch ];
		}

		// Non-standard percentage (e.g. 90%): not representable reliably.
		if ( /%$/.test( stretch ) ) {
			return '';
		}

		return stretch;
	}

	/**
	 * Apply the CSS text-transform so the canvas glyphs match the DOM layout.
	 *
	 * @param {string} text      Line text.
	 * @param {string} transform CSS text-transform value.
	 * @return {string} Transformed text.
	 */
	applyTextTransform( text, transform ) {
		if ( 'uppercase' === transform ) {
			return text.toUpperCase();
		}

		if ( 'lowercase' === transform ) {
			return text.toLowerCase();
		}

		if ( 'capitalize' === transform ) {
			return text.replace( /(^|\s)\S/g, ( match ) => match.toUpperCase() );
		}

		return text;
	}

	/**
	 * Split a text element into visual lines with their bounding rects,
	 * walking each text node (lines may wrap or be separated by <br>).
	 * Leading and trailing whitespace (e.g. the newlines left by nl2br
	 * between <br> tags) is excluded from both the drawn text and the
	 * measured rect, so the mask glyphs can never drift from the layout.
	 *
	 * @param {HTMLElement} element Text element.
	 * @return {Array} Array of { text, rect } objects.
	 */
	getTextLines( element ) {
		const lines = [];
		const range = document.createRange();
		const walker = document.createTreeWalker( element, NodeFilter.SHOW_TEXT );

		let node = walker.nextNode();

		while ( node ) {
			const text = node.textContent;

			if ( text.trim() ) {
				let start = 0;
				let lineIndex = 0;

				for ( let i = 0; i <= text.length; i++ ) {
					range.setStart( node, start );
					range.setEnd( node, i );

					const rects = range.getClientRects();

					if ( rects.length > lineIndex + 1 ) {
						const firstVisible = text.slice( start ).search( /\S/ );

						if ( firstVisible >= 0 ) {
							const cleanStart = start + firstVisible;
							let cleanEnd = i - 1;

							while ( cleanEnd > cleanStart && /\s/.test( text[ cleanEnd - 1 ] ) ) {
								cleanEnd--;
							}

							lines.push( {
								text: text.slice( cleanStart, cleanEnd ),
								rect: rects[ lineIndex ],
							} );
						}

						start = i - 1;
						lineIndex = rects.length - 1;
						i--;
					}
				}

				if ( start < text.length || ! lines.length ) {
					const firstVisible = text.slice( start ).search( /\S/ );

					if ( firstVisible >= 0 ) {
						const cleanStart = start + firstVisible;
						let cleanEnd = text.length;

						while ( cleanEnd > cleanStart && /\s/.test( text[ cleanEnd - 1 ] ) ) {
							cleanEnd--;
						}

						range.setStart( node, cleanStart );
						range.setEnd( node, cleanEnd );

						const finalRects = range.getClientRects();
						const finalRect = finalRects[ finalRects.length - 1 ];

						if ( finalRect && finalRect.width ) {
							lines.push( {
								text: text.slice( cleanStart, cleanEnd ),
								rect: finalRect,
							} );
						}
					}
				}
			}

			node = walker.nextNode();
		}

		return lines;
	}

	/**
	 * Pin the widget when its bottom reaches the bottom of the viewport and
	 * scrub the text block upward over the pin distance, revealing the media
	 * behind it. The media is never transformed, so it stays perfectly still.
	 * Desktop and reduced-motion aware only. The mask lives on the text
	 * block itself, so holes and glyphs move together and never drift.
	 */
	initShowcaseAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { widget, text } = this.elements;

		if ( ! widget || ! text ) {
			return;
		}

		gsap.set( text, { willChange: 'transform' } );

		const timeline = gsap.timeline( {
			scrollTrigger: {
				trigger: widget,
				start: 'bottom bottom',
				scrub: 1,
				pin: true,
			},
		} );

		timeline.to( text, { yPercent: -100, ease: 'none', duration: 1 } );

		// Announce to the theme that this widget's pin is ready, so any outer
		// pin (data-animate="pin" / "cover" / "sticky") containing this widget is
		// deferred until this pin has finished.
		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-hero-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonHeroShowcaseHandler,
				{ $element }
			);
		}
	);
} );
