class AvalonStepProcessHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-step-process',
				stepWrapper: '.avalon-step-process__step-wrapper',
				headingText: '.avalon-step-process__heading-text',
				cards: '.avalon-step-process__card',
				arms: '.avalon-step-process__arm',
			},
		};
	}

	getDefaultElements() {
		const s = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( s.wrapper ),
			stepWrapper: this.$element[0].querySelector( s.stepWrapper ),
			headingText: this.$element[0].querySelector( s.headingText ),
			cards: [ ...this.$element[0].querySelectorAll( s.cards ) ],
			arms: [ ...this.$element[0].querySelectorAll( s.arms ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._lastActiveIndex = -1;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		if ( this.tl ) {
			this.tl.kill();
			this.tl = null;
		}

		if ( this._resizeHandler ) {
			window.removeEventListener( 'resize', this._resizeHandler );
			this._resizeHandler = null;
		}

		super.onDestroy();
	}

	initAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { wrapper, stepWrapper, headingText, cards, arms } = this.elements;

		if ( ! wrapper || ! cards.length ) {
			return;
		}

		const count = cards.length;
		const scrollDistance = parseInt( wrapper.dataset.scrollDistance, 10 ) || 500;
		const totalScroll = count * scrollDistance;
		const pinLength = ( count - 1 ) * scrollDistance;
		const angle = parseFloat( stepWrapper?.dataset.angle ) || 25;

		this._setActiveIndex = ( idx ) => {
			if ( idx === this._lastActiveIndex ) {
				return;
			}
			this._lastActiveIndex = idx;

			cards.forEach( ( el, i ) => {
				const isActive = i === idx;
				el.classList.toggle( 'is-active', isActive );
				el.setAttribute( 'aria-hidden', ! isActive );
			} );

			// Toggle is-active on arms (dial rotation is handled by the timeline).
			arms.forEach( ( arm, i ) => {
				arm.classList.toggle( 'is-active', i === idx );
			} );
		};

		this._setActiveIndex( 0 );

		// Handle resize
		this._resizeHandler = () => {
			if ( typeof ScrollTrigger !== 'undefined' ) {
				ScrollTrigger.refresh();
			}
		};
		window.addEventListener( 'resize', this._resizeHandler );

		this.mm = gsap.matchMedia();

		// Build the timeline for a given card spacing.
		// Desktop (>=1024px): spacing 415. Below 1023px: spacing 215.
		const build = ( spacing, rotation_card ) => {
			// Initial card stacking so cards 1+ sit below card 0 (not overlapping at y:0).
			gsap.set( cards[ 0 ], { opacity: 1, y: 0, rotation: 0 } );
			cards.forEach( ( card, i ) => {
				if ( 0 === i ) {
					return;
				}
				gsap.set( card, { opacity: 0, y: spacing * i, rotation: rotation_card * i * -1 } );
			} );

			// Heading char reveal
			if ( headingText ) {
				const spans = headingText.querySelectorAll( 'span span[style*="opacity:0"]' );

				if ( spans.length ) {
					gsap.set( spans, { opacity: 0, y: 16 } );

					gsap.to( spans, {
						opacity: 1,
						y: 0,
						duration: 0.5,
						ease: 'power2.out',
						stagger: 0.02,
						scrollTrigger: {
							trigger: wrapper,
							start: 'top 80%',
							toggleActions: 'play none none none',
						},
					} );
				}
			}

			this.tl = gsap.timeline( {
					scrollTrigger: {
						trigger: wrapper,
						start: 'bottom bottom',
						end: () => '+=' + pinLength,
						scrub: true,
						pin: true,
						invalidateOnRefresh: true,
						onUpdate: ( self ) => {
							// Continuous position from first card (0) to last card (count-1).
							const pos = self.progress * ( count - 1 );
							const activeStep = Math.min(
								Math.max( Math.round( pos ), 0 ),
								count - 1
							);
							this._setActiveIndex( activeStep );
						},
					},
				} );

			// Dial rotates continuously (all arms move together as one circle).
			if ( stepWrapper ) {
				this.tl.to( stepWrapper, {
					rotation: angle * ( count - 1 ),
					ease: 'none',
					duration: count - 1,
				}, 0 );
			}

			// Continuous conveyor: every card moves EVERY frame.
			// y and rotation both derive from the offset (i - t), so cards tilt as they pass center.
			cards.forEach( ( card, i ) => {
				// Full-length travel (y + rotation) across the whole scroll.
				this.tl.fromTo( card,
					{ y: i * spacing, rotation: i * rotation_card * -1 },
					{ y: ( i - ( count - 1 ) ) * spacing, rotation: ( i - ( count - 1 ) ) * rotation_card * -1, ease: 'none', duration: count - 1 },
					0
				);

				// Opacity windows (0 -> 1 -> 0 around center); rotation is handled above.
				if ( 0 !== i ) {
					this.tl.fromTo( card, { opacity: 0 }, { opacity: 1, ease: 'none', duration: 1 }, i - 1 );
				}
				if ( i !== count - 1 ) {
					this.tl.to( card, { opacity: 0, ease: 'none', duration: 1 }, i );
				}
			} );

			window.AvalonAddons.widget.pinReady( this.$element );
		};

		this.mm.add( '(prefers-reduced-motion: no-preference) and (min-width: 1024px)', () => build( 415, angle ) );
		this.mm.add( '(prefers-reduced-motion: no-preference) and (max-width: 1023px)', () => build( 215, 0 ) );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-step-process.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonStepProcessHandler,
				{ $element }
			);
		}
	);
} );
