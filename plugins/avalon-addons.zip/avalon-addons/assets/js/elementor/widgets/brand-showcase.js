class AvalonBrandShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				brands: '.avalon-brand-showcase__brand',
				spheres: '.avalon-brand-showcase__sphere',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			brands: [ ...this.$element[0].querySelectorAll( selectors.brands ) ],
			spheres: [ ...this.$element[0].querySelectorAll( selectors.spheres ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );
		this.initBrandInteraction();
	}

	initBrandInteraction() {
		const { brands } = this.elements;

		brands.forEach( ( brand, index ) => {
			brand.addEventListener( 'mouseenter', () => this.setActiveBrand( index ) );
			brand.addEventListener( 'click', () => this.setActiveBrand( index ) );
			brand.addEventListener( 'keydown', ( e ) => {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					this.setActiveBrand( index );
				}
			} );
		} );
	}

	setActiveBrand( index ) {
		const { brands, spheres } = this.elements;

		brands.forEach( ( b, i ) => b.classList.toggle( 'is-active', i === index ) );
		spheres.forEach( ( s, i ) => s.classList.toggle( 'is-active', i === index ) );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-brand-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonBrandShowcaseHandler,
				{ $element }
			);
		}
	);
} );
