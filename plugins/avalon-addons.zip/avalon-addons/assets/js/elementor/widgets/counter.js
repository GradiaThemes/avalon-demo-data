/**
 * Simple numeric counter for the Avalon Counter widget.
 *
 * The number is rendered as normal text instead of individual digit
 * columns. GSAP animates the numeric value from the starting number
 * to the ending number when the widget enters the viewport.
 */
class AvalonCounterHandler extends elementorModules.frontend.handlers.Base {

	getDefaultSettings() {
		return {
			selectors: {
				container: '.avalon-counter',
				value: '.avalon-counter__value',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );
		const scope = this.$element[0];

		return {
			container: scope.querySelector( selectors.container ),
			value: scope.querySelector( selectors.value ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._tween = null;

		this._reducedMotion = !! (
			window.matchMedia &&
			window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches
		);

		if (
			! this.elements.container ||
			! this.elements.value
		) {
			return;
		}

		const container = this.elements.container;

		this._from = this.parseNumber( container.dataset.from );
		this._to = this.parseNumber( container.dataset.to );

		if ( null === this._from || null === this._to ) {
			return;
		}

		// Set the starting value immediately.
		this.setValue( this._from );

		const scheduled = window.AvalonAddons?.widget?.onReady(
			this.$element,
			() => this.initCounterAnimation(),
			() => this._destroyed
		);

		// Fallback when the theme animation API is unavailable.
		if ( ! scheduled ) {
			this.resetCounter();
		}
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._tween ) {
			if ( this._tween.scrollTrigger ) {
				this._tween.scrollTrigger.kill();
			}

			this._tween.kill();
			this._tween = null;
		}

		this.resetCounter();

		super.onDestroy();
	}

	/**
	 * Start the counter animation.
	 *
	 * @return {void}
	 */
	initCounterAnimation() {
		if (
			this._reducedMotion ||
			'undefined' === typeof gsap ||
			'undefined' === typeof ScrollTrigger
		) {
			this.resetCounter();
			return;
		}

		const container = this.elements.container;
		const value = this.elements.value;

		const duration = Math.max(
			( parseInt( container.dataset.duration, 10 ) || 2000 ) / 1000,
			0.2
		);

		const counter = {
			value: this._from,
		};

		this._tween = gsap.to( counter, {
			value: this._to,
			duration,
			ease: 'power2.out',

			scrollTrigger: {
				trigger: container,
				start: 'top 85%',
				once: true,
			},

			onUpdate: () => {
				if ( this._destroyed ) {
					return;
				}

				this.setValue( counter.value );
			},

			onComplete: () => {
				this.setValue( this._to );
			},
		} );
	}

	/**
	 * Parse a formatted number into a numeric value.
	 *
	 * Supports values such as:
	 * 120
	 * 1,200
	 * 1.200
	 * 1 200
	 *
	 * @param {string} value Number string.
	 * @return {number|null}
	 */
	parseNumber( value ) {
		if ( undefined === value || null === value ) {
			return null;
		}

		let number = String( value ).trim();

		if ( ! number ) {
			return null;
		}

		// Remove common thousand separators.
		number = number.replace( /[, _']/g, '' );

		// Keep digits, minus sign and decimal point.
		number = number.replace( /[^0-9.-]/g, '' );

		const parsed = Number( number );

		return Number.isFinite( parsed ) ? parsed : null;
	}

	/**
	 * Update the visible number.
	 *
	 * The value is rendered as one normal text node, so proportional
	 * fonts keep their natural character widths.
	 *
	 * @param {number} value Current numeric value.
	 * @return {void}
	 */
	setValue( value ) {
		if ( ! this.elements.value ) {
			return;
		}

		const rounded = Math.round( value );

		this.elements.value.textContent = this.formatNumber( rounded );
	}

	/**
	 * Format the animated number.
	 *
	 * Uses the same thousand separator as the widget's final value.
	 *
	 * @param {number} value Numeric value.
	 * @return {string}
	 */
	formatNumber( value ) {
		const original = this.elements.container.dataset.to || '';

		// Detect the separator used by the final rendered number.
		let separator = '';

		if ( original.includes( ',' ) ) {
			separator = ',';
		} else if ( original.includes( '.' ) ) {
			separator = '.';
		} else if ( original.includes( ' ' ) ) {
			separator = ' ';
		} else if ( original.includes( '_' ) ) {
			separator = '_';
		} else if ( original.includes( "'" ) ) {
			separator = "'";
		}

		const negative = value < 0;
		const absolute = Math.abs( value ).toString();

		let formatted = absolute;

		if ( separator && absolute.length > 3 ) {
			formatted = absolute.replace(
				/\B(?=(\d{3})+(?!\d))/g,
				separator
			);
		}

		return negative ? `-${formatted}` : formatted;
	}

	/**
	 * Reset the counter to its final value.
	 *
	 * Used for reduced motion and when the animation system is unavailable.
	 *
	 * @return {void}
	 */
	resetCounter() {
		if ( null !== this._to ) {
			this.setValue( this._to );
		}
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-counter.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonCounterHandler,
				{
					$element,
				}
			);
		}
	);
} );