/**
 * Shared helpers for Avalon Elementor widget frontend handlers.
 *
 * Lifted wrappers around the theme's `window.Avalon` animation/pin API so
 * individual widget scripts only need to pass their `$element` (or an explicit
 * widget name for special cases).
 */
window.AvalonAddons = window.AvalonAddons || {};

window.AvalonAddons.widget = ( () => {
	/**
	 * Resolve the widget slug from the element wrapper, with an explicit
	 * name override for special cases.
	 *
	 * @param {jQuery} $element Widget scope.
	 * @param {string} [name]   Optional explicit widget name.
	 * @return {string} Widget slug (e.g. "image-showcase").
	 */
	const getName = ( $element, name ) => {
		if ( name ) {
			return name;
		}

		return ( $element[0].dataset.widget_type || '' ).replace( /\..*$/, '' ).replace( /^avalon-/, '' );
	};

	/**
	 * Widget wrapper selector for the theme API.
	 *
	 * @param {string} name Widget slug.
	 * @return {string} Selector.
	 */
	const sel = ( name ) => '.avalon-' + name;

	return {
		/**
		 * Announce that the widget will create its own pin so any outer pin
		 * deferring it is deferred until this pin finishes.
		 *
		 * @param {jQuery} $element Widget scope.
		 * @param {string} [name]   Optional explicit widget name.
		 */
		pinStarting( $element, name ) {
			if ( window.Avalon && window.Avalon.pinStarting ) {
				window.Avalon.pinStarting( sel( getName( $element, name ) ) );
			}
		},

		/**
		 * Announce that the widget's own pin is ready.
		 *
		 * @param {jQuery} $element Widget scope.
		 * @param {string} [name]   Optional explicit widget name.
		 */
		pinReady( $element, name ) {
			if ( window.Avalon && window.Avalon.pinReady ) {
				window.Avalon.pinReady( sel( getName( $element, name ) ) );
			}
		},

		/**
		 * Run a callback once the theme's animations are ready.
		 *
		 * @param {jQuery}    $element    Widget scope.
		 * @param {string}    [name]      Optional explicit widget name.
		 * @param {Function}  callback    Callback to run when ready.
		 * @param {Function}  isDestroyed Predicate guarding against destroyed widgets.
		 * @return {boolean} True when scheduled, false when the theme API is missing.
		 */
		onReady( $element, name, callback, isDestroyed ) {
			// Support both ( $element, name, callback, isDestroyed ) and the
			// shorthand ( $element, callback, isDestroyed ) used by widgets.
			if ( typeof name === 'function' ) {
				isDestroyed = callback;
				callback = name;
				name = undefined;
			}

			if ( ! window.Avalon || ! window.Avalon.onAnimationsReady ) {
				return false;
			}

			window.Avalon.onAnimationsReady( () => {
				if ( ! isDestroyed() ) {
					callback();
				}
			} );

			return true;
		},

		/**
		 * Run a callback once the theme's animations are ready and any outer
		 * pin containing this widget has finished.
		 *
		 * @param {jQuery}    $element    Widget scope.
		 * @param {string}    [name]      Optional explicit widget name.
		 * @param {Function}  callback    Callback to run when ready.
		 * @param {Function}  isDestroyed Predicate guarding against destroyed widgets.
		 * @return {boolean} True when scheduled, false when the theme API is missing.
		 */
		whenOuterPinDone( $element, name, callback, isDestroyed ) {
			// Same shorthand support as onReady().
			if ( typeof name === 'function' ) {
				isDestroyed = callback;
				callback = name;
				name = undefined;
			}

			return this.onReady( $element, name, () => {
				const selector = sel( getName( $element, name ) );

				if ( window.Avalon.isOuterPinDone && ! window.Avalon.isOuterPinDone( selector ) ) {
					window.Avalon.waitForOuterPin( selector, () => {
						if ( ! isDestroyed() ) {
							callback();
						}
					} );
				} else if ( ! isDestroyed() ) {
					callback();
				}
			}, isDestroyed );
		},
	};
} )();
