class AvalonPostsShowcaseHandler extends elementorModules.frontend.handlers.Base {

	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-posts-showcase',
				intro: '.avalon-posts-showcase__intro',
				introHeading: '.avalon-posts-showcase__intro-heading',
				introDesc: '.avalon-posts-showcase__intro-desc',
				introBg: '.avalon-posts-showcase__intro-bg',
				introImages: '.avalon-posts-showcase__intro-img',
				items: '.avalon-posts-showcase__items',
				thumbWrapper: '.avalon-posts-showcase__thumb-wrapper',
				thumb: '.avalon-posts-showcase__thumb',
				titles: '.avalon-posts-showcase__titles',
				titleItems: '.avalon-posts-showcase__title-item',
				details: '.avalon-posts-showcase__details',
				detailItems: '.avalon-posts-showcase__detail-item',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector(selectors.widget),
			intro: this.$element[0].querySelector(selectors.intro),
			introHeading: this.$element[0].querySelector(selectors.introHeading),
			introDesc: this.$element[0].querySelector(selectors.introDesc),
			introBg: this.$element[0].querySelector(selectors.introBg),
			introImages: Array.from(this.$element[0].querySelectorAll(selectors.introImages)),
			thumbWrapper: this.$element[0].querySelector(selectors.thumbWrapper),
			thumbItems: Array.from(this.$element[0].querySelectorAll(selectors.thumb)),
			titleItems: Array.from(this.$element[0].querySelectorAll(selectors.titleItems)),
			detailItems: Array.from(this.$element[0].querySelectorAll(selectors.detailItems)),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;
		this._introImageInterval = null;
		this._timeline = null;
		this._draggable = null;
		this._dragProxy = null;
		this._titleClickHandlers = null;
		this._settleOffsets = null;
		this._introScroll = null;
		this._stepScroll = null;
		this._tailScroll = null;
		this._totalScroll = null;
		this._isDragging = false;
		this._isSettling = false;
		this._dragStartTime = null;
		this._dragCurrentTime = null;
		this._dragTargetTime = null;
		this._dragTargetScroll = null;
		this._dragTick = null;
		this._settleTween = null;
		this._settleVerify = null;
		this._titleScrollTween = null;

		this.startIntroImageCycle();

		window.AvalonAddons.widget.pinStarting(this.$element);

		window.AvalonAddons.widget.whenOuterPinDone(
			this.$element,
			() => {
				this.initShowcaseAnimation();
			},
			() => this._destroyed
		);
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._introImageInterval ) {
			clearInterval(this._introImageInterval);
			this._introImageInterval = null;
		}

		this.unbindTitleNavigation();
		this.unbindThumbDrag();

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		this._settleOffsets = null;
		this._introScroll = null;
		this._stepScroll = null;
		this._tailScroll = null;
		this._totalScroll = null;
		this._isSettling = false;
		this._dragStartTime = null;
		this._dragCurrentTime = null;
		this._dragTargetTime = null;
		this._dragTargetScroll = null;
		this._titleScrollTween = null;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	startIntroImageCycle() {
		const { introImages } = this.elements;

		if (!introImages || introImages.length < 2) return;

		if (
			window.matchMedia &&
			window.matchMedia('(prefers-reduced-motion: reduce)').matches
		) {
			return;
		}

		const INTERVAL = 2000;
		let current = 0;

		this._introImageInterval = setInterval(() => {
			if ( this._destroyed ) {
				clearInterval(this._introImageInterval);
				this._introImageInterval = null;
				return;
			}

			introImages[current].classList.remove('is-active');

			current = (current + 1) % introImages.length;

			introImages[current].classList.add('is-active');
		}, INTERVAL);
	}

	bindTitleNavigation( settleOffsets ) {
		const { titleItems } = this.elements;

		this.unbindTitleNavigation();

		this._settleOffsets = settleOffsets;
		this._titleClickHandlers = [];

		titleItems.forEach((item, index) => {
			item.setAttribute('role', 'button');
			item.setAttribute('tabindex', '0');

			const onClick = (event) => {
				event.preventDefault();
				this.scrollToIndex(index);
			};

			const onKeydown = (event) => {
				if ('Enter' === event.key || ' ' === event.key) {
					event.preventDefault();
					this.scrollToIndex(index);
				}
			};

			item.addEventListener('click', onClick);
			item.addEventListener('keydown', onKeydown);

			this._titleClickHandlers.push({
				item,
				onClick,
				onKeydown,
			});
		});
	}

	unbindTitleNavigation() {
		if (!this._titleClickHandlers) return;

		this._titleClickHandlers.forEach(({ item, onClick, onKeydown }) => {
			item.removeEventListener('click', onClick);
			item.removeEventListener('keydown', onKeydown);
			item.removeAttribute('role');
			item.removeAttribute('tabindex');
		});

		this._titleClickHandlers = null;

		this.killTitleScroll();
	}

	scrollToIndex(index) {
		if (
			!this._timeline ||
			!this._timeline.scrollTrigger ||
			!this._settleOffsets
		) {
			return;
		}

		if ( this._isDragging ) {
			return;
		}

		const st = this._timeline.scrollTrigger;

		const settleIndex = Math.min(
			Math.max(index, 0),
			this._settleOffsets.length - 1
		);

		this.killSnap(st);
		this.killSettleTween();
		this._isSettling = false;

		this.animateScroll(
			st.start + this._settleOffsets[settleIndex],
			0.6
		);
	}

	/**
	 * Write an absolute scroll position through every channel the
	 * page scrolls with: the ScrollSmoother transform (when the
	 * smoother is active) and the ScrollTrigger scroller itself.
	 *
	 * Writing only one of them lets ScrollTrigger keep reading the
	 * old position, which snaps the timeline back right after a
	 * release and then replays it forward.
	 *
	 * @param {number} position Absolute scroll position.
	 */
	setScroll( position ) {
		const smoother =
			window.ScrollSmoother && window.ScrollSmoother.get();

		if ( smoother ) {
			smoother.scrollTo( position, false );
		}

		const st =
			this._timeline && this._timeline.scrollTrigger;

		if ( st ) {
			st.scroll( position );
		} else if ( ! smoother ) {
			window.scrollTo( 0, position );
		}
	}

	killTitleScroll() {
		if ( ! this._titleScrollTween ) {
			return;
		}

		this._titleScrollTween.kill();
		this._titleScrollTween = null;
	}

	/**
	 * Ease the page to an absolute position.
	 *
	 * ScrollTrigger follows the scroll while it animates, so the
	 * timeline is driven by the same eased value instead of
	 * snapping to the destination in a single frame.
	 *
	 * @param {number} position Absolute scroll position.
	 * @param {number} [duration] Duration in seconds.
	 */
	animateScroll( position, duration ) {
		this.killTitleScroll();

		const st =
			this._timeline && this._timeline.scrollTrigger;
		const from = st ? st.scroll() : window.pageYOffset;

		if ( Math.abs( position - from ) < 2 ) {
			this.setScroll( position );
			return;
		}

		const state = { y: from };

		this._titleScrollTween = gsap.to( state, {
			y: position,
			duration: duration || 0.6,
			ease: 'power2.out',
			onUpdate: () => {
				if ( this._destroyed ) {
					return;
				}

				this.setScroll( state.y );
			},
			onComplete: () => {
				this._titleScrollTween = null;

				if ( this._destroyed ) {
					return;
				}

				this.setScroll( position );
			},
		} );
	}

	/**
	 * Interpolate the visual timeline toward the drag target each frame.
	 *
	 * Draggable events do not line up with render frames, so writing
	 * timeline.time() directly on every pointermove feels steppy.
	 * Lerping on the gsap ticker keeps the motion fluid.
	 */
	startDragTicker() {
		if ( this._dragTick ) {
			return;
		}

		this._dragTick = ( time, deltaTime ) => {
			if (
				this._destroyed ||
				! this._isDragging ||
				! this._timeline
			) {
				return;
			}

			const target = this._dragTargetTime;
			const current = this._dragCurrentTime;

			if ( target === null || current === null || current === target ) {
				return;
			}

			const dt = Math.min( deltaTime || 16.7, 64 ) / 1000;
			const smoothing = 1 - Math.exp( -dt / 0.05 );
			let next = current + ( target - current ) * smoothing;

			if ( Math.abs( target - next ) < 0.001 ) {
				next = target;
			}

			this._dragCurrentTime = next;
			this._timeline.time( next );
		};

		gsap.ticker.add( this._dragTick );
	}

	stopDragTicker() {
		if ( ! this._dragTick ) {
			return;
		}

		gsap.ticker.remove( this._dragTick );
		this._dragTick = null;
	}

	killSettleTween() {
		this.stopSettleVerify();

		if ( this._settleTween ) {
			this._settleTween.kill();
			this._settleTween = null;
		}
	}

	stopSettleVerify() {
		if ( ! this._settleVerify ) {
			return;
		}

		gsap.ticker.remove( this._settleVerify );
		this._settleVerify = null;
	}

	/**
	 * Hold the settle lock until ScrollTrigger really reports the
	 * settle position.
	 *
	 * ScrollSmoother keeps a scrubbed scroll value of its own, so
	 * right after our write it can still hold the position the drag
	 * started from. Unlocking at that moment makes ScrollTrigger
	 * push the timeline back to the drag start and then replay it
	 * forward while the smoother catches up.
	 *
	 * @param {number} nearest Target timeline time.
	 * @param {Object} st ScrollTrigger instance.
	 */
	startSettleVerify( nearest, st ) {
		this.stopSettleVerify();

		const target = st.start + nearest;
		let stableFrames = 0;
		let totalFrames = 0;

		this._settleVerify = () => {
			if (
				this._destroyed ||
				! this._timeline ||
				! this._timeline.scrollTrigger
			) {
				this.stopSettleVerify();
				this._isSettling = false;
				return;
			}

			/*
			 * The guard is still on, so the visual can never be
			 * overwritten while we wait for the scroll channels.
			 */
			this._timeline.time( nearest );

			if ( Math.abs( st.scroll() - target ) > 2 ) {
				this.setScroll( target );
				stableFrames = 0;
			} else if ( ++stableFrames >= 10 ) {
				this.stopSettleVerify();
				this._isSettling = false;

				ScrollTrigger.update();
				this._timeline.time( nearest );
				this.resetDragState();
				return;
			}

			if ( ++totalFrames > 150 ) {
				this.setScroll( target );
				this.stopSettleVerify();
				this._isSettling = false;

				ScrollTrigger.update();
				this._timeline.time( nearest );
				this.resetDragState();
			}
		};

		gsap.ticker.add( this._settleVerify );
	}

	resetDragState() {
		this._dragStartTime = null;
		this._dragCurrentTime = null;
		this._dragTargetTime = null;
		this._dragTargetScroll = null;
	}

	/**
	 * Lock the timeline to a settle position and start the verify
	 * phase.
	 *
	 * The scroll write goes through both scroll channels while the
	 * guard is still on; the guard is only released once
	 * ScrollTrigger reports the settle position itself, so it can
	 * never observe the drag start and drag the timeline back to it.
	 *
	 * @param {number} nearest Target timeline time.
	 * @param {Object} st ScrollTrigger instance.
	 */
	finishSettle( nearest, st ) {
		if (
			this._destroyed ||
			! this._timeline ||
			! this._timeline.scrollTrigger
		) {
			this._isSettling = false;
			return;
		}

		this.setScroll( st.start + nearest );

		this._timeline.time( nearest );

		this.startSettleVerify( nearest, st );
	}

	getActiveIndex() {
		const { thumbItems } = this.elements;

		const index = thumbItems.findIndex(
			(thumb) => thumb.classList.contains('is-active')
		);

		return index < 0 ? 0 : index;
	}

	/**
	 * Kill only the currently running ScrollTrigger snap.
	 *
	 * getTween(true) returns the snap tween.
	 */
	killSnap(st) {
		if (!st || typeof st.getTween !== 'function') return;

		const snapTween = st.getTween(true);

		if (snapTween) {
			snapTween.kill();
		}
	}

	/**
	 * Find the nearest predefined settle position.
	 */
	getNearestSettleTime(time) {
		const offsets = this._settleOffsets;

		if (!offsets || !offsets.length) {
			return 0;
		}

		let nearest = offsets[0];

		offsets.forEach((offset) => {
			if (
				Math.abs(offset - time) <
				Math.abs(nearest - time)
			) {
				nearest = offset;
			}
		});

		return nearest;
	}

	bindThumbDrag(settleOffsets) {
		const {
			widget,
			thumbWrapper,
			thumbItems,
	} = this.elements;

		if (
			!widget ||
			!thumbWrapper ||
			!thumbItems.length ||
			!this._timeline ||
			!this._timeline.scrollTrigger
		) {
			return;
		}

		if (typeof Draggable === 'undefined') {
			return;
		}

		this.unbindThumbDrag();

		this._settleOffsets = settleOffsets;

		const self = this;

		const dirSign =
			document.documentElement.dir === 'rtl'
				? -1
				: 1;

		const st = this._timeline.scrollTrigger;

		const proxy = document.createElement('div');

		proxy.setAttribute('aria-hidden', 'true');

		proxy.style.cssText = [
			'position:absolute',
			'top:0',
			'left:0',
			'width:1px',
			'height:1px',
			'opacity:0',
			'pointer-events:none',
		].join(';');

		widget.appendChild(proxy);

		let startX = 0;
		let startScroll = 0;
		let scrollPerPx = 1;
		let moved = false;

		const draggables = Draggable.create(proxy, {
			type: 'x',

			trigger: thumbWrapper,

			allowNativeTouchScrolling: false,

			dragClickables: true,

			minimumMovement: 4,

			onPress() {
				if (
					!self._timeline ||
					!self._timeline.scrollTrigger ||
					!self._stepScroll
				) {
					return;
				}

				self.killSnap(st);

				const wasSettling = self._isSettling;

				self.killSettleTween();
				self.killTitleScroll();
				self._isSettling = false;

				self._isDragging = true;

				thumbWrapper.classList.add(
					'is-dragging'
				);

				let desiredScroll = null;

				/*
				 * A settle was interrupted: bring the page scroll
				 * to what is already on screen so the drag starts
				 * from the visual position instead of snapping back.
				 */
				if (wasSettling) {
					const duration =
						self._timeline.duration();
					const progress = duration
						? self._timeline.time() /
						duration
						: 0;

					desiredScroll =
						st.start +
						progress *
						(st.end - st.start);
				}

				/*
				 * Make sure the showcase is already inside
				 * the thumbnail section.
				 */
				const minimumScroll =
					st.start +
					self._introScroll;

				if (
					desiredScroll === null &&
					st.scroll() < minimumScroll
				) {
					desiredScroll = minimumScroll;
				}

				if (desiredScroll !== null) {
					self.setScroll(desiredScroll);
				}

				/*
				 * Store the current real scroll position.
				 * It will NOT be changed during drag.
				 */
				startScroll = st.scroll();

				startX = this.x;

				moved = false;

				const stepWidth =
					(
						thumbItems[0] &&
						thumbItems[0].offsetWidth
					) ||
					thumbWrapper.offsetWidth ||
					300;

				const dragPerStep = Math.min(
					Math.max(
						stepWidth * 0.6,
						220
					),
					480
				);

				scrollPerPx =
					self._stepScroll /
					dragPerStep;

				/*
				 * Store the timeline position corresponding
				 * to the current scroll position, and keep the
				 * visual in sync right away so nothing jumps on
				 * the first drag movement.
				 */
				self._dragStartTime =
					(
						startScroll -
						st.start
					) /
					(st.end - st.start) *
					self._timeline.duration();

				self._dragCurrentTime =
					self._dragStartTime;

				self._dragTargetTime =
					self._dragStartTime;

				self._dragTargetScroll =
					startScroll;

				self._timeline.time(
					self._dragStartTime
				);

				self.startDragTicker();
			},

			onDrag() {
				if (
					!self._isDragging ||
					!self._timeline ||
					!self._timeline.scrollTrigger
				) {
					return;
				}

				const offsets =
					self._settleOffsets;

				if (!offsets || !offsets.length) {
					return;
				}

				/*
				 * Draggable is now only an input device.
				 *
				 * The actual page scroll is NOT changed here.
				 */
				const dragDelta =
					(this.x - startX) *
					dirSign;

				const minScroll =
					st.start +
					offsets[0];

				const maxScroll =
					st.start +
					offsets[
						offsets.length - 1
					];

				const targetScroll =
					startScroll -
					dragDelta *
					scrollPerPx;

				const clampedScroll =
					Math.min(
						Math.max(
							targetScroll,
							minScroll
						),
						maxScroll
					);

				const progress =
					(
						clampedScroll -
						st.start
					) /
					(st.end - st.start);

				const clampedProgress =
					Math.min(
						Math.max(progress, 0),
						1
					);

				const targetTime =
					clampedProgress *
					self._timeline.duration();

				/*
				 * Only record the target here. The ticker
				 * interpolates the visual timeline toward it
				 * on render frames, so the motion stays smooth
				 * no matter how pointer events line up with
				 * frames, and ScrollTrigger never sees a new
				 * scroll position during drag (no feedback
				 * loop, no visual jitter).
				 */
				self._dragTargetTime = targetTime;

				moved = true;
			},

			onDragEnd() {
				const wasMoved = moved;

				gsap.set(proxy, {
					x: 0,
				});

				self.stopDragTicker();
				self._isDragging = false;

				thumbWrapper.classList.remove(
					'is-dragging'
				);

				if (!wasMoved) {
					self._dragStartTime = null;
					self._dragCurrentTime = null;
					self._dragTargetTime = null;
					self._dragTargetScroll = null;

					return;
				}

				if (
					!self._timeline ||
					!self._timeline.scrollTrigger
				) {
					return;
				}

				const offsets =
					self._settleOffsets;

				if (!offsets || !offsets.length) {
					return;
				}

				/*
				 * Aim from the pointer's true target so a fast
				 * flick released a frame early still lands on
				 * the item the user was pointing at.
				 */
				const intentTime =
					self._dragTargetTime !== null
						? self._dragTargetTime
						: self._timeline.time();

				const visualTime =
					self._dragCurrentTime !== null
						? self._dragCurrentTime
						: self._timeline.time();

				const nearest =
					self.getNearestSettleTime(
						intentTime
					);

				/*
				 * Keep ScrollTrigger's onUpdate suppressed while
				 * the visual eases to the settle position. The
				 * page scroll is synced only after the visual is
				 * already correct.
				 */
				self._isSettling = true;

				/*
				 * Ease the visual and the page scroll together
				 * instead of snapping the scroll once the visual
				 * has landed. Both end on the same value, so the
				 * timeline can never disagree with the position
				 * ScrollTrigger reads after the guard is lifted.
				 */
				const settleScrollFrom = st.scroll();
				const settleScrollTo = st.start + nearest;

				if (
					Math.abs(nearest - visualTime) <
						0.001 &&
					Math.abs(
						settleScrollFrom -
							settleScrollTo
					) < 2
				) {
					self.finishSettle(nearest, st);
					return;
				}

				const settleState = {
					t: visualTime,
					y: settleScrollFrom,
				};

				self._settleTween = gsap.to(
					settleState,
					{
						t: nearest,
						y: settleScrollTo,
						duration: 0.5,
						ease: 'power2.out',
						onUpdate() {
							if (
								self._destroyed ||
								!self._timeline
							) {
								return;
							}

							self._timeline.time(
								settleState.t
							);
							self._dragCurrentTime =
								settleState.t;

							self.setScroll(
								settleState.y
							);
						},
						onComplete() {
							self._settleTween = null;
							self.finishSettle(
								nearest,
								st
							);
						},
					}
				);
			},
		});

		this._draggable =
			draggables[0] || null;

		this._dragProxy = proxy;
	}

	unbindThumbDrag() {
		this.stopDragTicker();
		this.killSettleTween();

		this._isDragging = false;
		this._isSettling = false;

		if (
			this.elements &&
			this.elements.thumbWrapper
		) {
			this.elements.thumbWrapper.classList.remove(
				'is-dragging'
			);
		}

		if (this._draggable) {
			this._draggable.kill();
			this._draggable = null;
		}

		if (
			this._dragProxy &&
			this._dragProxy.parentNode
		) {
			this._dragProxy.parentNode.removeChild(
				this._dragProxy
			);
		}

		this._dragProxy = null;
		this._dragStartTime = null;
		this._dragCurrentTime = null;
		this._dragTargetTime = null;
		this._dragTargetScroll = null;
	}

	initShowcaseAnimation() {
		if (
			typeof gsap === 'undefined' ||
			typeof ScrollTrigger === 'undefined'
		) {
			return;
		}

		const isRTL =
			document.documentElement.dir === 'rtl';

		const dirSign = isRTL ? -1 : 1;

		const {
			widget,
			intro,
			introHeading,
			introDesc,
			introBg,
			thumbItems,
			titleItems,
			detailItems,
		} = this.elements;

		if (!widget || !thumbItems.length) return;

		const postCount = thumbItems.length;

		const vh =
			widget.offsetHeight ||
			window.innerHeight;

		const introScroll = Math.round(vh * 5.5 / 16);
		const stepScroll = Math.round(vh * 0.6);
		const tailScroll = Math.round(vh * 3 / 16);

		const totalScroll =
			introScroll +
			(postCount - 1) * stepScroll +
			tailScroll;

		const settleOffsets = [introScroll];

		if (postCount > 1) {
			for (
				let k = 1;
				k <= postCount - 1;
				k++
			) {
				settleOffsets.push(
					introScroll + k * stepScroll
				);
			}
		}

		this._introScroll = introScroll;
		this._stepScroll = stepScroll;
		this._tailScroll = tailScroll;
		this._totalScroll = totalScroll;

		this.mm = gsap.matchMedia();

		this.mm.add(
			'(prefers-reduced-motion: no-preference)',
			() => {
				gsap.set(thumbItems, {
					willChange: 'transform, opacity, filter',
				});

				thumbItems.forEach((thumb, i) => {
					if (0 === i) return;

					gsap.set(thumb, {
						scale: 0.7,
						opacity: 0.3,
						xPercent: dirSign * i * 100,
						yPercent: i * 50,
					});
				});

				const phase3Start = introScroll;

				const timeline = gsap.timeline({
					paused: true,
				});

				const introHold = phase3Start * 0.4;

				const introFade =
					introScroll * 1.3 / 5.5;

				if (introHeading) {
					timeline.to(
						introHeading,
						{
							autoAlpha: 0,
							duration: introFade,
						},
						introHold
					);
				}

				if (introDesc) {
					timeline.to(
						introDesc,
						{
							autoAlpha: 0,
							duration: introFade,
						},
						introHold
					);
				}

				if (introBg) {
					timeline.to(
						introBg,
						{
							scale: 0.5,
							autoAlpha: 0,
							duration:
								phase3Start -
								introHold,
							ease: 'power2.inOut',
						},
						introHold
					);
				}

				if (intro) {
					timeline.to(
						intro,
						{
							css: {
								pointerEvents: 'none',
							},
							duration: 0,
						},
						phase3Start
					);
				}

				const setActiveIndex =
					(activeIdx) => {
						thumbItems.forEach((thumb, i) => {
							thumb.classList.toggle(
								'is-active',
								i === activeIdx
							);
						});

						titleItems.forEach((item, i) => {
							item.classList.toggle(
								'is-active',
								i === activeIdx
							);
						});

						detailItems.forEach((item, i) => {
							item.classList.toggle(
								'is-active',
								i === activeIdx
							);
						});
					};

				timeline.eventCallback(
					'onUpdate',
					() => {
						const currentTime =
							timeline.time();

						if (
							currentTime < phase3Start ||
							postCount <= 1
						) {
							setActiveIndex(0);
							return;
						}

						const elapsed =
							currentTime -
							phase3Start;

						const activeStep =
							Math.min(
								Math.floor(
									(
										elapsed -
										stepScroll * 0.5
									) /
									stepScroll
								),
								postCount - 2
							);

						setActiveIndex(
							Math.max(
								activeStep + 1,
								0
							)
						);
					}
				);

				const stepXOffset = 100;
				const stepYOffset = 50;

				if (postCount > 1) {
					for (
						let step = 0;
						step < postCount - 1;
						step++
					) {
						const t =
							phase3Start +
							step * stepScroll;

						thumbItems.forEach((thumb, j) => {
							const targetXPercent =
								(
									j -
									step -
									1
								) * stepXOffset;

							const targetYPercent =
								(
									j -
									step -
									1
								) * stepYOffset;

							const isCenter =
								j === step + 1;

							const isExited =
								j <= step;

							timeline.to(
								thumb,
								{
									xPercent:
										dirSign *
										targetXPercent,

									yPercent:
										targetYPercent,

									opacity:
										isCenter
											? 1
											: (
												isExited
													? 0.3
													: 0.3
											),

									scale:
										isCenter
											? 1
											: 0.7,

									duration:
										stepScroll,

									ease:
										'none',
								},
								t
							);
						});
					}
				}

				timeline.to(
					{},
					{
						duration: tailScroll,
					}
				);

				const st =
					ScrollTrigger.create({
						trigger: widget,

						start: 'top top',

						end:
							'+=' +
							totalScroll,

						pin: true,

						invalidateOnRefresh: true,

						fastScrollEnd: false,

						onUpdate: (self) => {
							/*
							 * While dragging or settling, the timeline is
							 * controlled directly by Draggable / the
							 * settle tween. Do not overwrite it with the
							 * old ScrollTrigger position.
							 */
							if (this._isDragging || this._isSettling) {
								return;
							}

							timeline.time(
								self.progress *
								timeline.duration()
							);
						},

						/*
						 * ScrollTrigger snap is intentionally disabled.
						 *
						 * Drag release performs its own exact settle
						 * operation so there is only one controller.
						 */
					});

				timeline.scrollTrigger = st;

				this._timeline = timeline;

				this.bindTitleNavigation(
					settleOffsets
				);

				this.bindThumbDrag(
					settleOffsets
				);

				return () => {
					this.unbindTitleNavigation();
					this.unbindThumbDrag();
				};
			}
		);

		window.AvalonAddons.widget.pinReady(
			this.$element
		);
	}
}

window.addEventListener(
	'elementor/frontend/init',
	() => {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/avalon-posts-showcase.default',
			($element) => {
				elementorFrontend.elementsHandler.addHandler(
					AvalonPostsShowcaseHandler,
					{
						$element,
					}
				);
			}
		);
	}
);