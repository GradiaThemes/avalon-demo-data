class AvalonPostsShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-posts-showcase',
				intro: '.avalon-posts-showcase__intro',
				introHeading: '.avalon-posts-showcase__intro-heading',
				introDesc: '.avalon-posts-showcase__intro-desc',
				introBg: '.avalon-posts-showcase__intro-bg',
				items: '.avalon-posts-showcase__items',
				thumbWrapper: '.avalon-posts-showcase__thumb-wrapper',
				thumb: '.avalon-posts-showcase__thumb',
				titles: '.avalon-posts-showcase__titles',
				titleItems: '.avalon-posts-showcase__title-item',
				details: '.avalon-posts-showcase__details',
				detailItems: '.avalon-posts-showcase__detail-item',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			intro: this.$element[0].querySelector( selectors.intro ),
			introHeading: this.$element[0].querySelector( selectors.introHeading ),
			introDesc: this.$element[0].querySelector( selectors.introDesc ),
			introBg: this.$element[0].querySelector( selectors.introBg ),
			thumbWrapper: this.$element[0].querySelector( selectors.thumbWrapper ),
			thumbItems: Array.from( this.$element[0].querySelectorAll( selectors.thumb ) ),
			titleItems: Array.from( this.$element[0].querySelectorAll( selectors.titleItems ) ),
			detailItems: Array.from( this.$element[0].querySelectorAll( selectors.detailItems ) ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			// Check if outer pin is still active - if so, wait for it to finish
			// before creating the widget's own pin (for default "outer first" behavior).
			this.initShowcaseAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		this.unbindTitleNavigation();
		this.unbindThumbDrag();

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		this._settleTimes = null;
		this._phase3Start = null;
		this._stepDuration = null;

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	bindTitleNavigation( settleTimes ) {
		const { titleItems } = this.elements;

		this.unbindTitleNavigation();
		this._settleTimes = settleTimes;
		this._titleClickHandlers = [];

		titleItems.forEach( ( item, index ) => {
			item.setAttribute( 'role', 'button' );
			item.setAttribute( 'tabindex', '0' );

			const onClick = ( event ) => {
				event.preventDefault();
				this.scrollToIndex( index );
			};

			const onKeydown = ( event ) => {
				if ( 'Enter' === event.key || ' ' === event.key ) {
					event.preventDefault();
					this.scrollToIndex( index );
				}
			};

			item.addEventListener( 'click', onClick );
			item.addEventListener( 'keydown', onKeydown );
			this._titleClickHandlers.push( { item, onClick, onKeydown } );
		} );
	}

	unbindTitleNavigation() {
		if ( ! this._titleClickHandlers ) {
			return;
		}

		this._titleClickHandlers.forEach( ( { item, onClick, onKeydown } ) => {
			item.removeEventListener( 'click', onClick );
			item.removeEventListener( 'keydown', onKeydown );
			item.removeAttribute( 'role' );
			item.removeAttribute( 'tabindex' );
		} );

		this._titleClickHandlers = null;
	}

	scrollToIndex( index ) {
		if ( ! this._timeline || ! this._timeline.scrollTrigger || ! this._settleTimes ) {
			return;
		}

		const scrollTrigger = this._timeline.scrollTrigger;
		const timelineDuration = this._timeline.duration();

		if ( ! timelineDuration ) {
			return;
		}

		const settleIndex = Math.min( Math.max( index, 0 ), this._settleTimes.length - 1 );
		const progress = Math.min(
			Math.max( this._settleTimes[ settleIndex ] / timelineDuration, 0 ),
			1
		);
		const targetScroll = scrollTrigger.start + progress * ( scrollTrigger.end - scrollTrigger.start );

		window.scrollTo( {
			top: targetScroll,
			behavior: 'smooth',
		} );
	}

	getActiveIndex() {
		const { thumbItems } = this.elements;
		const index = thumbItems.findIndex( ( thumb ) => thumb.classList.contains( 'is-active' ) );

		return index < 0 ? 0 : index;
	}

	bindThumbDrag( settleTimes ) {
		const { widget, thumbWrapper, thumbItems } = this.elements;

		if ( ! widget || ! thumbWrapper || ! thumbItems.length || ! this._timeline ) {
			return;
		}

		if ( typeof Draggable === 'undefined' ) {
			return;
		}

		if ( ! this._timeline || ! this._timeline.scrollTrigger ) {
			return;
		}

		this.unbindThumbDrag();
		this._settleTimes = settleTimes;

		const self = this;
		const dirSign = document.documentElement.dir === 'rtl' ? -1 : 1;
		const st = this._timeline.scrollTrigger;
		const duration = this._timeline.duration();

		// Invisible proxy so Draggable never transforms the layout.
		const proxy = document.createElement( 'div' );
		proxy.setAttribute( 'aria-hidden', 'true' );
		proxy.style.cssText = 'position:absolute;top:0;left:0;width:1px;height:1px;opacity:0;pointer-events:none;';
		widget.appendChild( proxy );

		let startTime = 0;
		let timePerPx = 1;

		const getScrollFromTime = ( timeValue ) => {
			if ( ! st || ! duration ) {
				return 0;
			}

			const progress = Math.min( Math.max( timeValue / duration, 0 ), 1 );

			return st.start + progress * ( st.end - st.start );
		};

		const draggables = Draggable.create( proxy, {
			type: 'x',
			trigger: thumbWrapper,
			allowNativeTouchScrolling: false,
			dragClickables: true,
			onPress() {
				if ( ! self._timeline || ! self._timeline.scrollTrigger ) {
					return;
				}

				const timelineDuration = self._timeline.duration();
				const phaseStart = settleTimes[ 0 ];

				// Jump into cycle once on press so the first drag moves thumbs (not intro).
				if ( self._timeline.time() < phaseStart ) {
					const progress = Math.min( Math.max( phaseStart / timelineDuration, 0 ), 1 );
					st.scroll( st.start + progress * ( st.end - st.start ) );
				}

				startTime = Math.max( self._timeline.time(), phaseStart );

				// Pixels of pointer travel per one item step — larger = slower/finer.
				const stepTime = settleTimes.length > 1
					? ( settleTimes[1] - settleTimes[0] )
					: timelineDuration;
				const stepWidth = ( thumbItems[ 0 ] && thumbItems[ 0 ].offsetWidth )
					|| thumbWrapper.offsetWidth
					|| 300;
				const dragPerStep = Math.min( Math.max( stepWidth * 0.6, 220 ), 480 );

				timePerPx = stepTime / dragPerStep;

				self._isDragging = true;
				thumbWrapper.classList.add( 'is-dragging' );
			},
			onDrag() {
				if ( ! self._timeline ) {
					return;
				}

				// Never call st.scroll() mid-drag — only drive timeline time.
				// LTR: drag left (this.x decreases) → next.
				const dragDelta = this.startX - this.x;
				const targetTime = startTime + ( dragDelta * dirSign * timePerPx );
				const clamped = Math.min( Math.max( targetTime, 0 ), self._timeline.duration() );

				self._timeline.time( clamped );
			},
			onRelease() {
				// Click without drag never fires onDragEnd — flag cleared in onDragEnd.
			},
			onDragEnd() {
				gsap.set( proxy, { x: 0 } );

				if ( ! self._timeline || ! self._timeline.scrollTrigger || ! self._settleTimes ) {
					self._isDragging = false;
					thumbWrapper.classList.remove( 'is-dragging' );
					return;
				}

				const time = self._timeline.time();

				// Nearest settle time — matches ScrollTrigger's snapTo logic exactly.
				let nearestIndex = 0;
				let nearestDiff = Infinity;

				self._settleTimes.forEach( ( settleTime, index ) => {
					const diff = Math.abs( settleTime - time );

					if ( diff < nearestDiff ) {
						nearestDiff = diff;
						nearestIndex = index;
					}
				} );

				const targetTime = self._settleTimes[ nearestIndex ];

				// Sync timeline + scroll position.
				self._timeline.time( targetTime );
				self._timeline.scrollTrigger.scroll( getScrollFromTime( targetTime ) );

				// Keep _isDragging guard alive longer than ScrollTrigger's snap delay (80ms)
				// + max snap duration (400ms) to prevent its internal snap tween from
				// fighting with our manual snap via onUpdate.
				clearTimeout( self._dragEndGuardTimer );
				self._dragEndGuardTimer = setTimeout( () => {
					self._isDragging = false;
					thumbWrapper.classList.remove( 'is-dragging' );
				}, 500 );
			},
		} );

		this._draggable = draggables[0] || null;
		this._dragProxy = proxy;
	}

	unbindThumbDrag() {
		if ( this._draggable ) {
			this._draggable.kill();
			this._draggable = null;
		}

		if ( this._dragProxy && this._dragProxy.parentNode ) {
			this._dragProxy.parentNode.removeChild( this._dragProxy );
		}

		this._dragProxy = null;

		if ( this.elements && this.elements.thumbWrapper ) {
			this.elements.thumbWrapper.classList.remove( 'is-dragging' );
		}

		clearTimeout( this._dragEndGuardTimer );
		this._dragEndGuardTimer = null;

		this._isDragging = false;
	}

	initShowcaseAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const isRTL = document.documentElement.dir === 'rtl';
		const dirSign = isRTL ? -1 : 1;
		const { widget, intro, introHeading, introDesc, introBg, thumbItems, titleItems, detailItems } = this.elements;

		if ( ! widget || ! thumbItems.length ) {
			return;
		}

		const postCount = thumbItems.length;

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			gsap.set( thumbItems, { willChange: 'transform, opacity' } );

			// Hide all items except first
			thumbItems.forEach( ( thumb, i ) => {
				if ( 0 === i ) {
					return;
				}
				gsap.set( thumb, {
					scale: 0.7,
					opacity: 0.3,
					xPercent: dirSign * i * 100,
					yPercent: i * 50,
					filter: 'grayscale(100%)',
				} );
			} );

			const phase3Start   = 5.5;
			const stepDuration  = postCount > 1 ? 7.5 / ( postCount - 1 ) : 0;
			const settleTimes   = [ phase3Start ];

			if ( postCount > 1 ) {
				for ( let k = 1; k <= postCount - 1; k++ ) {
					settleTimes.push( phase3Start + k * stepDuration );
				}
			}

			// No scrub — ScrollTrigger drives time via onUpdate so drag can own
			// timeline.time() mid-drag without fighting a scrub tween. Paused so
			// it doesn't auto-play; progress comes only from scroll/drag.
			const timeline = gsap.timeline( { paused: true } );

			// Phase 1: Fade out intro text and shrink background (0% -> 40%)
			if ( introHeading ) {
				timeline.to( introHeading, { autoAlpha: 0, duration: 2 }, 0 );
			}
			if ( introDesc ) {
				timeline.to( introDesc, { autoAlpha: 0, duration: 2 }, 0 );
			}
			if ( introBg ) {
				timeline.to( introBg, { scale: 0.5, autoAlpha: 0, duration: 4, ease: 'power2.inOut' }, 0 );
			}
			if ( intro ) {
				timeline.to( intro, { css: { pointerEvents: 'none' }, duration: 0 }, 4 );
			}

			// Phase 3: Cycle through remaining posts (55% -> 100%)
			const stepXOffset = 100;
			const stepYOffset = 50;

			const setActiveIndex = ( activeIdx ) => {
				thumbItems.forEach( ( thumb, i ) => {
					thumb.classList.toggle( 'is-active', i === activeIdx );
				} );

				titleItems.forEach( ( item, i ) => {
					item.classList.toggle( 'is-active', i === activeIdx );
				} );

				detailItems.forEach( ( item, i ) => {
					item.classList.toggle( 'is-active', i === activeIdx );
				} );
			};

			timeline.eventCallback( 'onUpdate', () => {
				const currentTime = timeline.time();

				if ( currentTime < phase3Start || postCount <= 1 ) {
					setActiveIndex( 0 );
				} else {
					const elapsed = currentTime - phase3Start;
					const activeStep = Math.min(
						Math.floor( ( elapsed - stepDuration * 0.5 ) / stepDuration ),
						postCount - 2 );
					setActiveIndex( Math.max( activeStep + 1, 0 ) );
				}
			} );

			if ( postCount > 1 ) {
				for ( let step = 0; step < postCount - 1; step++ ) {
					const t = phase3Start + ( step * stepDuration );

					thumbItems.forEach( ( thumb, j ) => {
						const targetXPercent = ( j - step - 1 ) * stepXOffset;
						const targetYPercent = ( j - step - 1 ) * stepYOffset;
						const isCenter      = j === step + 1;
						const isExited      = j <= step;

						timeline.to( thumb, {
							xPercent: dirSign * targetXPercent,
							yPercent: targetYPercent,
							opacity: isCenter ? 1 : ( isExited ? 0.3 : 0.3 ),
							scale: isCenter ? 1 : 0.7,
							filter: isCenter ? 'grayscale(0%)' : 'grayscale(100%)',
							duration: stepDuration,
							ease: 'power2.inOut',
						}, t );
					} );
				}
			}

			// Extra dead time at end — keeps pin active longer without affecting item mapping.
			// ~3s extra ≈ 1.5 viewport scroll at normal speed.
			const pinBuffer = 3;
			timeline.to( {}, { duration: pinBuffer } );

			// Attach ScrollTrigger AFTER timeline is built so duration is final.
			// onUpdate mirrors scrub:true while letting drag own time mid-drag.
			const st = ScrollTrigger.create( {
				trigger: widget,
				start: 'top top',
				pin: true,
				onUpdate: ( self ) => {
					if ( this._isDragging ) {
						return;
					}

					timeline.time( self.progress * timeline.duration() );
				},
				snap: {
					snapTo: ( progressValue ) => {
						// No snap while dragging — drag end picks the settle point.
						if ( this._isDragging ) {
							return progressValue;
						}

						const time = progressValue * timeline.duration();

						// Intro phase: free scroll, no snap.
						if ( time < phase3Start ) {
							return progressValue;
						}

						// Cycle phase: snap to nearest settled item.
						let nearest = settleTimes[ 0 ];
						settleTimes.forEach( ( t ) => {
							if ( Math.abs( t - time ) < Math.abs( nearest - time ) ) {
								nearest = t;
							}
						} );

						return nearest / timeline.duration();
					},
					duration: { min: 0.15, max: 0.4 },
					delay: 0.08,
					ease: 'power1.inOut',
				},
			} );

			// Keep timeline.scrollTrigger for existing cleanup / scrollToIndex paths.
			timeline.scrollTrigger = st;

			this._timeline = timeline;
			this.bindTitleNavigation( settleTimes );
			this.bindThumbDrag( settleTimes );

			return () => {
				this.unbindTitleNavigation();
				this.unbindThumbDrag();
			};
		} );

		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-posts-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonPostsShowcaseHandler,
				{ $element }
			);
		}
	);
} );
