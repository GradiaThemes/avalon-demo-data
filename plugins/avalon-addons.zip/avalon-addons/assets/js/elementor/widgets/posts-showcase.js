class AvalonPostsShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-posts-showcase',
				intro: '.avalon-posts-showcase__intro',
				introHeading: '.avalon-posts-showcase__intro-heading',
				introDesc: '.avalon-posts-showcase__intro-desc',
				introBg: '.avalon-posts-showcase__intro-bg',
				items: '.avalon-posts-showcase__items',
				thumbWrapper: '.avalon-posts-showcase__thumb-wrapper',
				thumb: '.avalon-posts-showcase__thumb',
				titles: '.avalon-posts-showcase__titles',
				titleItems: '.avalon-posts-showcase__title-item',
				details: '.avalon-posts-showcase__details',
				detailItems: '.avalon-posts-showcase__detail-item',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			intro: this.$element[0].querySelector( selectors.intro ),
			introHeading: this.$element[0].querySelector( selectors.introHeading ),
			introDesc: this.$element[0].querySelector( selectors.introDesc ),
			introBg: this.$element[0].querySelector( selectors.introBg ),
			thumbWrapper: this.$element[0].querySelector( selectors.thumbWrapper ),
			thumbItems: Array.from( this.$element[0].querySelectorAll( selectors.thumb ) ),
			titleItems: Array.from( this.$element[0].querySelectorAll( selectors.titleItems ) ),
			detailItems: Array.from( this.$element[0].querySelectorAll( selectors.detailItems ) ),
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			// Check if outer pin is still active - if so, wait for it to finish
			// before creating the widget's own pin (for default "outer first" behavior).
			this.initShowcaseAnimation();
		} , () => this._destroyed );
	}

	onDestroy() {
		this._destroyed = true;

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	initShowcaseAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const isRTL = document.documentElement.dir === 'rtl';
		const dirSign = isRTL ? -1 : 1;
		const { widget, intro, introHeading, introDesc, introBg, thumbItems, titleItems, detailItems } = this.elements;

		if ( ! widget || ! thumbItems.length ) {
			return;
		}

		const postCount = thumbItems.length;

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			gsap.set( thumbItems, { willChange: 'transform, opacity' } );

			// Hide all items except first
			thumbItems.forEach( ( thumb, i ) => {
				if ( 0 === i ) {
					return;
				}
				gsap.set( thumb, {
					scale: 0.7,
					opacity: 0.3,
					xPercent: dirSign * i * 100,
					yPercent: i * 50,
					filter: 'grayscale(100%)',
				} );
			} );

			const timeline = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					scrub: true,
					pin: true,
				},
			} );

			// Phase 1: Fade out intro text and shrink background (0% -> 40%)
			if ( introHeading ) {
				timeline.to( introHeading, { autoAlpha: 0, duration: 2 }, 0 );
			}
			if ( introDesc ) {
				timeline.to( introDesc, { autoAlpha: 0, duration: 2 }, 0 );
			}
			if ( introBg ) {
				timeline.to( introBg, { scale: 0.5, autoAlpha: 0, duration: 4, ease: 'power2.inOut' }, 0 );
			}

			// Phase 3: Cycle through remaining posts (55% -> 100%)
			if ( postCount > 1 ) {
				const stepDuration = 7.5 / ( postCount - 1 );
				const stepXOffset   = 100;
				const stepYOffset   = 50;

				for ( let step = 0; step < postCount - 1; step++ ) {
					const t = 5.5 + ( step * stepDuration );

					thumbItems.forEach( ( thumb, j ) => {
						const targetXPercent = ( j - step - 1 ) * stepXOffset;
						const targetYPercent = ( j - step - 1 ) * stepYOffset;
						const isCenter      = j === step + 1;
						const isExited      = j <= step;

						timeline.to( thumb, {
							xPercent: dirSign * targetXPercent,
							yPercent: targetYPercent,
							opacity: isCenter ? 1 : ( isExited ? 0.3 : 0.3 ),
							scale: isCenter ? 1 : 0.7,
							filter: isCenter ? 'grayscale(0%)' : 'grayscale(100%)',
							duration: stepDuration,
							ease: 'power2.inOut',
						}, t );
					} );

					// Title: toggle is-active class
					const setActiveIndex = ( activeIdx ) => {
						thumbItems.forEach( ( thumb, i ) => {
							thumb.classList.toggle( 'is-active', i === activeIdx );
						});

						titleItems.forEach( ( item, i ) => {
							item.classList.toggle( 'is-active', i === activeIdx );
						} );

						detailItems.forEach( ( item, i ) => {
							item.classList.toggle( 'is-active', i === activeIdx );
						} );
					};

					timeline.eventCallback( 'onUpdate', () => {
						const currentTime = timeline.time();
						const phase3Start = 5.5;

						if ( currentTime < phase3Start ) {
							setActiveIndex( 0 );
						} else {
							const elapsed = currentTime - phase3Start;
							const activeStep = Math.min(
							Math.floor( ( elapsed - stepDuration * 0.5 ) / stepDuration ),
							postCount - 2 );
							setActiveIndex( Math.max( activeStep + 1, 0 ) );
						}
					} );
				}
			}

			this._timeline = timeline;
		} );

		window.AvalonAddons.widget.pinReady( this.$element );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-posts-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonPostsShowcaseHandler,
				{ $element }
			);
		}
	);
} );
