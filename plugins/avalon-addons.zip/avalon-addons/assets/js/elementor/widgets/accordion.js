class AvalonAccordionHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.avalon-accordion',
				items: '.avalon-accordion__item',
				title: '.avalon-accordion__title',
				content: '.avalon-accordion__content',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			wrapper: this.$element[0].querySelector( selectors.wrapper ),
			items: [ ...this.$element[0].querySelectorAll( selectors.items ) ],
			titles: [ ...this.$element[0].querySelectorAll( selectors.title ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this.elements.titles.forEach( ( title ) => {
			title.addEventListener( 'click', ( e ) => this.toggleItem( e ) );

			title.addEventListener( 'keydown', ( e ) => {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					this.toggleItem( e );
				}
			} );
		} );
	}

	slideDown( content ) {
		content.style.display = 'block';
		const height = content.scrollHeight;
		content.style.height = '0px';

		// Force reflow.
		content.offsetHeight;

		content.style.transition = 'height 0.3s ease';
		content.style.height = height + 'px';

		const onEnd = () => {
			content.removeEventListener( 'transitionend', onEnd );
			content.style.height = 'auto';
			content.style.overflow = '';
			content.style.transition = '';
		};

		content.addEventListener( 'transitionend', onEnd );
	}

	slideUp( content ) {
		const height = content.scrollHeight;
		content.style.height = height + 'px';
		content.style.overflow = 'hidden';

		// Force reflow.
		content.offsetHeight;

		content.style.transition = 'height 0.3s ease';
		content.style.height = '0px';

		const onEnd = () => {
			content.removeEventListener( 'transitionend', onEnd );
			content.style.display = 'none';
			content.style.height = '';
			content.style.overflow = '';
			content.style.transition = '';
		};

		content.addEventListener( 'transitionend', onEnd );
	}

	toggleItem( e ) {
		const button = e.currentTarget;
		const item = button.closest( this.getSettings( 'selectors' ).items );
		const content = item.querySelector( this.getSettings( 'selectors' ).content );
		const isActive = item.classList.contains( 'is-active' );

		// Close all other items (single-open behavior).
		this.elements.items.forEach( ( otherItem ) => {
			if ( otherItem !== item && otherItem.classList.contains( 'is-active' ) ) {
				otherItem.classList.remove( 'is-active' );
				const otherButton = otherItem.querySelector( this.getSettings( 'selectors' ).title );
				const otherContent = otherItem.querySelector( this.getSettings( 'selectors' ).content );

				if ( otherButton ) {
					otherButton.setAttribute( 'aria-expanded', 'false' );
				}
				if ( otherContent ) {
					otherContent.setAttribute( 'aria-hidden', 'true' );
					this.slideUp( otherContent );
				}
			}
		} );

		// Toggle current item.
		if ( isActive ) {
			item.classList.remove( 'is-active' );
			button.setAttribute( 'aria-expanded', 'false' );
			content.setAttribute( 'aria-hidden', 'true' );
			this.slideUp( content );
		} else {
			item.classList.add( 'is-active' );
			button.setAttribute( 'aria-expanded', 'true' );
			content.setAttribute( 'aria-hidden', 'false' );
			this.slideDown( content );
		}
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-accordion.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonAccordionHandler,
				{ $element }
			);
		}
	);
} );
