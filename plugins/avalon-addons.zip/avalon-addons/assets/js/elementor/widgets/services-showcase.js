class AvalonServicesShowcaseHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				widget: '.avalon-services-showcase',
				images: '.avalon-services-showcase__image',
				titles: '.avalon-services-showcase__title-item',
				titleCenter: '.avalon-services-showcase__titles-center .avalon-services-showcase__title > *',
				titleMobile: '.avalon-services-showcase__right .avalon-services-showcase__title > *',
				descs: '.avalon-services-showcase__descs > div',
				buttons: '.avalon-services-showcase__buttons > div',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			widget: this.$element[0].querySelector( selectors.widget ),
			images: [ ...this.$element[0].querySelectorAll( selectors.images ) ],
			titles: [ ...this.$element[0].querySelectorAll( selectors.titles ) ],
			titleCenter: [ ...this.$element[0].querySelectorAll( selectors.titleCenter ) ],
			titleMobile: [ ...this.$element[0].querySelectorAll( selectors.titleMobile ) ],
			descs: [ ...this.$element[0].querySelectorAll( selectors.descs ) ],
			buttons: [ ...this.$element[0].querySelectorAll( selectors.buttons ) ],
		};
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this._destroyed = false;

		window.AvalonAddons.widget.pinStarting( this.$element );

		window.AvalonAddons.widget.whenOuterPinDone( this.$element, () => {

			this.initAnimation();
		} , () => this._destroyed );
	}

	removeTitleClickHandlers() {
		if ( this._titleClickHandlers ) {
			this._titleClickHandlers.forEach( ( handler, i ) => {
				if ( this.elements.titles[ i ] ) {
					this.elements.titles[ i ].removeEventListener( 'click', handler );
				}
			} );
			this._titleClickHandlers = null;
		}
	}

	onDestroy() {
		this._destroyed = true;

		this.removeTitleClickHandlers();

		if ( this._timeline ) {
			if ( this._timeline.scrollTrigger ) {
				this._timeline.scrollTrigger.kill();
			}
			this._timeline.kill();
			this._timeline = null;
		}

		if ( this.mm ) {
			this.mm.revert();
			this.mm = null;
		}

		super.onDestroy();
	}

	initAnimation() {
		if ( typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' ) {
			return;
		}

		const { widget, images, titles, titleCenter, titleMobile, descs, buttons } = this.elements;

		if ( ! widget || ! images.length ) {
			return;
		}

		const count = images.length;

		this.mm = gsap.matchMedia();

		this.mm.add( '(prefers-reduced-motion: no-preference)', () => {
			const timeline = gsap.timeline( {
				scrollTrigger: {
					trigger: widget,
					start: 'top top',
					end: () => '+=' + ( count - 1 ) * widget.offsetHeight,
					scrub: true,
					pin: true,
					invalidateOnRefresh: true,
				},
			} );

			timeline.to( {}, { duration: count - 1 } );

			const setActiveIndex = ( idx ) => {
				images.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				titles.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				titleCenter.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				titleMobile.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				descs.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
				buttons.forEach( ( el, i ) => el.classList.toggle( 'is-active', i === idx ) );
			};

			setActiveIndex( 0 );

			timeline.eventCallback( 'onUpdate', () => {
				const progress = timeline.progress();
				const exactIndex = progress * ( count - 1 );
				const activeIndex = Math.min( Math.round( exactIndex ), count - 1 );

				setActiveIndex( activeIndex );
			} );

			this._timeline = timeline;
			this._scrollTrigger = timeline.scrollTrigger;

			this._titleClickHandlers = titles.map( ( el, i ) => {
				const handler = () => {
					const st = this._scrollTrigger;
					if ( ! st ) {
						return;
					}
					const progress = i / ( count - 1 );
					const targetScroll = st.start + progress * ( st.end - st.start );
					window.scrollTo( { top: targetScroll, behavior: 'smooth' } );
				};
				el.addEventListener( 'click', handler );
				return handler;
			} );

			window.AvalonAddons.widget.pinReady( this.$element );

			return () => {
				this.removeTitleClickHandlers();
			};
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-services-showcase.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonServicesShowcaseHandler,
				{ $element }
			);
		}
	);
} );
