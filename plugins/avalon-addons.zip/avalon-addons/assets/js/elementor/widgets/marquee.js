class AvalonMarqueeWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				...super.getDefaultSettings().selectors,
				container: '.avalon-elementor--marquee',
				inner: '.avalon-marquee__inner',
				items: '.avalon-marquee--original',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			...super.getDefaultElements(),
			$container: this.$element.find( selectors.container ),
			$inner: this.$element.find( selectors.inner ),
			$items: this.$element.find( selectors.items ),
		};
	}

	duplicateItems() {
		const settings = this.getElementSettings(),
			$inner = this.elements.$inner;

		if ( $inner.find( '.avalon-marquee--duplicate' ).length ) {
			$inner.find( '.avalon-marquee--duplicate' ).remove();
		}

		const $items = $inner.find( '.avalon-marquee--original' );

		if ( ! $items.length ) {
			return;
		}

		const itemWidth = $items.outerWidth( true );

		if ( ! Number.isFinite( itemWidth ) || itemWidth <= 0 ) {
			return;
		}

		const speedValue = parseFloat( settings.speed );
		const speed      = ( Number.isFinite( speedValue ) && speedValue > 0 ? speedValue : 15 );
		const amount     = ( Math.ceil( jQuery( window ).width() / itemWidth ) || 0 ) + 1;

		$inner.css( '--avalon-marquee-speed', speed + 's' );

		for ( let i = 1; i <= amount; i++ ) {
			const item = $items.clone();

			item.addClass( 'avalon-marquee--duplicate' );
			item.removeClass( 'avalon-marquee--original' );
			item.css( '--avalon-marquee-index', String( i ) );
			item.appendTo( $inner );
		}
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this.duplicateItems();

		this._resizeHandler = () => {
			this.duplicateItems();
		};

		jQuery( window ).on( 'resize', this._resizeHandler );
	}

	onDestroy() {
		if ( this._resizeHandler ) {
			jQuery( window ).off( 'resize', this._resizeHandler );
		}
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-marquee.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				AvalonMarqueeWidgetHandler,
				{ $element }
			);
		}
	);
} );
