class AvalonMarqueeWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				...super.getDefaultSettings().selectors,
				container: '.avalon-elementor--marquee',
				inner: '.avalon-marquee__inner',
				items: '.avalon-marquee--original',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			...super.getDefaultElements(),
			$container: this.$element.find( selectors.container ),
			$inner: this.$element.find( selectors.inner ),
			$items: this.$element.find( selectors.items ),
		};
	}

	duplicateItems() {
		const settings = this.getElementSettings(),
			$inner = this.elements.$inner;

		if ( $inner.find( '.avalon-marquee--duplicate' ).length ) {
			$inner.find( '.avalon-marquee--duplicate' ).remove();
		}

		const $items = $inner.find( '.avalon-marquee--original' );

		if ( ! $items.length ) {
			return;
		}

		// Lightbox clones are stripped of their data-lightbox trigger, so a
		// delegated handler redirects clone clicks to the matching original.
		const hasLightbox = $items.children( '[data-lightbox="item"]' ).length > 0;

		$inner.off( 'click.avalonMarqueeLightbox' );

		if ( hasLightbox ) {
			$inner.on( 'click.avalonMarqueeLightbox', '.avalon-marquee--duplicate > [data-marquee-clone]', ( event ) => {
				const $cloneItem = jQuery( event.currentTarget );
				const $original  = $items.children().eq( $cloneItem.index() );

				if ( $original.length ) {
					event.preventDefault();
					$original[0].click();
				}
			} );
		}

		const itemWidth = $items.outerWidth( true );

		if ( ! Number.isFinite( itemWidth ) || itemWidth <= 0 ) {
			return;
		}

		const speedValue = parseFloat( settings.speed );
		const speed      = ( Number.isFinite( speedValue ) && speedValue > 0 ? speedValue : 15 );
		const amount     = ( Math.ceil( jQuery( window ).width() / itemWidth ) || 0 ) + 1;

		$inner.css( '--avalon-marquee-speed', speed + 's' );

		for ( let i = 1; i <= amount; i++ ) {
			const item = $items.clone();

			// Clean cloned post cards: drop duplicate ids and any scroll/lightbox
			// triggers so clones don't re-animate or leak into lightbox queries.
			item.removeAttr( 'id' );
			item.removeAttr( 'data-lightbox' );

			item.find( '[id], [data-animate], [data-lightbox], [data-st-start], [data-st-once]' ).each( function () {
				const $clone = jQuery( this );

				// Mark the item wrappers so lightbox clicks can map back to originals.
				if ( hasLightbox && this.parentNode === item[0] ) {
					$clone.attr( 'data-marquee-clone', 'true' );
				}

				$clone.removeAttr( 'id' );
				$clone.removeAttr( 'data-lightbox' );

				Array.from( this.attributes ).forEach( ( attr ) => {
					if ( attr.name.indexOf( 'data-animate' ) === 0 || attr.name.indexOf( 'data-st-' ) === 0 ) {
						$clone.removeAttr( attr.name );
					}
				} );
			} );

			item.addClass( 'avalon-marquee--duplicate' );
			item.removeClass( 'avalon-marquee--original' );
			item.css( '--avalon-marquee-index', String( i ) );
			item.appendTo( $inner );
		}
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this.duplicateItems();

		this._resizeHandler = () => {
			this.duplicateItems();
		};

		jQuery( window ).on( 'resize', this._resizeHandler );
	}

	onDestroy() {
		if ( this._resizeHandler ) {
			jQuery( window ).off( 'resize', this._resizeHandler );
		}
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	const bindMarqueeHandler = ( $element ) => {
		elementorFrontend.elementsHandler.addHandler(
			AvalonMarqueeWidgetHandler,
			{ $element }
		);
	};

	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-marquee.default',
		bindMarqueeHandler
	);

	elementorFrontend.hooks.addAction(
		'frontend/element_ready/avalon-posts-marquee.default',
		bindMarqueeHandler
	);
} );
