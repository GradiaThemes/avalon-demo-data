<?php
/**
 * Plugin Name: Avalon Addons
 * Plugin URI: #
 * Description: A companion plugin for the Avalon theme that adds custom Elementor widgets and theme-specific functionality.
 * Version: 1.0.0
 * Author: GradiaThemes
 * Author URI: https://gradiathemes.com
 * Text Domain: avalon-addons
 * Domain Path: /languages
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.5
 *
 * @package Avalon Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'AVALON_ADDONS_VERSION', '1.0.0' );
define( 'AVALON_ADDONS_FILE', __FILE__ );
define( 'AVALON_ADDONS_PATH', plugin_dir_path( __FILE__ ) );
define( 'AVALON_ADDONS_URL', plugin_dir_url( __FILE__ ) );
define( 'AVALON_ADDONS_ASSETS_URL', plugins_url( 'assets/', __FILE__ ) );

// Load the autoloader.
require_once AVALON_ADDONS_PATH . 'autoload.php';

// Load the plugin.
require_once AVALON_ADDONS_PATH . 'inc/plugin.php';

\AvalonAddons\Plugin::instance();
